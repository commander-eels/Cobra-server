#!/usr/bin/env bash
# F64-pve-home-vm.sh  --  (v3.8 draft) builds cobra-home: Home Assistant OS in VM 120 on the Latitude (Proxmox).
#
# Where:  the Proxmox host cobra-command (10.6.9.2), as root, in its web Shell (https://10.6.9.2:8006 -> cobra-command
#         -> >_ Shell). It's the only box plugged into both networks: vmbr0 = the LAN (10.6.9.x), vmbr1 = the Xfinity
#         side (10.0.0.x), where the Sensi thermostat and the Eufy bulbs live. (Manual part 10, chosen 2026-11-27.)
# How:    bash /root/F64-pve-home-vm.sh create [HAOS version]     README 9.5
#         bash /root/F64-pve-home-vm.sh plug-lan                   README 9.9   (LAN card on, VM starts)
#         bash /root/F64-pve-home-vm.sh plug-iot                   README 9.17  (Xfinity card on, AFTER Home Assistant
#                                                                                has net1 = static 10.0.0.3, no gateway)
#         bash /root/F64-pve-home-vm.sh usb                        README 10.3 (optional, later: pass a Zigbee USB stick
#                                                                                into VM 120; asks before restarting it)
#         bash /root/F64-pve-home-vm.sh check                      any time, read-only
#
# Safety: never touches another VM or container. "create" stops if VM 120 already exists, never overwrites a firewall
#   file (it prints what to merge instead), and both network cards start UNPLUGGED (link_down=1), so the Xfinity side
#   is never touched before Home Assistant has been told "no gateway there". The Proxmox firewall it turns on has
#   ACCEPT policies for the host and every other guest; only VM 120's Xfinity card (net1, firewall=1) gets rules.
# Undo:   qm stop 120 && qm destroy 120 --purge        (deletes only VM 120 and its disks; nothing else)
#         pve-firewall stop                             (if the Proxmox page or WireGuard stops answering)
set -euo pipefail
ID=120
NAME=cobra-home
VER_DEFAULT=18.5          # newest HA OS on 2026-11-27; check https://github.com/home-assistant/operating-system/releases
FW=${PVE_FW_DIR:-/etc/pve/firewall}   # (overridable only for the mock test)

say()  { printf '\n\033[1;32m==> %s\033[0m\n' "$*"; }
note() { printf '    %s\n' "$*"; }
warn() { printf '\033[1;33mWARNING: %s\033[0m\n' "$*"; }
die()  { printf '\033[1;31mERROR: %s\033[0m\n' "$*" >&2; exit 1; }
confirm() { local a; read -rp "    $1 [y/N] " a </dev/tty; [[ ${a,,} == y* ]]; }

[ "$(id -u)" = 0 ] || die "run this as root in the Proxmox Shell"
command -v qm >/dev/null && command -v pvesm >/dev/null || die "this isn't the Proxmox host (no qm). Open https://10.6.9.2:8006 -> cobra-command -> Shell."

net_line() { qm config "$ID" | sed -n "s/^$1: //p"; }

cmd_check() {
  say "VM $ID"
  if ! qm status "$ID" >/dev/null 2>&1; then note "doesn't exist yet"; return 0; fi
  note "$(qm status "$ID")"
  qm config "$ID" | grep -E '^(name|memory|net0|net1|scsi0|onboot|startup):' | sed 's/^/    /'
  say "Proxmox firewall"
  pve-firewall status 2>/dev/null | sed 's/^/    /' || true
  [ -f "$FW/$ID.fw" ] && sed 's/^/    /' "$FW/$ID.fw" || note "no $FW/$ID.fw"
}

cmd_create() {
  local VER=${1:-$VER_DEFAULT}
  [[ $VER =~ ^[0-9]+\.[0-9]+$ ]] || die "'$VER' doesn't look like an HA OS version (like 18.5)"
  local URL="https://github.com/home-assistant/operating-system/releases/download/$VER/haos_ova-$VER.qcow2.xz"
  local IMG=/root/haos_ova-$VER.qcow2

  say "1/6 Look first (read-only)"
  qm status "$ID" >/dev/null 2>&1 && die "VM $ID already exists ($(qm config "$ID" | sed -n 's/^name: //p')). Nothing changed. Send Claude: qm config $ID"
  pct status "$ID" >/dev/null 2>&1 && die "a container already uses ID $ID. Nothing changed."
  for b in vmbr0 vmbr1; do ip link show "$b" >/dev/null 2>&1 || die "bridge $b is missing. Nothing changed. Send Claude: ip -br link"; done
  local avail_mb mem=3072 lvm_free_gb root_free_gb
  avail_mb=$(free -m | awk '/^Mem:/ {print $7}')
  note "memory available: ${avail_mb} MB"
  if [ "$avail_mb" -lt 3500 ]; then
    [ "$avail_mb" -lt 2300 ] && die "under 2.3 GB of memory free; Home Assistant needs 2 GB. Nothing changed."
    warn "under 3.5 GB free, so VM $ID gets 2048 MB (Home Assistant's minimum; plenty for a thermostat and a dozen lights)"
    mem=2048
  fi
  lvm_free_gb=$(pvesm status --storage local-lvm 2>/dev/null | awk 'NR==2 {printf "%d", $6/1048576}')
  note "local-lvm free: ${lvm_free_gb:-?} GB (needs 32)"
  [ "${lvm_free_gb:-0}" -ge 32 ] || die "local-lvm has under 32 GB free. Nothing changed. Send Claude: pvesm status"
  root_free_gb=$(df -BG --output=avail /root | tail -1 | tr -dc 0-9)
  note "/root free: ${root_free_gb} GB (needs 8 for the download, deleted afterwards)"
  [ "$root_free_gb" -ge 8 ] || die "/root has under 8 GB free. Nothing changed."
  qm list | sed 's/^/    /'

  say "2/6 Download HA OS $VER"
  if [ -s "$IMG" ]; then
    note "already unpacked: $IMG"
  else
    curl -fsIL --max-time 20 "$URL" >/dev/null || die "HA OS $VER isn't on GitHub ($URL). Check the newest version on the releases page and run: bash $0 create <version>"
    wget -q --show-progress -O "$IMG.xz" "$URL" || { rm -f "$IMG.xz"; die "download failed. Nothing changed."; }
    xz -d "$IMG.xz" || { rm -f "$IMG.xz" "$IMG"; die "couldn't unpack it. Nothing changed."; }
  fi
  ls -lh "$IMG" | sed 's/^/    /'

  say "3/6 Create VM $ID ($NAME): UEFI, Secure Boot off, ${mem} MB, 2 cores, both network cards UNPLUGGED"
  confirm "Create VM $ID now?" || die "nothing changed"
  qm create "$ID" --name "$NAME" --ostype l26 \
    --machine q35 --bios ovmf \
    --efidisk0 local-lvm:1,efitype=4m,pre-enrolled-keys=0 \
    --cpu host --cores 2 --memory "$mem" \
    --scsihw virtio-scsi-single \
    --scsi0 "local-lvm:0,import-from=$IMG,discard=on,iothread=1,ssd=1" \
    --boot order=scsi0 \
    --net0 virtio,bridge=vmbr0,link_down=1 \
    --net1 virtio,bridge=vmbr1,firewall=1,link_down=1 \
    --agent 1 --onboot 1 --startup order=4
  qm resize "$ID" scsi0 32G

  say "4/6 Check the imported disk (a known Proxmox 9 trap: an import that 'succeeds' but leaves no partitions)"
  local vol dev parts
  vol=$(net_line scsi0 | cut -d, -f1)
  dev=$(pvesm path "$vol")
  parts=$(sfdisk -d "$dev" 2>/dev/null | grep -c '^/dev' || true)
  note "$vol -> $dev: $parts partitions (HA OS has 8)"
  if [ "${parts:-0}" -lt 8 ] || ! sfdisk -d "$dev" 2>/dev/null | grep -q '^label: gpt'; then
    warn "the imported disk doesn't look like HA OS. It can be written again byte for byte (only VM $ID's new disk)."
    confirm "Write the image straight onto VM $ID's disk ($dev)?" || die "stopped. VM $ID exists but won't boot. Undo: qm destroy $ID --purge"
    qemu-img convert -n -p -f qcow2 -O raw "$IMG" "$dev"   # -n: write onto the existing disk, create nothing
    parts=$(sfdisk -d "$dev" 2>/dev/null | grep -c '^/dev' || true)
    [ "${parts:-0}" -ge 8 ] || die "still no HA OS partitions on $dev. Send Claude: sfdisk -d $dev"
    note "rewritten: $parts partitions"
  fi
  rm -f "$IMG" && note "download deleted (the disk lives in local-lvm now)"

  say "5/6 Proxmox firewall: only VM $ID's Xfinity card gets rules"
  if [ -e "$FW/cluster.fw" ] || [ -e "$FW/$ID.fw" ]; then
    warn "a firewall file already exists, so nothing was written. Show these to Claude to merge by hand:"
    for f in "$FW/cluster.fw" "$FW/$ID.fw"; do [ -e "$f" ] && { note "--- $f"; sed 's/^/      /' "$f"; }; done
  else
    note "will write $FW/cluster.fw (firewall on, ACCEPT in and out: nothing changes for the host or other guests)"
    note "and $FW/$ID.fw (net1 only: drop NEW connections from the Xfinity side, except mDNS 5353 and ping)"
    if confirm "Write both files and turn the Proxmox firewall on?"; then
      mkdir -p "$FW"
      printf '[OPTIONS]\nenable: 1\npolicy_in: ACCEPT\npolicy_out: ACCEPT\n' >"$FW/cluster.fw"
      cat >"$FW/$ID.fw" <<'EOF'
[OPTIONS]
enable: 1
policy_in: DROP
policy_out: ACCEPT
log_level_in: nolog

[RULES]
IN ACCEPT -i net1 -p udp -dport 5353 -log nolog # mDNS: HomeKit discovery (the Sensi thermostat)
IN ACCEPT -i net1 -p icmp -log nolog # ping, for troubleshooting from the Xfinity side
EOF
      if ! pve-firewall compile >/dev/null; then
        rm -f "$FW/cluster.fw" "$FW/$ID.fw"; die "the rules didn't compile, so both files were removed again"
      fi
      pve-firewall restart
      pve-firewall status | sed 's/^/    /'
      warn "Check NOW that https://10.6.9.2:8006 still opens in a NEW browser tab. If it doesn't: pve-firewall stop"
    else
      warn "skipped. Don't plug in net1 (plug-iot) until the firewall is on: it's what keeps the Xfinity side out of VM $ID."
    fi
  fi

  say "6/6 Write these down (README 9.7 and 9.8)"
  note "net0 MAC (LAN, for OPNsense):    $(net_line net0 | sed -n 's/^virtio=\([^,]*\).*/\1/p')"
  note "net1 MAC (Xfinity, for the app): $(net_line net1 | sed -n 's/^virtio=\([^,]*\).*/\1/p')"
  say "VM $ID is made and switched off, with both cards unplugged. Next: README 9.7."
}

plug() {   # plug <net0|net1>
  local n=$1 line
  qm status "$ID" >/dev/null 2>&1 || die "VM $ID doesn't exist. Run: bash $0 create"
  line=$(net_line "$n")
  [ -n "$line" ] || die "VM $ID has no $n"
  if [[ $line != *link_down=1* ]]; then note "$n is already plugged in: $line"; return 0; fi
  if [ "$n" = net1 ]; then
    [[ $line == *firewall=1* ]] || die "net1 has lost firewall=1. Nothing changed. Send Claude: qm config $ID"
    [ -f "$FW/$ID.fw" ] && pve-firewall status 2>/dev/null | grep -q 'enabled/running' \
      || die "the Proxmox firewall isn't on for VM $ID, so the Xfinity side could reach it. Nothing changed. Send Claude: bash $0 check"
  fi
  qm set "$ID" --"$n" "${line/link_down=1/link_down=0}" >/dev/null   # same MAC, same bridge, same firewall flag
  note "$n plugged in: $(net_line "$n")"
}

cmd_usb() {
  # Zigbee coordinator chips seen on common sticks (Silicon Labs CP210x, WCH CH9102/CH340). Others: type the ID.
  local known='^(10c4:ea60|1a86:55d4|1a86:7523)$' ids id n
  qm status "$ID" >/dev/null 2>&1 || die "VM $ID doesn't exist yet."
  if net_line usb0 | grep -q .; then note "VM $ID already has a USB device: $(net_line usb0)"; return 0; fi
  command -v lsusb >/dev/null || die "lsusb is missing. Install it first: apt install usbutils"
  say "USB devices on the Latitude"
  lsusb | sed 's/^/    /'
  ids=$(lsusb | awk '{print $6}' | grep -E "$known" || true)
  n=$(printf '%s' "$ids" | grep -c . || true)
  if [ "$n" = 1 ]; then
    id=$ids; note "found one Zigbee-type stick: $id ($(lsusb | grep -F "$id" | cut -d' ' -f7-))"
  else
    [ "$n" = 0 ] && warn "no known Zigbee stick found. Is it plugged in (extension cable, USB 2.0 port)?"
    [ "$n" -gt 1 ] && warn "more than one possible stick: $(echo $ids)"
    read -rp "    Type the stick's ID from the list above (like 10c4:ea60), or Enter to stop: " id </dev/tty
    [ -n "$id" ] || die "nothing changed"
  fi
  [[ $id =~ ^[0-9a-f]{4}:[0-9a-f]{4}$ ]] || die "'$id' isn't a USB ID (4 hex digits, colon, 4 hex digits). Nothing changed."
  lsusb | awk '{print $6}' | grep -qx "$id" || die "$id isn't plugged in right now. Nothing changed."
  confirm "Give USB device $id to VM $ID? (Only VM $ID can use it afterwards.)" || die "nothing changed"
  qm set "$ID" --usb0 "host=$id" >/dev/null
  note "usb0: $(net_line usb0)"
  if qm status "$ID" | grep -q running; then
    confirm "Restart VM $ID now so Home Assistant sees the stick? (lights stay as they are; about 2 minutes)" \
      && { qm shutdown "$ID" --timeout 120 && qm start "$ID"; note "$(qm status "$ID")"; } \
      || warn "not restarted: the stick appears in Home Assistant after VM $ID's next restart"
  fi
  say "Next: README 10.4."
}

case ${1:-} in
  create)   shift; cmd_create "$@" ;;
  plug-lan) say "Plug in the LAN card and start VM $ID"; plug net0
            qm status "$ID" | grep -q running || qm start "$ID"
            note "$(qm status "$ID")"
            say "Next: README 9.10 (first boot takes up to 20 minutes)." ;;
  plug-iot) say "Plug in the Xfinity-side card"
            confirm "Did Home Assistant save net1 as STATIC 10.0.0.3/24 with NO gateway and NO DNS (README 9.15)?" || die "nothing changed. Do 9.15 first."
            plug net1
            say "Next: README 9.18 (route check)." ;;
  usb)      cmd_usb ;;
  check)    cmd_check ;;
  *)        die "usage: bash $0 create [version] | plug-lan | plug-iot | usb | check" ;;
esac
