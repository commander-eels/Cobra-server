# F00-copy-to-servers.ps1  --  copies this fix list to the gate and the SGIN, into /tmp/cobra-fix.
# It changes nothing on either server except making /tmp/cobra-fix (a scratch folder that a reboot empties).
#
# Where:  the-box, Windows Terminal -> PowerShell, inside the unzipped cobra-fix folder.
# How:    powershell -ExecutionPolicy Bypass -File .\F00-copy-to-servers.ps1
#
# What it does, step by step:
#   1. Checks the-box can reach both servers' SSH port (PIA must be disconnected: it hides 10.6.9.x).
#   2. Makes a clean copy with Linux line endings (Windows saves CRLF, and bash then fails with $'\r').
#   3. Copies that copy to /tmp/cobra-fix on each server and lets every user read it (podsvc runs most steps).
# The scripts are always started with "bash <file>", so a lost execute bit can never stop one half-way.

$ErrorActionPreference = 'Stop'
$here = $PSScriptRoot
$targets = @(
  @{ Name = 'gate (cobra-gate)';   Ip = '10.6.9.10'; Host = 'eels@10.6.9.10' },
  @{ Name = 'SGIN (cobra-stream)'; Ip = '10.6.9.20'; Host = 'eels@10.6.9.20' }
)

# 1. Reachability. Test-NetConnection prints nothing useful when it fails, so say what to do.
foreach ($t in $targets) {
  $ok = (Test-NetConnection $t.Ip -Port 22 -WarningAction SilentlyContinue).TcpTestSucceeded
  if (-not $ok) {
    Write-Host "ERROR: can't reach $($t.Name) on $($t.Ip):22. Disconnect PIA, check the-box is on the home network, try again." -ForegroundColor Red
    exit 1
  }
  Write-Host "==> $($t.Name) answers on port 22" -ForegroundColor Green
}

# 2. A staged copy with LF line endings and no byte-order mark. .ps1 files and survey output stay on the-box.
$stage = Join-Path $env:TEMP 'cobra-fix-stage'
if (Test-Path $stage) { Remove-Item -Recurse -Force $stage }
New-Item -ItemType Directory -Path $stage | Out-Null
$binary = '.woff2', '.png', '.jpg', '.zip'
Get-ChildItem -Path $here -Recurse -File |
  Where-Object { $_.Extension -ne '.ps1' -and $_.Name -notlike 'cobra-fix-survey-*.txt' } |
  ForEach-Object {
    $rel = $_.FullName.Substring($here.Length).TrimStart('\')
    $dest = Join-Path $stage $rel
    New-Item -ItemType Directory -Force -Path (Split-Path $dest) | Out-Null
    if ($binary -contains $_.Extension) { Copy-Item $_.FullName $dest; return }   # fonts are copied byte for byte
    $text = [IO.File]::ReadAllText($_.FullName) -replace "`r`n", "`n"
    [IO.File]::WriteAllText($dest, $text, (New-Object System.Text.UTF8Encoding($false)))
  }
Write-Host "==> staged $((Get-ChildItem $stage -Recurse -File).Count) files" -ForegroundColor Green

# 3. Copy. ssh/scp ask for eels's password unless the-box has an SSH key there.
foreach ($t in $targets) {
  Write-Host "==> $($t.Name): copying to /tmp/cobra-fix" -ForegroundColor Green
  ssh $t.Host 'mkdir -p /tmp/cobra-fix'
  scp -r "$stage\*" "$($t.Host):/tmp/cobra-fix/"
  ssh $t.Host 'chmod -R a+rX /tmp/cobra-fix && ls /tmp/cobra-fix'
}
Write-Host ""
Write-Host "Copied. Next: README.md, step 2 (the read-only survey)." -ForegroundColor Green
