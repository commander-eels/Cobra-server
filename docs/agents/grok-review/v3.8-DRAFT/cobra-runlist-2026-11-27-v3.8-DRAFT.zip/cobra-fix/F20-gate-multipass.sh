#!/usr/bin/env bash
# F20-gate-multipass.sh  --  puts the NEWEST Multi-Pass build on the gate (account.songofeo.com).
#
# Where:  the gate (10.6.9.10), as podsvc.
# How:    sudo machinectl shell podsvc@ /bin/bash /tmp/cobra-fix/F20-gate-multipass.sh
# Needs:  step 15 of cobra-setup done once before (eo-account's Quadlet and apps.json exist).
#
# Why the live page didn't have the new updates: there were TWO builds. Your downloaded bundle had the ADMIN
# section and themes; GitHub's main had Forgot password, PodPanels, new-user Bays and the Audiobookshelf walls,
# without the ADMIN section. This fix list carries one merged build with all of it, plus:
#   - Admin Bays: your personal pods (Vaultwarden, Paperless, MeTube, the radio, Feishin ...) with a live state
#   - Talk Radio & Comedy Club and The Archives as their own Audiobookshelf servers (password sync and new users)
#
# What it does:
#   1. READ-ONLY: shows which build is live and what's different.
#   2. After your y: backs up the live app files, copies the new ones in, adds the theme fonts (new files only).
#   3. Adds the two new Audiobookshelf servers to apps.json, switched OFF (nothing already there changes),
#      and offers to paste each one's API token (typed hidden, stored only in apps.json, mode 600).
#   4. nginx's account.conf (it now also serves /look.css and /fonts/): a diff, your y, nginx -t, reload.
#   5. Restarts eo-account and checks it answers. If it doesn't, the old files go back and it restarts again.
. "$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/fixlib.sh"
need_podsvc
[ "$(which_box)" = gate ] || die "this is for the gate (10.6.9.10)"
DIR=/srv/gate/eo-account
SRC=$P/account-gate
[ -f "$QDIR_FIX/eo-account.container" ] || die "eo-account isn't set up yet (no Quadlet). Run cobra-setup step 15 once first."
[ -f "$DIR/data/apps.json" ] || die "$DIR/data/apps.json is missing. Run cobra-setup step 15 once first."
IMAGE=$(sed -n 's/^Image=//p' "$QDIR_FIX/eo-account.container" | head -1)

# ------------------------------------------------------------------ 1. look
say "1/5 Live build vs this fix list (read-only)"
for m in 'def forgot_page' 'PODPANELS_KEY =' 'def admin_block' 'def admin_bays_block' 'AudiobookshelfTalk' 'def home_block'; do
  printf '    %-24s live %-3s new %s\n' "$m" "$(grep -c "$m" "$DIR/app/eo_account.py" 2>/dev/null || echo 0)" "$(grep -c "$m" "$SRC/eo_account.py")"
done
if cmp -s "$SRC/eo_account.py" "$DIR/app/eo_account.py"; then
  note "eo_account.py is already this build"
  NEWAPP=0
else
  # The whole diff is thousands of lines, so show its size, and keep the full diff in a file you can read.
  diff -u "$DIR/app/eo_account.py" "$SRC/eo_account.py" >"/tmp/eo_account-$TS.diff" || true
  note "eo_account.py differs: +$(grep -c '^+[^+]' "/tmp/eo_account-$TS.diff") / -$(grep -c '^-[^-]' "/tmp/eo_account-$TS.diff") lines (full diff: /tmp/eo_account-$TS.diff)"
  NEWAPP=1
fi

# ------------------------------------------------------------------ 2. app files
say "2/5 The app files in $DIR/app"
if [ "$NEWAPP" = 1 ]; then
  confirm "Install the new eo_account.py? (the live one is backed up first)" || die "nothing changed"
  backup "$DIR/app/eo_account.py"
  cp "$SRC/eo_account.py" "$DIR/app/eo_account.py"
fi
cp "$SRC/apps.example.json" "$DIR/app/apps.example.json"      # the app list without secrets, used in step 3
mkdir -p "$DIR/app/fonts"
# Copy each font (and licence) only if it isn't there yet: a file already in place is never overwritten.
( cd "$SRC/fonts" && find . -type f | while read -r f; do
    [ -e "$DIR/app/fonts/$f" ] || { mkdir -p "$DIR/app/fonts/$(dirname "$f")"; cp "$f" "$DIR/app/fonts/$f"; }
  done )
note "theme fonts: $(ls "$DIR/app/fonts"/*.woff2 2>/dev/null | wc -l) in $DIR/app/fonts"

# ------------------------------------------------------------------ 3. apps.json
say "3/5 apps.json: the two new Audiobookshelf servers"
# py runs Python in a throwaway container (the gate has no Python of its own). /data is the real data folder.
py() { podman run --rm -i -v "$DIR/app:/app:ro" -v "$DIR/data:/data" -e PYTHONDONTWRITEBYTECODE=1 "$IMAGE" python3 "$@"; }
backup "$DIR/data/apps.json"
py - <<'PY'
import json, os
p = "/data/apps.json"; c = json.load(open(p)); ex = json.load(open("/app/apps.example.json"))
added = [k for k in ex["apps"] if k not in c.setdefault("apps", {})]
for k in added:
    c["apps"][k] = ex["apps"][k]
if added:
    tmp = p + ".new"; open(tmp, "w").write(json.dumps(c, indent=2) + "\n"); os.chmod(tmp, 0o600); os.replace(tmp, p)
print("    added (switched off):", ", ".join(added) if added else "nothing, both were there")
PY
for app in audiobookshelf-talk audiobookshelf-archives; do
  on=$(py -c "import json;print(json.load(open('/data/apps.json'))['apps'].get('$app',{}).get('enabled',False))")
  [ "$on" = True ] && { note "$app: already on"; continue; }
  note "$app: off. Its token: that server's Settings -> API Keys -> Add (name it eo-account). Its server must be set up first (F30)."
  read -rsp "    Paste $app's API token now (hidden), or just Enter to leave it off: " tok </dev/tty; echo
  [ -n "$tok" ] || { note "left off"; continue; }
  # The token goes in on stdin, so it never shows up in the process list or on screen.
  printf '%s\n' "$tok" | py -c "
import json, os, sys
p = '/data/apps.json'; c = json.load(open(p)); a = c['apps']['$app']
a['api_token'] = sys.stdin.readline().strip(); a['enabled'] = True
tmp = p + '.new'; open(tmp, 'w').write(json.dumps(c, indent=2) + '\n'); os.chmod(tmp, 0o600); os.replace(tmp, p)
print('    $app: on')"
  unset tok
done

# ------------------------------------------------------------------ 4. nginx
say "4/5 nginx: $NGDIR/account.conf"
new=$(mktemp); cp "$SRC/account.conf" "$new"
if offer "$NGDIR/account.conf" "$new" "nginx's account.conf"; then
  gate_check_and_reload no_authelia "$NGDIR/account.conf"
fi

# ------------------------------------------------------------------ 5. restart and check
say "5/5 Restarting eo-account"
systemctl --user restart eo-account
up=0
for _ in $(seq 30); do
  podman exec eo-account python3 -c "import urllib.request; urllib.request.urlopen('http://127.0.0.1:8098/health', timeout=2)" 2>/dev/null && { up=1; break; }
  sleep 1
done
if [ "$up" != 1 ]; then
  podman logs --tail 30 eo-account 2>&1 | sed 's/^/    /'
  restore "$DIR/app/eo_account.py"
  systemctl --user restart eo-account
  die "the new build didn't start (log above), so the old eo_account.py is back and running. Send the log lines to Claude or Grok."
fi
podman logs --tail 1 eo-account | sed 's/^/    /'
note "read-only self-check:"
podman exec eo-account python3 /app/eo_account.py check 2>&1 | sed 's/^/    /' || true
say "Done. Open https://account.songofeo.com signed in as eels: Admin Bays and Admin are near the top."
