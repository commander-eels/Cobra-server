#!/usr/bin/env bash
# F32-gate-routes.sh  --  points the gate's front door at the new servers:
#   talk.songofeo.com, comedy.songofeo.com  -> the Talk Radio & Comedy Club Audiobookshelf (10.6.9.20:13379)
#   archives.songofeo.com                   -> CLOSED at the gate (private recordings): home Wi-Fi or WireGuard only,
#                                              http://10.6.9.20:13380
#   player.songofeo.com                     -> Feishin, the music player (inside the gate pod, 9180), behind the Music wall
# and lets the Audiobookshelf PHONE APP use talk. and comedy. (its API paths skip the gate sign-in,
# exactly like audio. already does; each server's own login is the wall there).
#
# Where:  the gate (10.6.9.10), as podsvc.
# How:    sudo machinectl shell podsvc@ /bin/bash /tmp/cobra-fix/F32-gate-routes.sh
#
# It edits only those lines in the LIVE files (it doesn't rewrite them from a template, so anything you changed
# by hand stays). Each file: a diff, your y, a backup, then nginx -t / authelia validate-config. A failed check
# puts every file back. Restarting Authelia signs everyone out once.
. "$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/fixlib.sh"
need_podsvc
[ "$(which_box)" = gate ] || die "this is for the gate (10.6.9.10)"
[ -f "$NG" ] || die "$NG doesn't exist"
[ -f "$AU" ] || die "$AU doesn't exist"

say "0/3 Can the gate reach the new servers? (read-only)"
for u in http://10.6.9.20:13379/ping; do printf '    %-32s %s\n' "$u" "$(probe_code "$u")"; done
note "000 means not yet: run F30 and F31 on the SGIN first. You can still go on; the doors just show an error until then."

changed=()

# ------------------------------------------------------------------ 1. nginx
say "1/3 nginx ($NG)"
new=$(mktemp)
# sed, line by line:
#   - the talk./comedy. upstream lines get the new port (whatever port they had before)
#   - the archives. line is taken OUT of the map and out of server_name, so nginx refuses that name (private Bay)
#   - player. is added under mustang. if it isn't there, and to the floors' server_name
#   - the phone-app skip becomes audio|sessions|talk|comedy (never archives)
sed -E \
  -e 's#^(\s*(talk|comedy)\.songofeo\.com\s+)http://10\.6\.9\.20:[0-9]+;#\1http://10.6.9.20:13379;#' \
  -e '/^\s*archives\.songofeo\.com\s+http/d' \
  -e 's#^(\s*server_name .*) archives\.songofeo\.com#\1#' \
  -e 's#\(audio\|sessions(\|talk\|comedy)?(\|archives)?\)(\\.songofeo)#(audio|sessions|talk|comedy)\3#' \
  "$NG" >"$new"
if ! grep -q 'player\.songofeo\.com' "$new"; then
  awk '{ print } /^[[:space:]]*mustang\.songofeo\.com[[:space:]]+http/ && !done { print "  player.songofeo.com       http://127.0.0.1:9180;    # Feishin, the music player for Navidrome (F32)"; done=1 }' "$new" >"$new.2" && mv "$new.2" "$new"
  sed -i -E '0,/server_name music\.songofeo\.com mustang\.songofeo\.com /s//server_name music.songofeo.com mustang.songofeo.com player.songofeo.com /' "$new"
  # v3.8: both edits hang off the mustang. lines. If mustang. was taken out by hand (it was dropped 2026-11-17),
  # they'd be skipped silently and nginx -t would still pass, leaving player. with no upstream. Stop instead.
  if ! grep -qE '^[[:space:]]*player\.songofeo\.com[[:space:]]+http' "$new" \
     || ! grep -qE '^[[:space:]]*server_name .*[[:space:]]player\.songofeo\.com([[:space:]]|;)' "$new"; then
    rm -f "$new"; die "couldn't add player. next to mustang. in $NG (mustang. lines missing or edited?). Nothing changed. Send Claude: grep -n 'music\.\|mustang' $NG"
  fi
fi
if offer "$NG" "$new" "nginx's songofeo.conf"; then changed+=("$NG"); fi

# ------------------------------------------------------------------ 2. Authelia
say "2/3 Authelia ($AU): player. behind the same Music wall as music."
new=$(mktemp)
# Every rule that lists music. and mustang. gets player. too, so the wall (and the home-Wi-Fi TOTP rule) match.
sed -E 's#\[music\.songofeo\.com, mustang\.songofeo\.com\]#[music.songofeo.com, mustang.songofeo.com, player.songofeo.com]#' "$AU" >"$new"
if offer "$AU" "$new" "Authelia's configuration.yml"; then changed+=("$AU"); fi

# ------------------------------------------------------------------ 3. check and reload
say "3/3 Check and reload"
if [ ${#changed[@]} = 0 ]; then note "nothing changed, nothing to reload"; exit 0; fi
if printf '%s\n' "${changed[@]}" | grep -q "$AU"; then gate_check_and_reload restart_authelia "${changed[@]}"
else gate_check_and_reload no_authelia "${changed[@]}"; fi
cat <<'TXT'

==> Two things only you can do (web pages, not scripts):
    1. Porkbun -> songofeo.com -> DNS: add a CNAME  player  ->  gate.songofeo.com  (talk and comedy already exist). Optional: delete the archives CNAME; the gate refuses that name either way.
    2. The certificate: F01's survey lists the names it covers. If it shows *.songofeo.com, nothing to do.
       If it lists names one by one and player.songofeo.com isn't there, add it where the certificate is made
       (manual part 5.3), then reload nginx.
TXT
