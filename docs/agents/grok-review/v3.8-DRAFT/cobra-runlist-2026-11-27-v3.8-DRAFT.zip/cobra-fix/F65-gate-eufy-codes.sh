#!/usr/bin/env bash
# F65-gate-eufy-codes.sh  --  (v3.8 draft) lists your Eufy bulbs and switches with their LOCAL codes, for Home Assistant.
#
# Where:  the gate (10.6.9.10), as eels (any LAN box with Python 3 works). Read-only: it changes nothing anywhere.
# How:    bash /tmp/cobra-fix/F65-gate-eufy-codes.sh
# Why:    Home Assistant's built-in EufyHome integration talks to each bulb directly on the Xfinity Wi-Fi, but it needs
#         each device's local code once. Eufy's cloud hands it out. This makes the same two calls as Home Assistant's
#         EufyHome docs. Your Eufy password is typed hidden and is never saved, logged or put on the command line.
# Then:   README 9.31: the codes go into Home Assistant's secrets.yaml, never into a chat or a screenshot.
set -euo pipefail
command -v python3 >/dev/null || { echo "ERROR: no python3 on this box" >&2; exit 1; }
python3 -I - <<'PY'
import getpass, json, sys, urllib.request

API = "https://home-api.eufylife.com/v1"

def call(url, body=None, headers=None):
    data = json.dumps(body).encode() if body is not None else None
    req = urllib.request.Request(url, data=data, headers={"Content-Type": "application/json", **(headers or {})})
    with urllib.request.urlopen(req, timeout=20) as r:
        return json.load(r)

# The EufyHome app's public client values, the same ones Home Assistant's docs and the lakeside library use.
try:
    login = call(f"{API}/user/email/login", {
        "client_id": "eufyhome-app",
        "client_Secret": "GQCpr9dSp3uQpsOMgJ4xQ",
        "email": input("    EufyHome email: "),
        "password": getpass.getpass("    EufyHome password (hidden): "),
    })
except Exception as e:
    sys.exit(f"ERROR: couldn't reach Eufy's login ({type(e).__name__}). Nothing changed. Check the gate has internet.")
token = login.get("access_token")
if not token:
    sys.exit(f"ERROR: Eufy refused the login: {login.get('message') or login.get('res_code') or 'no reason given'}. "
             "Nothing changed. README Help 9.27.")

devices = call(f"{API}/device/list/devices-and-groups", headers={"token": token, "category": "Home"})
ok = {"T1011", "T1012", "T1013", "T1201", "T1202", "T1203", "T1211"}   # what the EufyHome integration supports
print(f"\n    {'NAME':<24} {'MODEL':<6} {'IP':<15} {'LOCAL CODE':<17} WORKS LOCALLY?")
for item in devices.get("items", []):
    d = item.get("device")
    if not d:
        continue                                   # groups have no "device"
    model = d.get("product", {}).get("product_code", "?")
    ip = d.get("wifi", {}).get("lan_ip_addr", "?")
    print(f"    {d.get('alias_name', '?'):<24} {model:<6} {ip:<15} {d.get('local_code', '?'):<17} "
          f"{'yes' if model in ok else 'NO: cloud only, stays in the Eufy app'}")
print("\n    Keep this window private. The local codes go into Home Assistant's secrets.yaml (README 9.31).")
PY
