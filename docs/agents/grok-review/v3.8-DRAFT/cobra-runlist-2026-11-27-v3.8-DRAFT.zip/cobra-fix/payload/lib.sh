# shellcheck shell=bash
# Shared helpers for the cobra-setup scripts. Every numbered script sources this file; never run it on its own.
#
# The rules every script follows (the Commander's standing rules):
#   1. Nothing existing is replaced without asking. A change is written to a .new file first, shown as a
#      diff, and only copied over the real file after you type y.
#   2. Every file that is about to change is backed up first, as <file>.bak-YYYYmmdd-HHMMSS next to it.
#   3. Every change is checked (nginx -t, authelia validate-config, nft -c, a health check). If the check
#      fails, the backup is put back automatically and the script stops.
#   4. Running a script a second time changes nothing that is already right.

set -euo pipefail

# One timestamp per run, so every backup a script makes carries the same suffix and is easy to find.
TS=$(date +%Y%m%d-%H%M%S)

# The live files on the gate (cobra-gate, VM 110, 10.6.9.10). Override any of them in front of a command,
# for example:  NG=/tmp/test.conf bash 11-gate-ebooks.sh
NG=${NG:-/srv/gate/nginx/conf.d/songofeo.conf}          # the main nginx site file (manual 5.4)
NGDIR=${NGDIR:-/srv/gate/nginx/conf.d}                   # nginx reads every *.conf in here
AU=${AU:-/srv/gate/authelia/configuration.yml}           # Authelia's settings and access rules
AUDIR=${AUDIR:-/srv/gate/authelia}

# Coloured output, so OK / WARNING / ERROR stand out when you scroll back.
say()  { printf '\033[1;32m==> %s\033[0m\n' "$*"; }
note() { printf '    %s\n' "$*"; }
warn() { printf '\033[1;33mWARNING: %s\033[0m\n' "$*" >&2; }
die()  { printf '\033[1;31mERROR: %s\033[0m\n' "$*" >&2; exit 1; }

# confirm "question"   Asks y/N on the terminal itself (works even when the script's input is redirected).
# Anything except y or yes is a no. YES=1 in front of a command answers yes to every question
# (only use that once you've run the script and read its diffs).
confirm() {
  local a
  if [ "${YES:-0}" = 1 ]; then note "YES=1: answering yes to: $1"; return 0; fi
  read -rp "$1 [y/N] " a </dev/tty
  [[ ${a,,} == y || ${a,,} == yes ]]
}

# backup FILE   Copies FILE to FILE.bak-$TS (keeping owner, mode and time). Prints the backup's name.
backup() {
  [ -e "$1" ] || return 0
  cp -p "$1" "$1.bak-$TS"
  note "backup: $1.bak-$TS"
}

# restore FILE   Puts FILE.bak-$TS back over FILE (used when a check fails).
restore() {
  [ -e "$1.bak-$TS" ] || return 0
  cp -p "$1.bak-$TS" "$1"
  warn "put back $1 from $1.bak-$TS"
}

# offer FILE NEWFILE "what it is"
#   Shows the difference between FILE and NEWFILE. If they're the same, deletes NEWFILE and returns 1
#   ("nothing to do"). Otherwise asks; on yes, backs FILE up and writes NEWFILE's content over it
#   (with cat >, so FILE keeps its owner and permissions) and returns 0. On no, leaves FILE alone, returns 2.
offer() {
  local f=$1 new=$2 what=$3
  if [ -e "$f" ] && cmp -s "$f" "$new"; then
    rm -f "$new"; note "$what is already right, nothing to change"; return 1
  fi
  say "Proposed change to $what ($f):"
  if [ -e "$f" ]; then diff -u "$f" "$new" | sed 's/^/    /' || true
  else sed 's/^/    + /' "$new"; fi
  if ! confirm "Write this change to $f? (a backup is made first)"; then
    rm -f "$new"; warn "you said no, so $f was left exactly as it was"; return 2
  fi
  backup "$f"
  if [ -e "$f" ]; then cat "$new" > "$f"; else cp "$new" "$f"; fi
  rm -f "$new"
  return 0
}

# need_podsvc   The gate's and the SGIN's containers belong to the podsvc user, and rootless podman
# needs a real login session for it (sudo -u / sudo su don't make one; machinectl does).
need_podsvc() {
  [ "$(id -un)" = podsvc ] || die "run this as podsvc. As eels:  sudo machinectl shell podsvc@ /bin/bash $0"
  [ -n "${XDG_RUNTIME_DIR:-}" ] && [ -d "$XDG_RUNTIME_DIR" ] \
    || die "no user session for podsvc. Start it with  sudo machinectl shell podsvc@  (not sudo su)"
}

# need_eels   For steps that need sudo (firewall, mounts). eels is the admin account with sudo.
need_eels() {
  [ "$(id -u)" -ne 0 ] || die "run this as eels (with sudo inside), not as root"
  sudo -v || die "sudo didn't accept the password"
}

# running NAME   True when that container exists and is up.
# romm_hb SECONDS   RomM's /api/heartbeat (JSON). Tries this machine's loopback first, then its LAN address.
#                   ROMM_URL=http://host:port overrides both. RomM can take a while to answer it, so it
#                   waits at least 15 seconds.
romm_hb() {
  local u out t=$1; [ "$t" -lt 15 ] && t=15
  for u in ${ROMM_URL:-http://127.0.0.1:8080 http://10.6.9.20:8080}; do
    out=$(curl -s -L --max-time "$t" "$u/api/heartbeat" 2>/dev/null) || continue
    [[ $out == *"{"* ]] && { printf '%s' "$out"; return 0; }
  done
  return 1
}
# romm_up   RomM's web page answers at all (200 or a redirect), even if its heartbeat doesn't.
#           Prints "code url" for the record, e.g. "200 http://127.0.0.1:8080".
romm_up() {
  local u c
  for u in ${ROMM_URL:-http://127.0.0.1:8080 http://10.6.9.20:8080}; do
    c=$(curl -s --max-time 10 -o /dev/null -w '%{http_code}' "$u/" 2>/dev/null)
    [[ $c =~ ^(200|301|302|303|307)$ ]] && { echo "$c $u"; return 0; }
  done
  return 1
}
running() { [ "$(podman inspect -f '{{.State.Running}}' "$1" 2>/dev/null)" = true ]; }

# restart_app NAME   Restarts a container the way it was started: a Quadlet service (systemctl --user) if there
# is one, else the plain container (the podman run scripts made it with --restart always).
restart_app() {
  if systemctl --user cat "$1.service" >/dev/null 2>&1; then systemctl --user restart "$1"
  else podman restart "$1" >/dev/null; fi
}

# nginx_test   nginx -t. In the running container if it's up; otherwise in a throwaway nginx with the same
# two folders (manual 5.4, step 1), so a broken file is caught before nginx is ever started on it.
nginx_test() {
  if running nginx; then podman exec nginx nginx -t
  else
    note "(nginx isn't running yet, so testing in a throwaway nginx container)"
    podman run --rm -v /srv/gate/nginx/conf.d:/etc/nginx/conf.d:ro -v /srv/gate/nginx/certs:/certs:ro \
      ${STATION_MOUNT:+-v /srv/station/web:/srv/station/web:ro} docker.io/library/nginx:stable nginx -t
  fi
}

# authelia_test   authelia validate-config, the same way.
authelia_test() {
  if running authelia; then podman exec authelia authelia validate-config --config /config/configuration.yml
  else
    note "(Authelia isn't running yet, so testing in a throwaway Authelia container)"
    podman run --rm -v /srv/gate/authelia:/config docker.io/authelia/authelia:latest \
      authelia validate-config --config /config/configuration.yml
  fi
}

# gate_check_and_reload restart_authelia|no_authelia FILE ...
#   Tests nginx (and Authelia), then reloads nginx and restarts Authelia if they're running.
#   On any failure, puts back every FILE given and stops. Restarting Authelia signs everyone out once.
gate_check_and_reload() {
  local mode=$1; shift
  local f
  say "Checking nginx's config (nginx -t)"
  if ! nginx_test; then
    for f in "$@"; do restore "$f"; done
    die "nginx refused the change, so every file above was put back. Nothing was reloaded."
  fi
  if [ "$mode" = restart_authelia ]; then
    say "Checking Authelia's config (authelia validate-config)"
    if ! authelia_test; then
      for f in "$@"; do restore "$f"; done
      die "Authelia refused the change, so every file above was put back. Nothing was restarted."
    fi
    if running authelia || systemctl --user cat authelia.service >/dev/null 2>&1; then
      say "Restarting Authelia (this signs everyone out once; they just sign in again)"
      restart_app authelia
      sleep 6
      if ! running authelia; then
        for f in "$@"; do restore "$f"; done
        restart_app authelia || true
        die "Authelia didn't come back up, so every file above was put back and Authelia restarted again. Look at: podman logs --tail 40 authelia"
      fi
    else
      note "Authelia isn't set up as a container yet; it reads this file when it first starts."
    fi
  fi
  if running nginx; then
    say "Reloading nginx (no downtime: running connections finish on the old config)"
    podman exec nginx nginx -s reload
  else
    note "nginx isn't running yet; it reads these files when it first starts."
  fi
}
