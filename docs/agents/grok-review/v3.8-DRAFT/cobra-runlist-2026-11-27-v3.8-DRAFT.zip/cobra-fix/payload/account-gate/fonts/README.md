# The Multi-pass fonts

The fonts the ADMIN section offers for each theme. Every file is a Latin-only subset of a font from
Google Fonts' own repository (github.com/google/fonts). They are served from the page's own address,
because the page's security policy allows only that (font-src 'self'). Each font's licence is in
`licenses/`: the SIL Open Font License (OFL), except Special Elite (Apache 2.0). Both allow
redistributing the fonts like this, licence files included.

To make one again, or add one (needs `pip install fonttools brotli`):

```bash
# --unicodes: basic Latin, Latin-1, and the few symbols the page uses (dashes, quotes, arrows, the ornaments)
pyftsubset Orbitron[wght].ttf \
  --unicodes="U+0020-007E,U+00A0-00FF,U+2013-2014,U+2018-201D,U+2022,U+2026,U+2192,U+25B6,U+2726,U+2694,U+00B7,U+2715,U+2713" \
  --flavor=woff2 --layout-features='kern,liga' --output-file=orbitron.woff2
```

A new font also needs a line in `FONTS` and a place in `THEME_FONTS` in `eo_account.py`.
