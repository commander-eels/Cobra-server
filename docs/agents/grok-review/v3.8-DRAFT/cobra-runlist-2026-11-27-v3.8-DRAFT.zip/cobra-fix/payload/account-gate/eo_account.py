#!/usr/bin/env python3
"""eo-account: one password for the whole station.

A friend changes their password once, at https://account.songofeo.com (behind the gate's sign-in). This app
then sets that same password in Authelia (the gate) and in every app that keeps its own login for phone and
TV apps: Jellyfin, Navidrome (Subsonic apps), Audiobookshelf, Kavita, RomM and Calibre-Web (OPDS readers).

Why a page of our own and not Authelia's: Authelia only stores a one-way hash, and no app can use another
app's hash. The plain password only exists for the moment someone types it, so that's when it is copied.

Python standard library only. Settings come from the environment:
  ACCOUNT_ADDR      127.0.0.1:8098            where to listen (inside the gate pod; nginx is the only way in)
  ACCOUNT_APPS      /data/apps.json           each app's address and admin login (mode 600; see apps.example.json)
  ACCOUNT_USERS     /authelia/users.yml       Authelia's users file (mounted read-write; Authelia watches it)
  ACCOUNT_AUTHELIA  http://127.0.0.1:9091     Authelia, to check the CURRENT password before anything changes
  ACCOUNT_PORTAL    gate.songofeo.com         the host Authelia's sign-in answers to
  ACCOUNT_ORIGIN    https://account.songofeo.com   the only page allowed to post the form
  ACCOUNT_MIN_LEN   12
  ACCOUNT_FF        /app/ff                   Formidable's client (ff.js, ff.css), copied here by script 15
  ACCOUNT_SIGNOUT   https://gate.songofeo.com/logout?rd=...   the Sign out button (Authelia logout, then back here)
  ACCOUNT_FORMS     http://127.0.0.1:8097/f/username   cobra-forms' "username" form: "Request a username change"
                                              is passed on there, and cobra-forms emails it to Eels (or keeps it in
                                              forms.songofeo.com/inbox). Empty: the box isn't shown.
  ACCOUNT_FORMS_ACCESS  .../f/access          cobra-forms' "access" form: tells Eels a new access request is waiting
                                              (default: ACCOUNT_FORMS with /username swapped for /access)
  ACCOUNT_ADMINS    eels,root                 who sees the ADMIN section on their Multi-Pass (comma list). Anyone in the
                                              Authelia group "admins" sees it too.
  ACCOUNT_SETTINGS  /data/settings.json       the ADMIN section's switches and dials (theme, palette, password length ...)
  ACCOUNT_REQUESTS  /data/requests.json       waiting access requests (mode 600; holds each one's password HASH only)

Public pages (no sign-in; nginx sends only these paths here without the gate, and strips any Remote-User header):
  /join             "Request access": a friend asks for a pass, one question per screen, and picks their password.
                    Only its hash is kept. Nothing is created until Eels presses Approve on his Multi-Pass, which
                    writes the account into Authelia's users file (one sign-in for the station and every Bay).
                    The Bays can't be given a hash, so the first time they sign in, their Multi-Pass asks for
                    the password once ("Open my Bays") and makes their account in each app their pass allows.
                    An app account that already exists is left exactly as it is.
  /forgot           "Forgot password?": a friend who has a pass asks for a new password, one question per screen,
                    and picks it. Only its hash is kept, and the page never says whether a username exists.
                    Nothing changes until Eels checks it's really them (by a number or address he already has)
                    and presses Approve. Approve writes the new hash into Authelia only; the next time they sign
                    in, their Multi-Pass asks for the new password once and sets it in every app.
  ACCOUNT_RESYNC    /data/resync.json         who still needs their reset password copied to every app (no secrets)
  ACCOUNT_SETUP     /data/setup.json          who Eels approved and still needs their Bay accounts made (no secrets)
  PODPANELS_URL     http://127.0.0.1:8100    PodPanels command service, inside the gate pod only (no nginx route to it).
                                              The service must bind 8100. 8099 is the VIP helper in songofeo.conf.
  PODPANELS_KEY     (unset)                   the podman secret podpanels-key, injected by Quadlet as this environment
                                              variable. The admin proxy sends it as X-PodPanels-Key. It is never logged
                                              and never written into the page. There is no PODPANELS_API_KEY, no key
                                              file, and this app never accepts a pasted key.
  AUTHELIA_AUTHZ_URL http://127.0.0.1:9091/api/authz/auth-request
                                              Before /admin/pods is proxied or a key is rotated, this app asks Authelia
                                              itself. It forwards only the visitor's Cookie plus X-Original-Method,
                                              X-Original-URL (https://account.songofeo.com plus the path),
                                              X-Forwarded-Proto and X-Forwarded-Host. HTTP 200 is required, and the
                                              Remote-User Authelia returns must be the Remote-User on the request and
                                              one of ACCOUNT_ADMINS. HTTP 401 answers with a link to the gate sign-in.
                                              If Authelia cannot be reached the answer is 503. The cookie is never logged.

Approve and Decline on /admin/access (access requests and password resets) also run the Authelia session
check above first, so a forged Remote-User header can't approve anything.

Admin only (ACCOUNT_ADMINS), behind the gate's sign-in, and only after the Authelia session check above:
  /admin/pods/      PodPanels, proxied to PODPANELS_URL. GET /admin/pods redirects to /admin/pods/.
                    The key is added on the server. The browser never sends it.
  POST /admin/pods/rotate
                    "Make new key": asks PodPanels to generate a new key and replace the podman secret, then shows
                    that key once in the answer. This process does not keep the new key and cannot run podman.

The /admin/pods proxy and its Authelia session check are gate code. Cross-check them before they run on a server.

Command line (inside the container: podman exec -i eo-account python3 /app/eo_account.py ...):
  check             READ-ONLY. Logs in to each app as its admin and lists which station users each app knows.
  apps USER         Reads a password on stdin and sets it for USER in every app (not Authelia). Script 11 uses this.
  hash              Reads a password on stdin and prints the hash this app would write for Authelia.
  abs-libraries     READ-ONLY unless the next word is "apply" AND ABS_APPLY=1. Checks each Audiobookshelf
                    user's libraries against the Talk and Archives walls. The admin token is ABS_API_TOKEN
                    (a podman secret or an environment variable; never a value in this file). It is never printed.

abs-libraries is gate code. Cross-check it before it runs on a server.
"""

from __future__ import annotations

import base64
import fcntl
import hashlib
import hmac
import html
import http.client
import http.cookiejar
import json
import os
import re
import secrets
import sys
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
from html.parser import HTMLParser
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

ADDR = os.environ.get("ACCOUNT_ADDR", "127.0.0.1:8098")
APPS_FILE = Path(os.environ.get("ACCOUNT_APPS", "/data/apps.json"))
USERS_FILE = Path(os.environ.get("ACCOUNT_USERS", "/authelia/users.yml"))
AUTHELIA = os.environ.get("ACCOUNT_AUTHELIA", "http://127.0.0.1:9091").rstrip("/")
PORTAL = os.environ.get("ACCOUNT_PORTAL", "gate.songofeo.com")
ORIGIN = os.environ.get("ACCOUNT_ORIGIN", "https://account.songofeo.com")
MIN_LEN = int(os.environ.get("ACCOUNT_MIN_LEN", "12"))   # the floor: the admin dial can raise it, never lower it

# ---------------------------------------------------------------- settings (the ADMIN section's switches and dials)
# /data/settings.json, written only from an admin's Multi-Pass. Anything missing there takes the default below.
SETTINGS_FILE = Path(os.environ.get("ACCOUNT_SETTINGS", str(APPS_FILE.parent / "settings.json")))
THEMES = {"modern": "Modern", "hitek": "Hi-tek", "synthwave": "Synthwave", "pixel": "Pixel", "kingdom": "Kingdom",
          "clinical": "Clinical"}
# Fonts for each theme's headings, buttons and big numbers (body text stays readable unless "body" is set).
# Each is a small Latin-only .woff2 in /app/fonts (ACCOUNT_FONTS), cut from Google Fonts' OFL/Apache files
# (how: fonts/README.md; the licences are in fonts/licenses). key: (name, CSS weight range, also the body text?)
FONTS = {
    "inter": ("Inter", "100 900", True), "manrope": ("Manrope", "200 800", True), "dmsans": ("DM Sans", "100 1000", True),
    "outfit": ("Outfit", "100 900", True), "jakarta": ("Plus Jakarta Sans", "200 800", True), "syne": ("Syne", "400 800", False),
    "orbitron": ("Orbitron", "400 900", False), "oxanium": ("Oxanium", "200 800", False), "chakrapetch": ("Chakra Petch", "700", False),
    "sharetechmono": ("Share Tech Mono", "400", True), "rajdhani": ("Rajdhani", "700", False), "tektur": ("Tektur", "400 900", False),
    "monoton": ("Monoton", "400", False), "audiowide": ("Audiowide", "400", False), "righteous": ("Righteous", "400", False),
    "bungee": ("Bungee", "400", False), "exo2": ("Exo 2", "100 900", True),
    "pressstart2p": ("Press Start 2P", "400", False), "vt323": ("VT323", "400", True), "silkscreen": ("Silkscreen", "400", False),
    "pixelify": ("Pixelify Sans", "400 700", False), "dotgothic16": ("DotGothic16", "400", False), "jersey10": ("Jersey 10", "400", False),
    "cinzel": ("Cinzel", "400 900", False), "medievalsharp": ("MedievalSharp", "400", False), "unifraktur": ("UnifrakturMaguntia", "400", False),
    "imfell": ("IM Fell English", "400", True), "almendra": ("Almendra", "700", False), "cormorant": ("Cormorant Garamond", "300 700", True),
    "plexmono": ("IBM Plex Mono", "600", False), "spacemono": ("Space Mono", "700", False), "courierprime": ("Courier Prime", "700", False),
    "specialelite": ("Special Elite", "400", False), "creepster": ("Creepster", "400", False), "nosifer": ("Nosifer", "400", False),
}
THEME_FONTS = {   # "" = the theme's own built-in type
    "modern": ["", "inter", "manrope", "dmsans", "outfit", "jakarta", "syne"],
    "hitek": ["", "orbitron", "oxanium", "chakrapetch", "sharetechmono", "rajdhani", "tektur"],
    "synthwave": ["", "monoton", "audiowide", "righteous", "bungee", "exo2", "orbitron"],
    "pixel": ["", "pressstart2p", "vt323", "silkscreen", "pixelify", "dotgothic16", "jersey10"],
    "kingdom": ["", "cinzel", "medievalsharp", "unifraktur", "imfell", "almendra", "cormorant"],
    "clinical": ["", "plexmono", "spacemono", "courierprime", "specialelite", "creepster", "nosifer"],
}
FONTS_DIR = Path(os.environ.get("ACCOUNT_FONTS", "/app/fonts"))
PALETTES = {"1": "Gold", "2": "Crimson", "3": "Cyan", "4": "Violet", "5": "Emerald", "6": "Ember", "7": "Ice"}
SETTING_DEFAULTS = {"theme": "modern", "palette": "1", "fonts": {}, "min_len": MIN_LEN, "accept_requests": True, "username_requests": True,
                    "stats_minutes": 10}
SETTING_RANGES = {"min_len": (MIN_LEN, 24), "stats_minutes": (5, 60)}


def setting(key: str):
    try:
        v = json.loads(SETTINGS_FILE.read_text()).get(key, SETTING_DEFAULTS[key])
    except (OSError, ValueError):
        v = SETTING_DEFAULTS[key]
    if key in SETTING_RANGES:
        lo, hi = SETTING_RANGES[key]
        v = max(lo, min(hi, int(v))) if isinstance(v, (int, float)) else SETTING_DEFAULTS[key]
    if key == "theme" and v not in THEMES:
        v = SETTING_DEFAULTS["theme"]
    if key == "fonts" and not isinstance(v, dict):
        v = {}
    if key == "palette" and str(v) not in PALETTES:
        v = SETTING_DEFAULTS["palette"]
    return v


def save_settings(new: dict) -> None:
    try:
        cur = json.loads(SETTINGS_FILE.read_text())
    except (OSError, ValueError):
        cur = {}
    cur.update(new)
    tmp = SETTINGS_FILE.with_name(SETTINGS_FILE.name + ".new")
    tmp.write_text(json.dumps(cur, indent=1) + "\n")
    os.chmod(tmp, 0o600)
    os.replace(tmp, SETTINGS_FILE)


def min_len() -> int:
    return setting("min_len")


def pw_rule() -> str:
    return f"At least {min_len()} characters, with at least 1 number and 1 special character (like ! ? # $ % & * - _)."


def password_problem(pw: str) -> str:
    """The station's password rule (the Commander's, 2026-11-16). Empty string = the password is fine."""
    if len(pw) < min_len():
        return f"The new password needs at least {min_len()} characters."
    if not any(c.isdigit() for c in pw):
        return "The new password needs at least 1 number."
    if all(c.isalnum() or c.isspace() for c in pw):
        return "The new password needs at least 1 special character (like ! ? # $ % & * - _)."
    return ""
SIGNOUT = os.environ.get("ACCOUNT_SIGNOUT", "https://" + PORTAL + "/logout?rd=" + urllib.parse.quote(ORIGIN + "/", safe=""))
FORMS = os.environ.get("ACCOUNT_FORMS", "http://127.0.0.1:8097/f/username").strip()
USER_RE = re.compile(r"^[a-z0-9._-]{2,32}$")
ADMINS = {a.strip().lower() for a in os.environ.get("ACCOUNT_ADMINS", "eels").split(",") if a.strip()}
# PodPanels must bind 127.0.0.1:8100 inside the gate pod. 8099 is the VIP helper in songofeo.conf.
# The key arrives only as the podman secret (type=env, target=PODPANELS_KEY). PODPANELS_API_KEY is ignored
# on purpose: there is no second door and no pasted key.
ADMIN_GROUP = "admins"
GROUPS = [("music", "Music Bay"), ("talk", "Talk Radio"), ("archives", "The Archives"), (ADMIN_GROUP, "Admin")]   # the groups the ADMIN section offers


def is_admin(user: str, groups: set[str]) -> bool:
    """The ADMIN section shows for ACCOUNT_ADMINS or the "admins" group. Changing anything still needs
    _require_admin_session, which accepts ACCOUNT_ADMINS only (Authelia re-checks the cookie)."""
    return user in ADMINS or ADMIN_GROUP in groups


PODPANELS_URL = os.environ.get("PODPANELS_URL", "http://127.0.0.1:8100").strip().rstrip("/")
PODPANELS_KEY = os.environ.get("PODPANELS_KEY", "").strip()
# Session check for /admin/pods. nginx already asks Authelia; this asks again so another container in the
# pod cannot forge Remote-User. The cookie is sent only on this call and is never logged.
AUTHELIA_AUTHZ_URL = os.environ.get(
    "AUTHELIA_AUTHZ_URL", "http://127.0.0.1:9091/api/authz/auth-request").strip()
POD_POST_WINDOW, POD_POST_PER, POD_POST_ALL = 600, 30, 60          # /admin/pods POSTs: 30 per admin, 60 for everyone, per 10 minutes
POD_ROTATE_WINDOW, POD_ROTATE_PER, POD_ROTATE_ALL = 3600, 3, 6     # Make new key: 3 per admin, 6 for everyone, per hour
POD_LOCK = threading.Lock()
POD_HITS: dict[str, list[float]] = {}
POD_ALL: dict[str, list[float]] = {}
_POD_LOOPBACK = {"127.0.0.1", "localhost", "::1"}
_POD_BAD = re.compile(r"\.\.|\\|%2e|\x00", re.IGNORECASE)
_NEW_KEY_RE = re.compile(r"^[0-9a-f]{64}$")
_KEY_CREATED_RE = re.compile(r"^[0-9]{4}-[0-9]{2}-[0-9]{2}[T ][0-9]{2}:[0-9]{2}(?::[0-9]{2})?(?:Z|[+-][0-9]{2}:?[0-9]{2})?$")
POD_MAX_BODY = 1_048_576
PAGE_CSP = "default-src 'none'; script-src 'self'; style-src 'self' 'unsafe-inline'; connect-src 'self'; font-src 'self'; form-action 'self'; frame-ancestors 'none'"
PROXY_CSP = "default-src 'self'; frame-ancestors 'none'"
REQUESTS_FILE = Path(os.environ.get("ACCOUNT_REQUESTS", str(APPS_FILE.parent / "requests.json")))
FORMS_ACCESS = os.environ.get("ACCOUNT_FORMS_ACCESS", re.sub(r"/username$", "/access", FORMS) if FORMS else "").strip()
SIGN_IN = f"https://{PORTAL}/?rd=" + urllib.parse.quote(ORIGIN + "/", safe="")   # the gate's sign-in, then back here
JOIN = "~join"                                  # the "user" the public request form's tokens are made for
JOINED: dict[str, list[float]] = {}             # visitor address -> times of recent access requests
FORGOT = "~forgot"                              # the "user" the public forgot-password form's tokens are made for
RESET_DAYS = 3                                  # a reset nobody answered in 3 days is dropped (its hash with it)
RESYNC_FILE = Path(os.environ.get("ACCOUNT_RESYNC", str(APPS_FILE.parent / "resync.json")))
SETUP_FILE = Path(os.environ.get("ACCOUNT_SETUP", str(APPS_FILE.parent / "setup.json")))   # approved, Bay accounts not made yet
MAX_WAITING = 30                                # at most this many requests wait at once (a flood can't fill the disk)
TIMEOUT = 15
FORM_SECRET = secrets.token_bytes(32)          # new on every start: an open form simply needs a reload after a restart
LOCK = threading.Lock()                         # one password change at a time
RECENT: dict[str, list[float]] = {}             # username -> times of recent attempts (a light brake on top of Authelia's)
ASKED: dict[str, list[float]] = {}              # username -> times of recent username-change requests
SERVING = False                                 # True when running as the web page (then every sync line is logged)


def log(*parts: object) -> None:
    print(time.strftime("%Y-%m-%d %H:%M:%S"), *parts, flush=True)


# ---------------------------------------------------------------- Authelia: hash, verify, write

def authelia_hash(password: str) -> str:
    """PBKDF2-SHA512 in the passlib format Authelia reads ($pbkdf2-sha512$rounds$salt$key, adapted base64).
    The stdlib has no argon2; 15-gate-accounts.sh asks the real Authelia to validate one of these before use."""
    def ab64(b: bytes) -> str:
        return base64.b64encode(b).decode().rstrip("=").replace("+", ".")
    salt, rounds = os.urandom(16), 310_000
    key = hashlib.pbkdf2_hmac("sha512", password.encode(), salt, rounds, 64)
    return f"$pbkdf2-sha512${rounds}${ab64(salt)}${ab64(key)}"


def authelia_password_verdict(user: str, password: str, client_ip: str) -> str:
    """'ok', 'wrong', 'locked' (Authelia's lock-out answered 403) or 'down' (Authelia couldn't be reached)."""
    try:
        return "ok" if authelia_check_password(user, password, client_ip, strict=True) else "wrong"
    except urllib.error.HTTPError as e:
        return "locked" if e.code == 403 else "wrong"
    except (urllib.error.URLError, TimeoutError, OSError):
        return "down"


def authelia_check_password(user: str, password: str, client_ip: str, strict: bool = False) -> bool:
    """Asks Authelia itself whether this is the user's current password. Authelia's own lock-out
    (regulation) counts wrong tries, so this page can't be used to guess passwords faster than the gate."""
    body = json.dumps({"username": user, "password": password, "keepMeLoggedIn": False}).encode()
    req = urllib.request.Request(f"{AUTHELIA}/api/firstfactor", data=body, method="POST", headers={
        "Content-Type": "application/json", "Accept": "application/json",
        "Host": PORTAL, "X-Forwarded-Host": PORTAL, "X-Forwarded-Proto": "https",
        "X-Forwarded-For": client_ip, "X-Original-URL": f"https://{PORTAL}/"})
    try:
        with urllib.request.urlopen(req, timeout=TIMEOUT) as r:
            return r.status == 200 and json.loads(r.read() or b"{}").get("status") == "OK"
    except urllib.error.HTTPError as e:
        if strict and e.code != 401:
            raise
        return False


def users_in_file() -> list[str]:
    try:
        text = USERS_FILE.read_text()
    except OSError:
        return []
    return re.findall(r"^  ([a-z0-9._-]+):\s*$", text, re.M)


def authelia_set_password(user: str, new_hash: str) -> None:
    """Replaces the password line inside USER's block only. The file is rewritten in place (same inode), so the
    single-file bind mount keeps working and Authelia's file watcher reloads it. A backup is kept beside it."""
    with open(USERS_FILE, "r+") as f:
        fcntl.flock(f, fcntl.LOCK_EX)
        old = f.read()
        lines, out, inside, done = old.splitlines(keepends=True), [], False, False
        for line in lines:
            if re.match(rf"^  {re.escape(user)}:\s*$", line):
                inside = True
            elif inside and re.match(r"^  \S", line):
                inside = False
            if inside and re.match(r"^    password:", line):
                line, done = f"    password: '{new_hash}'\n", True
            out.append(line)
        if not done:
            raise RuntimeError(f"{user} has no password line in the users file")
        bak = USERS_FILE.with_name(USERS_FILE.name + ".bak-account")
        bak.write_text(old)
        os.chmod(bak, 0o600)
        f.seek(0)
        f.write("".join(out))
        f.truncate()
        f.flush()
        os.fsync(f.fileno())


def authelia_add_user(user: str, display: str, email: str, pw_hash: str, groups: list[str]) -> None:
    """Adds one account block at the end of the users: list. Same in-place write and backup as above.
    The display name and email are written as JSON strings, which YAML reads as double-quoted strings."""
    with open(USERS_FILE, "r+") as f:
        fcntl.flock(f, fcntl.LOCK_EX)
        old = f.read()
        if re.search(rf"^  {re.escape(user)}:\s*$", old, re.M):
            raise ValueError(f"{user} is already in the users file")
        lines = old.splitlines(keepends=True)
        if lines and not lines[-1].endswith("\n"):
            lines[-1] += "\n"
        top = next((i for i, l in enumerate(lines) if re.match(r"^users:\s*$", l)), None)
        if top is None:
            raise RuntimeError("the users file has no 'users:' line")
        end = next((i for i in range(top + 1, len(lines)) if re.match(r"^\S", lines[i])), len(lines))
        block = (f"  {user}:\n    displayname: {json.dumps(display)}\n    email: {json.dumps(email)}\n"
                 f"    password: '{pw_hash}'\n"
                 + ("    groups:\n" + "".join(f"      - {g}\n" for g in groups) if groups else "    groups: []\n"))
        lines.insert(end, block)
        bak = USERS_FILE.with_name(USERS_FILE.name + ".bak-account")
        bak.write_text(old)
        os.chmod(bak, 0o600)
        f.seek(0)
        f.write("".join(lines))
        f.truncate()
        f.flush()
        os.fsync(f.fileno())


def _unquote(v: str) -> str:
    v = v.strip()
    if v.startswith('"'):
        try:
            return json.loads(v)
        except ValueError:
            return v.strip('"')
    if v.startswith("'") and v.endswith("'"):
        return v[1:-1].replace("''", "'")
    return v


def read_users() -> list[dict]:
    """Every account in the users file: name, display name, email, groups, disabled. Never the password."""
    try:
        lines = USERS_FILE.read_text().splitlines()
    except OSError:
        return []
    people, cur, in_groups = [], None, False
    for line in lines:
        m = re.match(r"^  ([a-z0-9._-]+):\s*$", line)
        if m:
            cur = {"name": m[1], "displayname": "", "email": "", "groups": [], "disabled": False}
            people.append(cur)
            in_groups = False
            continue
        if cur is None or re.match(r"^\S", line):
            cur = None if re.match(r"^\S", line) else cur
            continue
        f = re.match(r"^    ([a-z_]+):\s*(.*)$", line)
        if f:
            in_groups = f[1] == "groups"
            if f[1] in ("displayname", "email"):
                cur[f[1]] = _unquote(f[2])
            elif f[1] == "disabled":
                cur["disabled"] = f[2].strip().lower() == "true"
            elif in_groups and f[2].strip().startswith("["):
                cur["groups"] = [_unquote(g) for g in f[2].strip()[1:-1].split(",") if g.strip()]
            continue
        g = re.match(r"^      - (.+)$", line)
        if g and in_groups:
            cur["groups"].append(_unquote(g[1]))
    return people


def authelia_update_user(user: str, display: str, email: str, groups: list[str], disabled: bool) -> None:
    """Rewrites only USER's display name, email, groups and disabled lines; the password line and anything else in
    the block stay exactly as they were. Same in-place write and backup as the password change."""
    with open(USERS_FILE, "r+") as f:
        fcntl.flock(f, fcntl.LOCK_EX)
        old = f.read()
        lines = old.splitlines(keepends=True)
        start = next((i for i, l in enumerate(lines) if re.match(rf"^  {re.escape(user)}:\s*$", l)), None)
        if start is None:
            raise LookupError(f"{user} isn't in the users file")
        end = next((i for i in range(start + 1, len(lines)) if re.match(r"^  \S|^\S", lines[i])), len(lines))
        kept, skipping = [], False
        for l in lines[start + 1:end]:
            if re.match(r"^    (displayname|email|groups|disabled):", l):
                skipping = l.startswith("    groups:")
                continue
            if skipping and re.match(r"^      - ", l):
                continue
            skipping = False
            kept.append(l if l.endswith("\n") else l + "\n")
        new_block = [f"    displayname: {json.dumps(display)}\n", f"    email: {json.dumps(email)}\n"] + kept
        new_block += ["    groups:\n"] + [f"      - {g}\n" for g in groups] if groups else ["    groups: []\n"]
        if disabled:
            new_block.append("    disabled: true\n")
        out = lines[:start + 1] + new_block + lines[end:]
        bak = USERS_FILE.with_name(USERS_FILE.name + ".bak-account")
        bak.write_text(old)
        os.chmod(bak, 0o600)
        f.seek(0)
        f.write("".join(out))
        f.truncate()
        f.flush()
        os.fsync(f.fileno())


# ---------------------------------------------------------------- small HTTP helper

class Http:
    """urllib with a cookie jar, JSON in and out, and the app's error text kept short."""

    def __init__(self, base: str):
        self.base = base.rstrip("/")
        self.jar = http.cookiejar.CookieJar()
        self.opener = urllib.request.build_opener(urllib.request.HTTPCookieProcessor(self.jar))

    def call(self, method: str, path: str, *, json_body=None, form=None, headers=None, raw=False):
        data, hdrs = None, dict(headers or {})
        if json_body is not None:
            data, hdrs["Content-Type"] = json.dumps(json_body).encode(), "application/json"
        elif form is not None:
            data, hdrs["Content-Type"] = urllib.parse.urlencode(form, doseq=True).encode(), "application/x-www-form-urlencoded"
        hdrs.setdefault("Accept", "application/json")
        req = urllib.request.Request(self.base + path, data=data, method=method, headers=hdrs)
        try:
            with self.opener.open(req, timeout=TIMEOUT) as r:
                body = r.read()
        except urllib.error.HTTPError as e:
            text = e.read()[:200].decode("utf-8", "replace").strip()
            raise RuntimeError(f"{method} {path.split('?', 1)[0]} -> HTTP {e.code} {text}") from None
        except urllib.error.URLError as e:
            raise RuntimeError(f"can't reach {self.base}: {e.reason}") from None
        if raw:
            return body.decode("utf-8", "replace")
        return json.loads(body) if body.strip() else None


# ---------------------------------------------------------------- the apps

class App:
    """One app. users() -> {username: id}; set_password(user, pw). Usernames are compared in lower case."""
    title = "app"

    def __init__(self, cfg: dict):
        self.cfg = cfg
        self.http = Http(cfg["url"])

    def users(self) -> dict[str, str]:
        raise NotImplementedError

    def set_password(self, user: str, pw: str) -> None:
        raise NotImplementedError

    def find(self, user: str) -> str | None:
        return self.users().get(user.lower())

    def create_user(self, user: str, pw: str, who: dict) -> None:
        """Makes a NEW account. who = {"display", "email", "groups"}. Only called when users() has no such name."""
        raise NotImplementedError


class Jellyfin(App):
    title = "Jellyfin (tv.)"

    def _h(self):
        return {"Authorization": f'MediaBrowser Token="{self.cfg["api_key"]}"'}

    def users(self):
        return {u["Name"].lower(): u["Id"] for u in self.http.call("GET", "/Users", headers=self._h())}

    def set_password(self, user, pw):
        uid = self.find(user)
        if not uid:
            raise LookupError
        self.http.call("POST", f"/Users/{uid}/Password", headers=self._h(),
                       json_body={"CurrentPw": "", "NewPw": pw, "ResetPassword": False})

    def create_user(self, user, pw, who):
        # Jellyfin's own defaults for a new user (every library, no admin).
        self.http.call("POST", "/Users/New", headers=self._h(), json_body={"Name": user, "Password": pw})


class Navidrome(App):
    title = "Navidrome (music.: Subsonic apps)"

    def _h(self):
        if not getattr(self, "_token", None):
            r = self.http.call("POST", "/auth/login", json_body={"username": self.cfg["admin_user"], "password": self.cfg["admin_password"]})
            self._token = r["token"]
        return {"X-ND-Authorization": f"Bearer {self._token}"}

    def _records(self):
        return self.http.call("GET", "/api/user?_start=0&_end=1000", headers=self._h())

    def users(self):
        return {u["userName"].lower(): u["id"] for u in self._records()}

    def set_password(self, user, pw):
        rec = next((u for u in self._records() if u["userName"].lower() == user.lower()), None)
        if not rec:
            raise LookupError
        body = {k: rec[k] for k in ("id", "userName", "name", "email", "isAdmin") if k in rec}
        body["password"] = pw
        self.http.call("PUT", f"/api/user/{rec['id']}", headers=self._h(), json_body=body)

    def create_user(self, user, pw, who):
        self.http.call("POST", "/api/user", headers=self._h(),
                       json_body={"userName": user, "name": who.get("display") or user, "email": who.get("email", ""),
                                  "password": pw, "isAdmin": False})


class Audiobookshelf(App):
    title = "Audiobookshelf (audio., sessions.)"

    def _h(self):
        return {"Authorization": f"Bearer {self.cfg['api_token']}"}

    def users(self):
        r = self.http.call("GET", "/api/users", headers=self._h())
        return {u["username"].lower(): u["id"] for u in r.get("users", [])}

    def set_password(self, user, pw):
        uid = self.find(user)
        if not uid:
            raise LookupError
        self.http.call("PATCH", f"/api/users/{uid}", headers=self._h(), json_body={"password": pw})

    def create_user(self, user, pw, who):
        # The phone-app door on audio. skips the gate, so the account itself carries the Talk and Archives walls:
        # accessAllLibraries off, and only the libraries this person's pass allows (new_user_libraries).
        libs = (self.http.call("GET", "/api/libraries", headers=self._h()) or {}).get("libraries") or []
        allowed = new_user_libraries(user, who.get("groups", set()), libs)
        if not allowed:
            raise RuntimeError("no library on their pass was found, so no account was made")
        self.http.call("POST", "/api/users", headers=self._h(), json_body={
            "username": user, "password": pw, "type": "user", "isActive": True,
            "permissions": {"download": True, "update": False, "delete": False, "upload": False,
                            "accessAllLibraries": False, "accessAllTags": True, "accessExplicitContent": True},
            "librariesAccessible": allowed})


class AudiobookshelfWalled(Audiobookshelf):
    """Its own Audiobookshelf instance for one walled Bay (2026-11-21, the Commander's call): its own pod, config,
    metadata, port and users, sharing nothing with audio. The whole server is the wall, so a new account simply
    gets every library on it, and setup_apps only makes one for people whose pass allows the Bay (APP_BAY)."""

    def create_user(self, user, pw, who):
        self.http.call("POST", "/api/users", headers=self._h(), json_body={
            "username": user, "password": pw, "type": "user", "isActive": True,
            "permissions": {"download": True, "update": False, "delete": False, "upload": False,
                            "accessAllLibraries": True, "accessAllTags": True, "accessExplicitContent": True}})


class AudiobookshelfTalk(AudiobookshelfWalled):
    title = "Talk Radio & Comedy Club (talk., comedy.)"


class AudiobookshelfArchives(AudiobookshelfWalled):
    title = "The Archives (private, home and WireGuard only)"


class Kavita(App):
    title = "Kavita (comics.)"

    def _h(self):
        if not getattr(self, "_token", None):
            r = self.http.call("POST", "/api/Account/login", json_body={"username": self.cfg["admin_user"], "password": self.cfg["admin_password"]})
            self._token = r["token"]
        return {"Authorization": f"Bearer {self._token}"}

    def users(self):
        return {u["username"].lower(): str(u["id"]) for u in self.http.call("GET", "/api/Users", headers=self._h())}

    def set_password(self, user, pw):
        name = next((n for n in self.users() if n == user.lower()), None)
        if not name:
            raise LookupError
        real = next(u["username"] for u in self.http.call("GET", "/api/Users", headers=self._h()) if u["username"].lower() == name)
        self.http.call("POST", "/api/Account/reset-password", headers=self._h(),
                       json_body={"userName": real, "password": pw, "oldPassword": ""})

    # Roles a new reader gets, where this Kavita has them. Never Admin.
    KAVITA_ROLES = ("Pleb", "Login", "Download", "Bookmark", "Change Password")

    def create_user(self, user, pw, who):
        # Kavita makes accounts by invite: invite (as admin), then confirm the invite with the password.
        # No email is sent; the invite link comes back in the answer and is used here once.
        have = self.http.call("GET", "/api/Account/roles", headers=self._h()) or []
        roles = [r for r in self.KAVITA_ROLES if r in have]
        libs = [lib["id"] for lib in (self.http.call("GET", "/api/Library/libraries", headers=self._h()) or []) if "id" in lib]
        # Always the station's own address, never their real one, so Kavita can't mail an invite to anyone.
        email = f"{user}@users.songofeo.com"
        # A try that was invited but not confirmed left a pending user named by that email. Only that exact
        # pending record (this address is made only here) is removed, so the invite can be sent again.
        pending = self.http.call("GET", "/api/Users?includePending=true", headers=self._h()) or []
        for u in pending:
            if (u.get("username") or "").lower() == email and u.get("isPending"):
                self.http.call("DELETE", "/api/Users/delete-user?username=" + urllib.parse.quote(u["username"]), headers=self._h())
        r = self.http.call("POST", "/api/Account/invite", headers=self._h(), json_body={
            "email": email, "roles": roles, "libraries": libs,
            "ageRestriction": {"ageRating": -1, "includeUnknowns": True}}) or {}
        link = r.get("emailLink") or ""
        q = urllib.parse.parse_qs(urllib.parse.urlsplit(link).query)
        token = (q.get("token") or [""])[0]
        if not token:
            raise RuntimeError("Kavita's invite came back without a link, so the account was not finished")
        self.http.call("POST", "/api/Account/confirm-email",
                       json_body={"email": (q.get("email") or [email])[0], "token": token, "username": user, "password": pw})


# The three Kavitas are walled from each other (2026-11-21, the owner's rule: every instance of an app is walled).
# Same API, separate servers, so each is its own entry in apps.json with its own admin login, and each person
# gets a separate account in each. stats_bay is the Bay their reading numbers belong to.
Kavita.stats_bay = "comics"


class KavitaBooks(Kavita):
    title = "Kavita Books (books.)"
    stats_bay = "library"


class KavitaRpg(Kavita):
    title = "Kavita RPG Vault (gaming.)"
    stats_bay = "rpg"


class RomM(App):
    title = "RomM (arcade.)"

    def _h(self):
        tok = base64.b64encode(f"{self.cfg['admin_user']}:{self.cfg['admin_password']}".encode()).decode()
        return {"Authorization": f"Basic {tok}"}

    def users(self):
        return {u["username"].lower(): str(u["id"]) for u in self.http.call("GET", "/api/users", headers=self._h())}

    def set_password(self, user, pw):
        uid = self.find(user)
        if not uid:
            raise LookupError
        self.http.call("PUT", f"/api/users/{uid}", headers=self._h(), form={"password": pw})

    def create_user(self, user, pw, who):
        # RomM 4 (the gate runs rommapp/romm:latest) takes a JSON body. The password never goes in a URL:
        # an older RomM that wants query parameters gets a "make it by hand" answer instead.
        email = who.get("email") or f"{user}@users.songofeo.com"
        try:
            self.http.call("POST", "/api/users", headers=self._h(),
                           json_body={"username": user, "password": pw, "email": email, "role": "viewer"})
        except RuntimeError as e:
            if "HTTP 422" in str(e):
                raise RuntimeError("RomM refused the new account (HTTP 422). Make it by hand in RomM: "
                                   "Administration -> Users -> +") from None
            raise


class _FormReader(HTMLParser):
    """Collects every field of Calibre-Web's edit-user form as it is now, so re-sending it changes only the password."""

    def __init__(self):
        super().__init__()
        self.fields: list[tuple[str, str]] = []
        self._select: str | None = None
        self._first_option: str | None = None
        self._picked = False

    def handle_starttag(self, tag, attrs):
        a = dict(attrs)
        name = a.get("name")
        if tag == "input" and name:
            kind = (a.get("type") or "text").lower()
            if kind in ("checkbox", "radio"):
                if "checked" in a:
                    self.fields.append((name, a.get("value", "on")))
            elif kind not in ("submit", "button", "file", "password"):
                self.fields.append((name, a.get("value", "")))
        elif tag == "select" and name:
            self._select, self._first_option, self._picked = name, None, False
        elif tag == "option" and self._select:
            val = a.get("value", "")
            if self._first_option is None:
                self._first_option = val
            if "selected" in a and not self._picked:
                self.fields.append((self._select, val))
                self._picked = True

    def handle_endtag(self, tag):
        if tag == "select" and self._select:
            if not self._picked and self._first_option is not None:
                self.fields.append((self._select, self._first_option))
            self._select = None


class CalibreWeb(App):
    title = "Calibre-Web (books.: OPDS readers)"

    def _login(self):
        if getattr(self, "_in", False):
            return
        page = self.http.call("GET", "/login", raw=True, headers={"Accept": "text/html"})
        m = re.search(r'name="csrf_token"[^>]*value="([^"]+)"', page)
        form = {"username": self.cfg["admin_user"], "password": self.cfg["admin_password"], "remember_me": "on", "submit": ""}
        if m:
            form["csrf_token"] = m.group(1)
        after = self.http.call("POST", "/login", form=form, raw=True, headers={"Accept": "text/html"})
        if 'name="password"' in after and "/logout" not in after:
            raise RuntimeError("admin login refused (check admin_user / admin_password)")
        self._in = True

    def users(self):
        self._login()
        r = self.http.call("GET", "/ajax/listusers?offset=0&limit=1000", headers={"Accept": "application/json"})
        rows = r.get("rows", []) if isinstance(r, dict) else r
        return {u["name"].lower(): str(u["id"]) for u in rows if u.get("name") and u.get("name") != "Guest"}

    def set_password(self, user, pw):
        uid = self.find(user)
        if not uid:
            raise LookupError
        page = self.http.call("GET", f"/admin/user/{uid}", raw=True, headers={"Accept": "text/html"})
        reader = _FormReader()
        reader.feed(page)
        fields = [(k, v) for k, v in reader.fields if k != "password"]
        if not any(k == "name" for k, _ in fields):
            raise RuntimeError("couldn't read the edit-user form; nothing was sent")
        fields.append(("password", pw))
        self.http.call("POST", f"/admin/user/{uid}", form=fields, raw=True, headers={"Accept": "text/html"})

    def create_user(self, user, pw, who):
        # Fills Calibre-Web's own "Add new user" form as it is (its default roles), never with the admin role.
        self._login()
        page = self.http.call("GET", "/admin/user/new", raw=True, headers={"Accept": "text/html"})
        reader = _FormReader()
        reader.feed(page)
        skip = {"name", "email", "password", "admin_role"}
        fields = [(k, v) for k, v in reader.fields if k not in skip]
        if not any(k == "csrf_token" for k, _ in fields) and "csrf_token" in page:
            raise RuntimeError("couldn't read the add-user form; nothing was sent")
        fields += [("name", user), ("email", who.get("email") or f"{user}@users.songofeo.com"), ("password", pw)]
        self.http.call("POST", "/admin/user/new", form=fields, raw=True, headers={"Accept": "text/html"})
        if user.lower() not in self.users():
            raise RuntimeError("Calibre-Web didn't keep the new account (is that email already used there?)")


# Talk Radio & Comedy and The Archives are libraries in the one Audiobookshelf since 2026-11-18, so the
# "audiobookshelf" entry already covers their passwords. An apps.json that still lists navidrome-talk or
# navidrome-archives is fine: kinds not named here are skipped (load_apps), never an error.
KINDS = {"jellyfin": Jellyfin, "navidrome": Navidrome,
         "audiobookshelf": Audiobookshelf, "kavita": Kavita, "kavita-books": KavitaBooks, "kavita-rpg": KavitaRpg,
         "romm": RomM, "calibre-web": CalibreWeb,   # calibre-web goes with Calibre-Web itself (cobra-server docs/kavita-walls-runbook.md step 5)
         "audiobookshelf-talk": AudiobookshelfTalk, "audiobookshelf-archives": AudiobookshelfArchives}


def load_apps() -> list[App]:
    try:
        cfg = json.loads(APPS_FILE.read_text())
    except FileNotFoundError:
        log(f"no {APPS_FILE}: only Authelia will be changed")
        return []
    apps = []
    for kind, c in cfg.get("apps", {}).items():
        if kind in KINDS and c.get("enabled"):
            apps.append(KINDS[kind](c))
    return apps


def sync_apps(user: str, pw: str) -> list[tuple[str, str, str]]:
    """Sets pw for user in every enabled app. Returns (app, 'ok'|'skip'|'fail', detail) per app."""
    results = []
    for app in load_apps():
        try:
            app.set_password(user, pw)
            results.append((app.title, "ok", "updated"))
        except LookupError:
            results.append((app.title, "skip", f"no account named {user} there"))
        except Exception as e:                                    # one app failing never stops the others
            results.append((app.title, "fail", str(e)[:200]))
        if SERVING:
            log(f"sync {user}: {results[-1][0]}: {results[-1][1]} {results[-1][2] if results[-1][1] != 'ok' else ''}")
    return results


# Which Bay each app is, for the group walls in BAYS_DEFAULT. Apps not named here have no wall.
# The walls come from the built-in BAYS_DEFAULT, never from /data/bays.json: a file on disk can't widen who
# gets an account (the same rule library_walls and abs-libraries use).
# Audiobookshelf's walls are per library (new_user_libraries), not per app.
APP_BAY = {Navidrome: "music", AudiobookshelfTalk: "talk", AudiobookshelfArchives: "archives"}


def bay_wall(bay: str) -> tuple[str, set[str]] | None:
    for b in BAYS_DEFAULT:
        if b.get("bay") == bay and b.get("need"):
            return b["need"], {u.casefold() for u in b.get("also", [])}
    return None


def new_user_libraries(user: str, groups: set[str], libs: list) -> list[str]:
    """Audiobookshelf library ids a new account gets: every library, minus Talk and Archives unless the pass allows them."""
    claimed = match_abs_libraries(libs)
    walls = library_walls()
    drop = {claimed[b]["id"] for b in ("talk", "archives") if b in claimed and not _may_enter(user, groups, walls[b])}
    claimed_ids = {lib.get("id") for lib in claimed.values()}
    # A library whose name looks like Talk or Archives but matched neither (say "Talk Shows") is left out:
    # its wall can't be told, so nobody new gets it until it's renamed (abs-libraries warns about it too).
    drop |= {lib.get("id") for lib in libs if lib.get("id") not in claimed_ids and _ABS_NAME_HINT.search(lib.get("name") or "")}
    return [lib["id"] for lib in libs if isinstance(lib.get("id"), str) and lib["id"] not in drop]


def setup_apps(user: str, pw: str, who: dict) -> list[tuple[str, str, str]]:
    """First sign-in after Approve: makes the account in every enabled app their pass allows.
    An account that is already there is left exactly as it is (not even its password is changed).
    Returns (app, 'ok'|'skip'|'fail', detail) per app."""
    results = []
    groups = who.get("groups", set())
    for app in load_apps():
        try:
            bay = APP_BAY.get(type(app))
            wall = bay_wall(bay) if bay else None
            if wall and not _may_enter(user, groups, wall):
                results.append((app.title, "skip", "not on your pass"))
            elif app.find(user):
                results.append((app.title, "skip", "already there, left as it is"))
            else:
                app.create_user(user, pw, who)
                results.append((app.title, "ok", "account made"))
        except Exception as e:                                    # one app failing never stops the others
            results.append((app.title, "fail", str(e)[:200]))
        if SERVING:
            log(f"setup {user}: {results[-1][0]}: {results[-1][1]} {results[-1][2] if results[-1][1] != 'ok' else ''}")
    return results


def user_record(user: str) -> dict:
    """display name, email and groups from Authelia's users file (the pass Eels approved). No password lines."""
    try:
        text = USERS_FILE.read_text()
    except OSError:
        return {"display": user, "email": "", "groups": set()}
    groups = authelia_groups(text).get(user, set())
    display = email = ""
    inside = False
    for line in text.splitlines():
        if re.match(r"^  \S", line):
            inside = line.strip() == f"{user}:"
            continue
        if inside:
            m = re.match(r"^    (displayname|email):\s*(.*)$", line)
            if m:
                val = m.group(2).strip().strip("'\"")
                if m.group(1) == "displayname":
                    display = val
                else:
                    email = val
    return {"display": display or user, "email": email, "groups": groups}


# ---------------------------------------------------------------- the Bay directory

# The concourse, in the Commander's order: two Bays a row, then the Command Deck across the bottom.
# address = what a phone or TV app is pointed at. probe = where the gate checks the Bay is up (empty = no check).
# need = the Authelia group a Bay's wall asks for (people named in "also" get in without it).
# /data/bays.json, if it exists, replaces this list (same fields), so a new Bay needs no code change.
DOCKYARD = {"name": "Song of Eo Rebel Entertainment Dockyard", "address": "https://songofeo.com"}
STATION_BAY = "https://station.songofeo.com/mall/?bay="   # each Bay's own window on the concourse
BAYS_DEFAULT = [
    {"bay": "tv", "name": "Television", "address": "https://tv.songofeo.com", "probe": "http://10.6.9.20:8096/health",
     "app": "Jellyfin", "how": "Jellyfin app on your phone or TV: Add server, this address, then your station username and password."},
    {"bay": "music", "name": "Music", "address": "https://music.songofeo.com", "probe": "http://10.6.9.20:4533/ping",
     "app": "Navidrome", "need": "music", "also": ["eels", "rachel"],
     "how": "Any Subsonic music app (Symfonium, Substreamer, Tempo ...): this address, your username and password."},
    {"bay": "audiobooks", "name": "Audiobooks", "address": "https://audio.songofeo.com", "probe": "http://10.6.9.20:13378/ping",
     "app": "Audiobookshelf", "how": "Audiobookshelf app: this address, your username and password."},
    {"bay": "talk", "name": "Talk Radio & Comedy Club", "address": "https://talk.songofeo.com", "probe": "http://10.6.9.20:13379/ping",
     "app": "Audiobookshelf (its own server)", "need": "talk", "also": ["eels", "rachel"],
     "how": "Audiobookshelf phone app: Add server, https://talk.songofeo.com, your username and password. It's its own server, apart from Audiobooks, and keeps your spot and bookmarks in every show."},
    {"bay": "library", "name": "Library", "address": "https://books.songofeo.com", "probe": "http://10.6.9.20:5001/api/health",
     "app": "Kavita Books (its own server)",
     "how": "Kavita in the browser: one shelf per bookstore section, sorted by author, and it keeps your page. E-reader apps with OPDS "
            "(KOReader, Moon+ Reader, Librera ...): the OPDS address from this Kavita's settings. Its own account, apart from Comics and the RPG Vault."},
    {"bay": "rpg", "name": "RPG Vault", "address": "https://gaming.songofeo.com", "probe": "http://10.6.9.20:5002/api/health",
     "app": "Kavita RPG Vault (its own server)",
     "how": "Kavita in the browser reads the PDF rulebooks and keeps your page. Tablet apps with OPDS (Panels, Chunky, KOReader): "
            "the OPDS address from this Kavita's settings (its own, not Comics'). Fillable character sheets: download the PDF and fill it in a PDF app."},
    {"bay": "arcade", "name": "Arcade", "address": "https://arcade.songofeo.com", "probe": "http://10.6.9.20:8080/",
     "app": "RomM", "how": "RomM in the browser plays right there; RomM-aware apps: this address, your username and password."},
    {"bay": "archives", "name": "The Archives", "address": "http://10.6.9.20:13380", "probe": "http://10.6.9.20:13380/ping",
     "app": "Audiobookshelf (its own private server)", "need": "archives", "also": ["eels"],
     "how": "Home Wi-Fi (cobra) or WireGuard only: it holds personal recordings, so it never faces the internet. Audiobookshelf phone app: Add server, this address, your username and password. Nothing is shared with Audiobooks or Talk Radio."},
]
COMMAND_DECK = {"name": "Command Deck", "address": "https://songofeo.com/council/",
                "how": "Always open to everyone, signed in or not: Seek Council's petitions."}
STATUS: dict[str, str] = {}                     # probe URL -> "up" | "down"


def load_bays() -> list[dict]:
    try:
        return json.loads((APPS_FILE.parent / "bays.json").read_text())
    except FileNotFoundError:
        return BAYS_DEFAULT
    except Exception as e:
        log(f"bays.json unreadable ({e}); using the built-in list")
        return BAYS_DEFAULT


def probe(url: str) -> str:
    """Up = the app answers at all (any reply below 500) within 4 seconds."""
    try:
        with urllib.request.urlopen(urllib.request.Request(url, method="GET"), timeout=4) as r:
            return "up" if r.status < 500 else "down"
    except urllib.error.HTTPError as e:
        return "up" if e.code < 500 else "down"
    except Exception:
        return "down"


def watch_bays() -> None:
    """Checks every Bay once a minute in the background, so the page itself never waits on a slow app."""
    while True:
        for url in {b.get("probe") for b in load_bays() + load_admin_bays() if b.get("probe")}:
            STATUS[url] = probe(url)
        time.sleep(60)


def copy_address(addr: str) -> str:
    """An address you tap to copy (app.js). Without JavaScript it's still one tap to select the whole address."""
    a = html.escape(addr)
    shown = re.sub(r"(//|\.|/(?=.))", r"\1<wbr>", a)   # on a narrow phone it breaks at the dots, not mid-word
    return (f'<button type="button" class="copy" data-copy="{a}" title="Copy to clipboard">'
            f'<code>{shown}</code><span class="ck">Copy</span></button>')




def bay_tile(b: dict, user: str, groups: set[str]) -> str:
    name, addr, app = b.get("name", ""), b.get("address", ""), b.get("app", "")
    if not addr:
        state, label = "closed", "Not open yet"
    elif b.get("external"):
        state, label = "ext", "Off-station"
    elif b.get("need") and b["need"] not in groups and user not in b.get("also", []):
        state, label = "nopass", "Not on your pass"
    else:
        st = STATUS.get(b.get("probe", ""), "unknown") if b.get("probe") else "up"
        state, label = {"up": ("up", "Active"), "down": ("down", "Technical difficulties")}.get(st, ("wait", "Checking ..."))
    a = copy_address(addr) if addr else ""
    bay = b.get("bay", "")
    door = (f'<a class="enter" href="{html.escape(STATION_BAY + bay)}">Enter {html.escape(name)}</a>'
            if re.fullmatch(r"[a-z]{2,12}", bay) and state not in ("closed", "nopass") else "")
    return (f'<div class="bay {state}"><div class="bh"><b>{html.escape(name)}</b><span class="st">{label}</span></div>'
            f'{f"<div class=app>{html.escape(app)}</div>" if app else ""}{door}{a}<p>{html.escape(b.get("how", ""))}</p></div>')


def directory(user: str, groups: set[str]) -> str:
    bays = load_bays()
    tiles = "".join(bay_tile(b, user, groups) for b in bays)
    d, c = DOCKYARD, COMMAND_DECK
    yours = sum(1 for b in bays if b.get("address") and not (b.get("need") and b["need"] not in groups and user not in b.get("also", [])))
    summary = f"{yours} of {len(bays)} Bays on your pass · Command Deck always open"
    return fold("baysfold", "The Bays", summary, f'<p class="note">ENTER opens that Bay&#39;s own page on the concourse. Tap an address to copy it into a phone or TV app. In a browser, just use '
            f'<a href="{d["address"]}">{html.escape(d["name"])}</a>.</p><div class="grid">{tiles}</div>'
            f'<div class="bay deck"><div class="bh"><b>{c["name"]}*</b><span class="st">Always open</span></div>'
            f'{copy_address(c["address"])}<p>* {html.escape(c["how"])}</p></div>')


# ---------------------------------------------------------------- username change requests

def forms_post(url: str, pairs: list[tuple[str, str]], ip: str) -> int:
    """Posts one submission to a cobra-forms form, as this page. Returns the HTTP status (0: no answer)."""
    u = urllib.parse.urlsplit(url)
    try:
        c = http.client.HTTPConnection(u.hostname, u.port or 80, timeout=TIMEOUT)
        c.request("POST", u.path or "/", urllib.parse.urlencode(pairs).encode(), {
            "Content-Type": "application/x-www-form-urlencoded",
            "Origin": ORIGIN, "Referer": ORIGIN + "/",       # the form's allowed origin is this page
            "X-Real-IP": ip,                                  # cobra-forms' per-address limit counts the visitor, not us
        })
        r = c.getresponse()
        r.read()
        c.close()
        return r.status
    except OSError as e:
        log(f"forms {url}: unreachable: {e}")
        return 0


def send_rename_request(user: str, wanted: str, note: str, groups: set[str], ip: str) -> tuple[bool, str]:
    """Hands a username-change request to cobra-forms, which emails it to Eels and keeps a copy in its inbox.
    Usernames are changed by hand (each app keeps its own copy of the name), so this only asks; nothing is renamed."""
    status = forms_post(FORMS, [
        ("Current username", user),
        ("Wanted username", wanted),
        ("Note", note or "(none)"),
        ("Groups", ", ".join(sorted(groups)) or "(none)"),
        ("Rename it in", "Authelia users.yml (script 11), then Jellyfin, Navidrome, Audiobookshelf, Kavita, RomM, Calibre-Web"),
    ], ip)
    if not status:
        return False, "The request couldn't be sent just now (the forms service didn't answer). Please try again later, or tell Eels."

    if status in (302, 303):
        log(f"rename request {user} -> {wanted!r}: sent (from {ip})")
        return True, f"Sent. Eels will rename you to “{wanted}” by hand and let you know. Until then, keep signing in as {user}."
    log(f"rename request {user}: forms answered {status}")
    if status == 429:
        return False, "Too many requests from your connection this hour. Please try again later."
    return False, f"The request wasn't accepted (forms answered {status}). Tell Eels."


# ---------------------------------------------------------------- access requests (the public "Request access")

REQ_LOCK = threading.Lock()


def load_requests() -> list[dict]:
    """The waiting requests, oldest first. A request nobody answered in 30 days is dropped (its hash with it)."""
    try:
        reqs = json.loads(REQUESTS_FILE.read_text())
    except (OSError, ValueError):
        return []
    now = time.time()
    return [r for r in reqs
            if now - r.get("at", 0) < (RESET_DAYS if r.get("kind") == "reset" else 30) * 86400]


def save_requests(reqs: list[dict]) -> None:
    tmp = REQUESTS_FILE.with_name(REQUESTS_FILE.name + ".new")
    tmp.write_text(json.dumps(reqs, indent=1) + "\n")
    os.chmod(tmp, 0o600)
    os.replace(tmp, REQUESTS_FILE)


def load_resync() -> set[str]:
    """People whose reset was approved: the gate has their new password, the apps don't yet."""
    try:
        return set(json.loads(RESYNC_FILE.read_text()))
    except (OSError, ValueError):
        return set()


def set_resync(user: str, waiting: bool) -> None:
    names = load_resync()
    if (user in names) == waiting:
        return
    names = names | {user} if waiting else names - {user}
    tmp = RESYNC_FILE.with_name(RESYNC_FILE.name + ".new")
    tmp.write_text(json.dumps(sorted(names)) + "\n")
    os.chmod(tmp, 0o600)
    os.replace(tmp, RESYNC_FILE)


def load_setup() -> set[str]:
    """People Eels approved whose Bay accounts aren't made yet (names only)."""
    try:
        return set(json.loads(SETUP_FILE.read_text()))
    except (OSError, ValueError):
        return set()


SETUP_LOCK = threading.Lock()                   # Approve (REQ_LOCK) and Finish your pass (LOCK) both write setup.json


def set_setup(user: str, waiting: bool) -> None:
    with SETUP_LOCK:
        names = load_setup()
        if (user in names) == waiting:
            return
        names = names | {user} if waiting else names - {user}
        tmp = SETUP_FILE.with_name(SETUP_FILE.name + ".new")
        tmp.write_text(json.dumps(sorted(names)) + "\n")
        os.chmod(tmp, 0o600)
        os.replace(tmp, SETUP_FILE)


def username_problem(name: str) -> str:
    """Empty string = free and well-formed. Taken means in the users file or already asked for."""
    if not USER_RE.match(name):
        return "Use 2 to 32 lowercase letters, numbers, dots, dashes or underscores (no spaces)."
    if name in users_in_file() or any(r["username"] == name and r.get("kind", "join") == "join" for r in load_requests()):
        return "That username is taken. Please pick another."
    return ""


def tell_eels_access(req: dict, ip: str) -> bool:
    """A short note to Eels through cobra-forms (email, or forms.songofeo.com/inbox). Never the password."""
    if not FORMS_ACCESS:
        return False
    status = forms_post(FORMS_ACCESS, [
        ("Name", req["name"]), ("Wanted username", req["username"]), ("Contact", req["contact"]),
        ("Note", req["note"] or "(none)"),
        ("Answer it", ORIGIN + "/  (your Multi-Pass: Access requests -> Approve or Decline)"),
    ], ip)
    if status not in (302, 303):
        log(f"access request {req['username']}: forms answered {status or 'nothing'} (it still waits on the Multi-Pass)")
    return status in (302, 303)


def tell_eels_reset(req: dict, ip: str) -> bool:
    """A short note to Eels that a reset is waiting. Never the password. Uses the same cobra-forms "access" form."""
    if not FORMS_ACCESS:
        return False
    status = forms_post(FORMS_ACCESS, [
        ("Name", req["name"]), ("Wanted username", req["username"] + "  (FORGOT PASSWORD: a reset, not a new pass)"),
        ("Contact", req["contact"]), ("Note", req["note"] or "(none)"),
        ("Answer it", ORIGIN + "/  (your Multi-Pass: Access requests. Check it's really them first, by a number you already have)"),
    ], ip)
    if status not in (302, 303):
        log(f"reset request {req['username']}: forms answered {status or 'nothing'} (it still waits on the Multi-Pass)")
    return status in (302, 303)


# ---------------------------------------------------------------- user stats
#
# Each person's own numbers, per Bay, for the Multi-Pass's stats fold and the concourse's bay windows.
# READ-ONLY: every call below is a GET. The apps' admin keys read Jellyfin, Audiobookshelf, Kavita and RomM;
# the three Navidromes are asked AS the signed-in person (the same Remote-User header the gate sends them,
# which they trust from the gate only), so they answer with that person's own plays and stars.
# Nobody can ask for someone else's numbers: /api/stats always uses the Remote-User Authelia vouched for.
#
# A report is {bay: {"tiles": [{n, label}], "bars": [{title, unit, parts: [{name, value}]}], "facts": [{label, value}],
#                    "lists": [{title, unit, items: [{name, value}]}]}}.
# Estimated numbers say "(estimate)" in their label.

STATS: dict[str, tuple[float, dict]] = {}       # username -> (when, report): asked of the apps at most every 10 minutes
STATS_TTL = 600
BAY_ORDER = [("tv", "Television"), ("music", "Music"), ("audiobooks", "Audiobooks"), ("talk", "Talk Radio & Comedy Club"),
             ("archives", "The Archives"), ("arcade", "Arcade"), ("comics", "Comics (Kavita)"),
             ("library", "Library (Kavita Books)"), ("rpg", "RPG Vault (Kavita)")]
ANIMATION = re.compile(r"\b(animation|anime|animated|cartoon)", re.I)


def _top(counter: dict, n: int = 6, by_name: bool = False) -> list[dict]:
    """The n biggest parts, the rest folded into Other; zero and empty names dropped. by_name puts the kept
    parts in name order (decades read best oldest first)."""
    items = sorted(((k, v) for k, v in counter.items() if k and v > 0), key=lambda kv: -kv[1])
    kept = sorted(items[:n]) if by_name else items[:n]
    parts = [{"name": k, "value": round(v)} for k, v in kept]
    rest = sum(v for _, v in items[n:])
    if rest > 0:
        parts.append({"name": "Other", "value": round(rest)})
    return parts


def _bar(title: str, unit: str, counter: dict, n: int = 6, by_name: bool = False) -> dict | None:
    parts = _top(counter, n, by_name)
    return {"title": title, "unit": unit, "parts": parts} if parts else None


def _decade(year) -> str:
    try:
        y = int(year)
    except (TypeError, ValueError):
        return ""
    return f"{y // 10 * 10}s" if 1880 < y < 2100 else ""


def _streak(days: list[str]) -> int:
    """Longest run of consecutive dates (YYYY-MM-DD)."""
    import datetime as dt
    ds = sorted({dt.date.fromisoformat(d) for d in days if re.fullmatch(r"\d{4}-\d{2}-\d{2}", d or "")})
    best = run = 0
    prev = None
    for d in ds:
        run = run + 1 if prev and (d - prev).days == 1 else 1
        best, prev = max(best, run), d
    return best


def _report(tiles, bars, facts, lists=()) -> dict:
    return {"tiles": [t for t in tiles if t], "bars": [b for b in bars if b],
            "facts": [f for f in facts if f and f.get("value") not in (None, "")],
            "lists": [x for x in lists if x and x.get("items")]}


def _ranked(title: str, unit: str, counter: dict, n: int = 10) -> dict | None:
    """A top-n list: [{name, value}], biggest first."""
    items = sorted(((k, v) for k, v in counter.items() if k and v > 0), key=lambda kv: -kv[1])[:n]
    return {"title": title, "unit": unit, "items": [{"name": k, "value": round(v)} for k, v in items]} if items else None


def _jellyfin_report(app: "Jellyfin", user: str) -> tuple[dict, dict]:
    uid = app.find(user)
    if not uid:
        return {}, {}
    h = app._h()
    q = ("Recursive=true&IncludeItemTypes=Movie,Episode&Filters=IsPlayed&EnableImages=false&EnableUserData=true"
         "&Fields=Genres,RunTimeTicks,ProductionYear,OfficialRating,SeriesName,Studios,People")
    items = (app.http.call("GET", f"/Users/{uid}/Items?{q}", headers=h) or {}).get("Items", [])
    count = lambda f: (app.http.call("GET", f"/Users/{uid}/Items?Recursive=true&IncludeItemTypes=Movie,Series,Episode&Filters={f}&Limit=0", headers=h) or {}).get("TotalRecordCount")
    favs, resumable = count("IsFavorite"), count("IsResumable")
    mins = lambda it: (it.get("RunTimeTicks") or 0) / 600_000_000
    films = [i for i in items if i.get("Type") == "Movie"]
    eps = [i for i in items if i.get("Type") == "Episode"]
    plays = lambda it: max(1, (it.get("UserData") or {}).get("PlayCount") or 1)
    total_min = sum(mins(i) * plays(i) for i in items)
    anim_min = sum(mins(i) * plays(i) for i in items if any(ANIMATION.search(g or "") for g in i.get("Genres") or []))
    genres, decades, ratings, series, studios = {}, {}, {}, {}, {}
    actors, directors, writers = {}, {}, {}   # from each title's cast and crew, weighted by your minutes watching it
    for i in items:
        m = mins(i) * plays(i)
        for person in i.get("People") or []:
            role = (person.get("Type") or "").lower()
            name = person.get("Name")
            if not name:
                continue
            book = actors if role in ("actor", "gueststar") else directors if role == "director" else writers if role == "writer" else None
            if book is not None:
                book[name] = book.get(name, 0) + m
        for g in i.get("Genres") or []:
            genres[g] = genres.get(g, 0) + m
        d = _decade(i.get("ProductionYear"))
        decades[d] = decades.get(d, 0) + 1
        r = i.get("OfficialRating") or "Not rated"
        ratings[r] = ratings.get(r, 0) + 1
        if i.get("SeriesName"):
            series[i["SeriesName"]] = series.get(i["SeriesName"], 0) + 1
        for s in (i.get("Studios") or [])[:1]:
            nm = s.get("Name") if isinstance(s, dict) else s
            studios[nm] = studios.get(nm, 0) + m
    all_plays = sum(plays(i) for i in items)
    rewatched = max(items, key=plays, default=None)
    fav_film = max(films, key=lambda f: (plays(f), (f.get("UserData") or {}).get("LastPlayedDate") or ""), default=None)
    top = lambda book: max(book, key=book.get) if book else ""
    longest = max(films, key=mins, default=None)
    oldest = min((i for i in items if i.get("ProductionYear")), key=lambda i: i["ProductionYear"], default=None)
    last = max((((i.get("UserData") or {}).get("LastPlayedDate") or ""), i.get("Name", "")) for i in items) if items else ("", "")
    top_series = max(series.items(), key=lambda kv: kv[1], default=None)
    report = _report(
        [{"n": round(total_min / 60), "label": "hours watched"},
         {"n": len(films), "label": "films"},
         {"n": len(eps), "label": "episodes"},
         {"n": len(series), "label": "series watched"},
         {"n": round(anim_min), "label": "minutes of animation"},
         {"n": all_plays - len(items), "label": "rewatches"},
         {"n": favs, "label": "favourites"},
         {"n": resumable, "label": "in progress"}],
        [_bar("Genres, by minutes watched", "min", genres),
         _bar("Decades, by titles watched", "titles", decades, 8, True),
         _bar("Films and episodes, by minutes", "min", {"Films": sum(mins(i) * plays(i) for i in films), "Episodes": sum(mins(i) * plays(i) for i in eps)}),
         _bar("Ratings, by titles watched", "titles", ratings, 5),
         _bar("Studios, by minutes watched", "min", studios, 5),
         _bar("Directors, by minutes watched", "min", directors, 5)],
        [{"label": "Favourite film", "value": f"{fav_film.get('Name')} ({plays(fav_film)} {'play' if plays(fav_film) == 1 else 'plays'})" if fav_film else ""},
         {"label": "Favourite genre", "value": top(genres)},
         {"label": "Most-watched actor", "value": f"{top(actors)} ({round(actors[top(actors)])} min)" if actors else ""},
         {"label": "Most-watched director", "value": top(directors)},
         {"label": "Most-watched writer", "value": top(writers)},
         {"label": "Most-watched series", "value": f"{top_series[0]} ({top_series[1]} episodes)" if top_series else ""},
         {"label": "Most rewatched", "value": f"{rewatched.get('Name')} ({plays(rewatched)} plays)" if rewatched and plays(rewatched) > 1 else ""},
         {"label": "Longest film watched", "value": f"{longest.get('Name')} ({round(mins(longest))} min)" if longest else ""},
         {"label": "Oldest title watched", "value": f"{oldest.get('Name')} ({oldest.get('ProductionYear')})" if oldest else ""},
         {"label": "Animation share", "value": f"{round(100 * anim_min / total_min)}% of your watching" if total_min else ""},
         {"label": "Last watched", "value": f"{last[1]} ({last[0][:10]})" if last[0] else ""}],
        [_ranked("Top films, by plays", "plays", {f.get("Name"): plays(f) for f in films}),
         _ranked("Top series, by episodes watched", "episodes", series),
         _ranked("Top actors, by minutes watched", "min", actors)])
    flat = {"tv_hours": round(total_min / 60), "films": len(films), "episodes": len(eps), "animation_minutes": round(anim_min)}
    return {"tv": report}, flat


# Which Audiobookshelf library is which Bay. Exact names (env, comma-separated, with these defaults) win.
# A fully anchored pattern is the fallback, so "Comedy Archives" is neither Talk nor The Archives.
# Anything still unmatched counts as Audiobooks. Keep the defaults in step with web/bays/window.js ABS_LIB
# and with the library names audiobookshelf.sh tells the owner to create.
_ABS_TALK_RE = r"^(?:talk radio(?: & comedy club)?|comedy(?: club)?)$"
_ABS_ARCHIVES_RE = r"^(?:the )?archives$"
_ABS_NAME_HINT = re.compile(r"talk|comedy|archive", re.I)


def _abs_name_set(env_key: str, default: str) -> set[str]:
    raw = os.environ.get(env_key, "").strip() or default
    return {part.strip().casefold() for part in raw.split(",") if part.strip()}


def abs_library_specs() -> tuple[list[tuple[str, set[str], re.Pattern]], list[str]]:
    """(bay, exact names, anchored pattern) for Talk and Archives, plus any setup warnings."""
    notes: list[str] = []

    def one(bay: str, env_names: str, default_names: str, env_re: str, default_re: str):
        raw = os.environ.get(env_re, "").strip()
        try:
            rx = re.compile(raw or default_re, re.I)
        except re.error:
            notes.append(f"WARN  setup  {env_re} is not a valid pattern; using the default")
            rx = re.compile(default_re, re.I)
        return bay, _abs_name_set(env_names, default_names), rx

    specs = [
        one("talk", "ABS_LIBRARY_TALK", "Talk Radio & Comedy Club", "ABS_LIBRARY_TALK_RE", _ABS_TALK_RE),
        one("archives", "ABS_LIBRARY_ARCHIVES", "The Archives", "ABS_LIBRARY_ARCHIVES_RE", _ABS_ARCHIVES_RE),
    ]
    return specs, notes


def match_abs_libraries(libs: list, specs: list | None = None) -> dict[str, dict]:
    """Bay -> library. Exact configured name first, then a full-name pattern. Each library is used once."""
    if specs is None:
        specs, _ = abs_library_specs()
    used: set = set()
    out: dict[str, dict] = {}
    for bay, names, rx in specs:
        exact = fuzzy = None
        for lib in libs:
            lid = lib.get("id")
            if not lid or lid in used:
                continue
            name = (lib.get("name") or "").strip()
            if name.casefold() in names and exact is None:
                exact = lib
            elif fuzzy is None and rx.fullmatch(name):
                fuzzy = lib
        hit = exact or fuzzy
        if hit:
            used.add(hit["id"])
            out[bay] = hit
    return out


def _abs_bay_items(app: "Audiobookshelf", h: dict) -> dict[str, set]:
    """READ-ONLY. Item ids per Bay library (talk, archives). Missing libraries are left out."""
    out: dict[str, set] = {}
    libs = (app.http.call("GET", "/api/libraries", headers=h) or {}).get("libraries") or []
    for bay, lib in match_abs_libraries(libs).items():
        r = app.http.call("GET", f"/api/libraries/{lib['id']}/items?minified=1&limit=0", headers=h) or {}
        out[bay] = {it.get("id") for it in r.get("results") or []}
    return out


def _abs_listen_report(prog: list, items: list, hours: float, finished_label: str = "finished",
                       extra_tiles=(), extra_bars=(), extra_facts=()) -> dict:
    """One Bay's report from its share of the person's Audiobookshelf progress and listening items."""
    finished = sum(1 for p in prog if p.get("isFinished") and p.get("mediaItemType", "book") == "book")
    episodes = sum(1 for p in prog if p.get("isFinished") and p.get("mediaItemType") == "podcastEpisode")
    going = sum(1 for p in prog if not p.get("isFinished") and (p.get("progress") or 0) > 0)
    titles, authors, genres = {}, {}, {}
    for it in items:
        t = float(it.get("timeListening") or 0) / 60
        md = it.get("mediaMetadata") or {}
        titles[md.get("title") or "?"] = titles.get(md.get("title") or "?", 0) + t
        names = [a.get("name") for a in md.get("authors") or [] if isinstance(a, dict)] or ([md["authorName"]] if md.get("authorName") else [])
        for a in names[:2]:
            authors[a] = authors.get(a, 0) + t
        for g in md.get("genres") or []:
            genres[g] = genres.get(g, 0) + t
    return _report(
        [{"n": round(hours), "label": "hours listened"},
         {"n": finished, "label": finished_label},
         {"n": episodes, "label": "podcast episodes finished"},
         {"n": going, "label": "in progress"}, *extra_tiles],
        [*extra_bars, _bar("Genres, by minutes listened", "min", genres), _bar("Authors, by minutes listened", "min", authors, 5)],
        [{"label": "Most listened", "value": max(titles, key=titles.get) if titles else ""}, *extra_facts])


def _abs_report(app: "Audiobookshelf", user: str) -> tuple[dict, dict]:
    """READ-ONLY. Audiobooks, Talk Radio & Comedy Club and The Archives all live in this one Audiobookshelf: the person's
    progress and listening are split by library, so each Bay gets its own numbers."""
    uid = app.find(user)
    if not uid:
        return {}, {}
    h = app._h()
    u = app.http.call("GET", f"/api/users/{uid}", headers=h) or {}
    prog = u.get("mediaProgress", []) if isinstance(u, dict) else []
    try:
        ls = app.http.call("GET", f"/api/users/{uid}/listening-stats", headers=h) or {}
    except Exception:
        ls = {}
    try:
        bay_items = _abs_bay_items(app, h)
    except Exception as e:
        log(f"stats {user}: Audiobookshelf libraries: {str(e)[:120]}")
        bay_items = {}
    listened = {iid: it for iid, it in (ls.get("items") or {}).items()}
    total = float(ls.get("totalTime") or 0)
    bays: dict = {}
    taken: set = set()
    for bay, ids in bay_items.items():
        b_prog = [p for p in prog if p.get("libraryItemId") in ids]
        b_items = [it for iid, it in listened.items() if iid in ids]
        secs = sum(float(it.get("timeListening") or 0) for it in b_items)
        taken |= ids
        bays[bay] = _abs_listen_report(b_prog, b_items, secs / 3600)
    a_prog = [p for p in prog if p.get("libraryItemId") not in taken]
    a_items = [it for iid, it in listened.items() if iid not in taken]
    a_total = max(0.0, total - sum(float(it.get("timeListening") or 0) for iid, it in listened.items() if iid in taken))
    days = {d: float(s or 0) for d, s in (ls.get("days") or {}).items()}
    week = {d: float(s or 0) / 60 for d, s in (ls.get("dayOfWeek") or {}).items()}
    busiest = max(days.items(), key=lambda kv: kv[1], default=None)
    listened_days = [d for d, s in days.items() if s > 0]
    # Days, streaks and weekdays come from Audiobookshelf as one total for the person, so they stay on Audiobooks
    # and count every library.
    bays["audiobooks"] = _abs_listen_report(
        a_prog, a_items, a_total / 3600, "audiobooks finished",
        extra_tiles=({"n": len(listened_days), "label": "days listened (all libraries)"},
                     {"n": _streak(listened_days), "label": "longest daily streak"},
                     {"n": round(total / 60 / len(listened_days)) if listened_days else None, "label": "minutes per listening day"},
                     {"n": round(float(ls.get("today") or 0) / 60), "label": "minutes today"}),
        extra_bars=(_bar("Weekdays, by minutes listened (all libraries)", "min", week, 7),),
        extra_facts=({"label": "Favourite weekday", "value": max(week, key=week.get) if week else ""},
                     {"label": "Biggest day", "value": f"{busiest[0]} ({round(busiest[1] / 60)} min)" if busiest and busiest[1] > 0 else ""}))
    finished = sum(1 for p in a_prog if p.get("isFinished") and p.get("mediaItemType", "book") == "book")
    flat = {"books_finished": finished, "listen_hours": round(a_total / 3600)}
    return bays, flat


def _navidrome_report(app: "Navidrome", user: str, bay: str) -> tuple[dict, dict]:
    """Asks this Navidrome as the person (Remote-User, trusted from the gate only). GETs only.
    Song by song where Navidrome lists them (search3 with an empty query, up to 10,000 songs), so plays and minutes
    are exact; album by album otherwise (minutes then marked as an estimate)."""
    hv = {"Remote-User": user}
    base = "v=1.16.1&c=eo-account&f=json"

    def sub(method: str, extra: str = "") -> dict:
        r = (app.http.call("GET", f"/rest/{method}?{base}{extra}", headers=hv) or {}).get("subsonic-response", {})
        if r.get("status") != "ok":
            raise RuntimeError((r.get("error") or {}).get("message", "Navidrome said no"))
        return r
    songs = []
    try:
        for off in range(0, 10000, 500):
            page = (sub("search3", f"&query=&artistCount=0&albumCount=0&songCount=500&songOffset={off}").get("searchResult3") or {}).get("song") or []
            songs += page
            if len(page) < 500:
                break
    except Exception:
        songs = []
    starred = sub("getStarred2").get("starred2") or {}
    lists = (sub("getPlaylists").get("playlists") or {}).get("playlist") or []
    recent = (sub("getAlbumList2", "&type=recent&size=1").get("albumList2") or {}).get("album") or []
    genres, decades, artists, albums, tracks, years = {}, {}, {}, {}, {}, {}
    names = lambda x: [g.get("name") for g in x.get("genres") or [] if isinstance(g, dict)] or [x.get("genre")]
    played_songs = [t for t in songs if (t.get("playCount") or 0) > 0]
    if played_songs:
        exact = True
        plays = sum(t["playCount"] for t in played_songs)
        minutes = sum(t["playCount"] * (t.get("duration") or 0) for t in played_songs) / 60
        for t in played_songs:
            p = t["playCount"]
            who = t.get("albumArtist") or t.get("artist") or "?"
            for g in names(t):
                if g:
                    genres[g] = genres.get(g, 0) + p
            d = _decade(t.get("year"))
            decades[d] = decades.get(d, 0) + p
            artists[who] = artists.get(who, 0) + p
            alb = f"{t.get('album') or '?'} — {who}"
            albums[alb] = albums.get(alb, 0) + p
            tracks[f"{t.get('title') or '?'} — {t.get('artist') or who}"] = p
            if t.get("year"):
                years[t["year"]] = years.get(t["year"], 0) + p
        album_count = len({t.get("albumId") or t.get("album") for t in played_songs})
    else:                                       # album by album: Navidrome didn't list songs
        exact = False
        alist = []
        for off in range(0, 2000, 500):
            page = (sub("getAlbumList2", f"&type=frequent&size=500&offset={off}").get("albumList2") or {}).get("album") or []
            alist += page
            if len(page) < 500:
                break
        played = [x for x in alist if (x.get("playCount") or 0) > 0]
        plays = sum(x["playCount"] for x in played)
        minutes = sum(x["playCount"] * (x.get("duration") or 0) / max(1, x.get("songCount") or 1) for x in played) / 60
        for x in played:
            p = x["playCount"]
            who = x.get("albumArtist") or x.get("artist") or "?"
            for g in names(x):
                if g:
                    genres[g] = genres.get(g, 0) + p
            d = _decade(x.get("year"))
            decades[d] = decades.get(d, 0) + p
            artists[who] = artists.get(who, 0) + p
            albums[f"{x.get('name') or '?'} — {who}"] = albums.get(f"{x.get('name') or '?'} — {who}", 0) + p
            if x.get("year"):
                years[x["year"]] = years.get(x["year"], 0) + p
        album_count = len(played)
    top = lambda book: max(book, key=book.get) if book else ""
    oldest = min(years) if years else None
    report = _report(
        [{"n": plays, "label": "plays"},
         {"n": round(minutes), "label": "minutes listened" if exact else "minutes listened (estimate)"},
         {"n": len(played_songs) if exact else None, "label": "songs played"},
         {"n": album_count, "label": "albums played"},
         {"n": len(artists), "label": "album artists played"},
         {"n": len(genres), "label": "genres played"},
         {"n": len(starred.get("song") or []), "label": "favourite tracks"},
         {"n": len(starred.get("album") or []), "label": "favourite albums"},
         {"n": len(lists), "label": "playlists"},
         {"n": round(minutes / plays, 1) if plays else None, "label": "minutes per play"}],
        [_bar("Genres, by plays", "plays", genres),
         _bar("Album artists, by plays", "plays", artists, 6),
         _bar("Decades, by plays", "plays", decades, 8, True)],
        [{"label": "Favourite song", "value": f"{top(tracks)} ({tracks[top(tracks)]} plays)" if tracks else ""},
         {"label": "Favourite album", "value": f"{top(albums)} ({albums[top(albums)]} plays)" if albums else ""},
         {"label": "Favourite album artist", "value": f"{top(artists)} ({artists[top(artists)]} plays)" if artists else ""},
         {"label": "Favourite genre", "value": top(genres)},
         {"label": "Favourite year", "value": str(top(years)) if years else ""},
         {"label": "Oldest music played", "value": str(oldest) if oldest else ""},
         {"label": "Last played album", "value": f"{recent[0].get('name')} by {recent[0].get('artist')}" if recent else ""}],
        [_ranked("Top songs, by plays", "plays", tracks),
         _ranked("Top albums, by plays", "plays", albums)])
    return {bay: report}, {f"{bay}_plays": plays, f"{bay}_minutes": round(minutes)}


def _kavita_report(app: "Kavita", user: str) -> tuple[dict, dict]:
    uid = app.find(user)
    if not uid:
        return {}, {}
    r = app.http.call("GET", f"/api/Stats/user/{uid}/read", headers=app._h()) or {}
    flat = {"chapters": int(r.get("chaptersRead") or 0), "pages": int(r.get("totalPagesRead") or 0),
            "read_hours": round(float(r.get("timeSpentReading") or 0))}
    report = _report([{"n": flat["chapters"], "label": "chapters read"}, {"n": flat["pages"], "label": "pages read"},
                      {"n": flat["read_hours"], "label": "hours reading"},
                      {"n": round(flat["pages"] / flat["read_hours"]) if flat["read_hours"] else None, "label": "pages per hour"}], [], [])
    bay = getattr(app, "stats_bay", "comics")
    # Comics keeps the plain keys the hourly record and older pages read; the other two Kavitas prefix theirs.
    return {bay: report}, (flat if bay == "comics" else {f"{bay}_{k}": v for k, v in flat.items()})


def _romm_report(app: "RomM", user: str) -> tuple[dict, dict]:
    """RomM keeps play data per person only for the person signed in, so these are the whole cabinet's numbers."""
    s = app.http.call("GET", "/api/stats", headers=app._h()) or {}
    plats = app.http.call("GET", "/api/platforms", headers=app._h()) or []
    per = {p.get("display_name") or p.get("name"): p.get("rom_count") or 0 for p in plats if isinstance(p, dict)}
    gb = round(float(s.get("TOTAL_FILESIZE_BYTES") or s.get("FILESIZE") or 0) / 1e9, 1)
    report = _report(
        [{"n": s.get("ROMS"), "label": "games in the cabinet"}, {"n": s.get("PLATFORMS"), "label": "systems"},
         {"n": s.get("SAVES"), "label": "saves (whole cabinet)"}, {"n": s.get("STATES"), "label": "save states (whole cabinet)"},
         {"n": gb or None, "label": "GB of games"}],
        [_bar("Systems, by games", "games", per)], [])
    return {"arcade": report}, {}


def user_stats(user: str) -> dict:
    """READ-ONLY. The person's report per Bay, plus the flat numbers the hourly record and older pages use.
    An app that's down or not set up leaves its Bay out; the rest still answer."""
    hit = STATS.get(user)
    if hit and time.time() - hit[0] < STATS_TTL:
        return hit[1]
    bays: dict = {}
    flat: dict = {}
    for app in load_apps():
        try:
            if isinstance(app, Jellyfin):
                b, f = _jellyfin_report(app, user)
            elif isinstance(app, Audiobookshelf):
                b, f = _abs_report(app, user)
            elif isinstance(app, Navidrome):
                b, f = _navidrome_report(app, user, "music")
            elif isinstance(app, Kavita):
                b, f = _kavita_report(app, user)
            elif isinstance(app, RomM):
                b, f = _romm_report(app, user)
            else:
                continue
            bays.update(b)
            flat.update(f)
        except Exception as e:
            log(f"stats {user}: {app.title}: {str(e)[:120]}")
    out = dict(flat)
    out["bays"] = {k: bays[k] for k, _ in BAY_ORDER if k in bays}
    out["names"] = dict(BAY_ORDER)
    out["taken"] = time.strftime("%Y-%m-%dT%H:%M:%S")
    STATS[user] = (time.time(), out)
    return out


STATS_DB = APPS_FILE.parent / "user-stats.sqlite"   # one row per person per day; in /data, so the nightly backup has it


def record_stats() -> None:
    """Every hour: today's flat numbers for every station user, kept in user-stats.sqlite (the day's last reading wins).
    The nightly personal-state backup (script 40) copies /data, so these sit with everyone's favorites and playlists."""
    import sqlite3
    while True:
        try:
            db = sqlite3.connect(STATS_DB, timeout=30)
            db.execute("create table if not exists daily (user text, day text, stats text, taken text, primary key (user, day))")
            day = time.strftime("%Y-%m-%d")
            for u in users_in_file():
                STATS.pop(u, None)
                numbers = {k: v for k, v in user_stats(u).items() if isinstance(v, (int, float))}
                if numbers:
                    db.execute("insert or replace into daily values (?, ?, ?, ?)",
                               (u, day, json.dumps(numbers, sort_keys=True), time.strftime("%Y-%m-%dT%H:%M:%S")))
            db.commit()
            db.close()
        except Exception as e:
            log(f"stats recording: {str(e)[:160]}")
        time.sleep(3600)


def stats_block() -> str:
    """One folded bar; inside it, one fold per Bay (filled in by app.js from /api/stats), so nothing shows until asked for."""
    return ('<section class="sec"><details class="fold" id="statsfold">'
            '<summary><span class="ft">Your stats</span><span class="fs" id="statsum">Loading…</span>'
            '<span class="chev" aria-hidden="true"></span></summary>'
            '<div class="fbody"><div id="stats" class="baystats" aria-live="polite"></div>'
            '<p class="note">Your own numbers only, read from each Bay\'s app. Estimates say so. '
            'The Arcade\'s numbers are the whole cabinet\'s. They refresh every 10 minutes.</p></div>'
            '</details></section>')


# ---------------------------------------------------------------- the page

PAGE = """<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Concourse Multi-pass</title>
<link rel="stylesheet" href="/ff/ff.css"><link rel="stylesheet" href="/look.css">
<style>
body{{margin:0;min-height:100vh;display:grid;place-items:start center;background:#0b0d12;color:#e8e4d8;font:16px/1.5 system-ui,sans-serif}}
main{{width:min(96vw,52rem);margin:1.5rem 0 3rem;padding:1.6rem;border:1px solid #6b5a2a;border-radius:14px;background:#12151c;box-sizing:border-box}}
a{{color:#e0b84c}}
h1{{margin:0;font-size:1.45rem;color:#e0b84c;letter-spacing:.1em;text-transform:uppercase}}
h2{{margin:0 0 .6rem;font-size:.85rem;color:#e0b84c;letter-spacing:.14em;text-transform:uppercase}}
.sec{{margin-top:1.8rem}}.who{{margin:.35rem 0 0;color:#a9a39a}}.who b{{color:#e8e4d8;font-size:1.1rem}}
.note{{color:#a9a39a;font-size:.88rem}}.bad{{color:#ff8a8a}}.ok{{color:#8fdc8f}}.skip{{color:#a9a39a}}.fail{{color:#ff8a8a}}ul{{padding-left:1.2rem}}
.stats{{display:grid;grid-template-columns:repeat(auto-fill,minmax(8rem,1fr));gap:.6rem}}
.stat{{border:1px solid #2a2d36;border-radius:10px;padding:.7rem .8rem;background:#0b0d12}}.stat b{{display:block;font-size:1.6rem;line-height:1.1;color:#e8e4d8}}
.stat span{{display:block;font-size:.85rem}}.baystats{{display:grid;gap:.5rem}}.bayfold{{border:1px solid #2a2d36;border-radius:10px;background:#0b0d12}}.bayfold>summary{{list-style:none;display:flex;flex-wrap:wrap;align-items:baseline;gap:.2rem .8rem;padding:.65rem .8rem;cursor:pointer;border-radius:10px}}.bayfold>summary::-webkit-details-marker{{display:none}}.bayfold>summary:hover,.bayfold>summary:focus-visible{{outline:none;background:#151922}}.bayfold>summary b{{color:#e0b84c;font-size:.9rem;letter-spacing:.08em;text-transform:uppercase}}.bayfold>summary span{{font-size:.85rem;color:#a9a39a}}.baybody{{padding:0 .8rem .9rem;display:grid;gap:.9rem}}.sbar h4{{margin:0 0 .35rem;font-size:.78rem;color:#e0b84c;letter-spacing:.1em;text-transform:uppercase}}.sbar .strip{{display:flex;height:.8rem;border-radius:4px;overflow:hidden;border:1px solid #05060a}}.sbar .strip span{{display:block;height:100%}}.sbar .legend{{list-style:none;margin:.45rem 0 0;padding:0;display:grid;grid-template-columns:repeat(auto-fill,minmax(12rem,1fr));gap:.2rem .8rem;font-size:.8rem}}.sbar .legend li{{display:flex;align-items:center;gap:.4rem;min-width:0}}.sbar .legend i{{flex:none;width:.6rem;height:.6rem;border-radius:2px}}.sbar .legend b{{min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;color:#e8e4d8;font-weight:600}}.sbar .legend span{{flex:none;margin-left:auto;color:#a9a39a}}.more{{border-top:1px dashed #2a2d36;padding-top:.4rem}}.more>summary{{list-style:none;display:flex;flex-wrap:wrap;align-items:baseline;gap:.2rem .7rem;cursor:pointer;padding:.35rem 0}}.more>summary::-webkit-details-marker{{display:none}}.more>summary b{{color:#e0b84c;font-size:.8rem;letter-spacing:.1em;text-transform:uppercase}}.more>summary b::after{{content:" ▸"}}.more[open]>summary b::after{{content:" ▾"}}.more>summary span{{font-size:.8rem;color:#a9a39a}}.more>summary:focus-visible{{outline:2px solid #e0b84c;outline-offset:2px}}.more>.baybody{{padding:.4rem 0 0}}.ranks{{display:grid;grid-template-columns:repeat(auto-fit,minmax(15rem,1fr));gap:.9rem 1.2rem}}.rank h4{{margin:0 0 .35rem;font-size:.78rem;color:#e0b84c;letter-spacing:.1em;text-transform:uppercase}}.rank ol{{margin:0;padding-left:1.4rem;display:grid;gap:.15rem;font-size:.82rem}}.rank li{{padding-left:.2rem}}.rank li::marker{{color:#6b5a2a;font-weight:700}}.rank li b{{display:inline-block;max-width:calc(100% - 6rem);overflow:hidden;text-overflow:ellipsis;white-space:nowrap;vertical-align:bottom;color:#e8e4d8;font-weight:600}}.rank li span{{float:right;color:#a9a39a}}.facts{{display:grid;grid-template-columns:minmax(8rem,auto) 1fr;gap:.25rem .8rem;margin:0;font-size:.85rem}}.facts dt{{color:#a9a39a}}.facts dd{{margin:0;color:#e8e4d8;overflow-wrap:anywhere}}.stat i{{display:block;font-style:normal;font-size:.72rem;color:#a9a39a;text-transform:uppercase;letter-spacing:.06em;margin-top:.15rem}}
.fold{{border:1px solid #6b5a2a;border-radius:12px;background:#0f1218}}.fold>summary{{list-style:none;display:flex;align-items:center;gap:.8rem;padding:.8rem 1rem;cursor:pointer;border-radius:12px}}.fold>summary::-webkit-details-marker{{display:none}}.fold>summary:hover,.fold>summary:focus-visible{{outline:none;background:#171b24}}.fold .ft{{flex:none;font-size:.85rem;font-weight:700;color:#e0b84c;letter-spacing:.14em;text-transform:uppercase}}.fold .fs{{flex:1;min-width:0;font-size:.88rem;color:#a9a39a;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}}.fold .chev{{flex:none;width:.55rem;height:.55rem;border-right:2px solid #e0b84c;border-bottom:2px solid #e0b84c;transform:rotate(45deg);transition:transform .2s}}.fold[open] .chev{{transform:rotate(-135deg)}}.fold .fbody{{padding:0 1rem 1rem}}.fold .fbody .note{{margin-bottom:0}}@media (prefers-reduced-motion:reduce){{.fold .chev{{transition:none}}}}
.out{{border-top:1px solid #2a2d36;padding-top:1.4rem;text-align:center}}a.signout{{display:inline-block;padding:.75rem 2.2rem;border:1px solid #c1121f;border-radius:10px;color:#ff8a8a;font-weight:700;letter-spacing:.08em;text-transform:uppercase;text-decoration:none}}a.signout:hover,a.signout:focus-visible{{background:#c1121f;color:#fff;outline:none}}
a.podlink{{display:inline-block;margin:.2rem 0 .8rem;padding:.7rem 1.2rem;border:1px solid #e0b84c;border-radius:10px;color:#e0b84c;font-weight:700;letter-spacing:.06em;text-decoration:none;text-transform:uppercase}}a.podlink:hover,a.podlink:focus-visible{{background:#e0b84c;color:#1a1205;outline:none}}
button.podnew{{margin:.2rem 0 .6rem;padding:.7rem 1.2rem;border:1px solid #e0b84c;border-radius:10px;background:transparent;color:#e0b84c;font:700 .95rem system-ui,sans-serif;letter-spacing:.06em;text-transform:uppercase;cursor:pointer}}button.podnew:hover,button.podnew:focus-visible{{background:#e0b84c;color:#1a1205;outline:none}}
.grid{{display:grid;grid-template-columns:1fr 1fr;gap:.6rem}}.bay{{border:1px solid #2a2d36;border-left:4px solid #555;border-radius:10px;padding:.6rem .7rem;background:#0b0d12;min-width:0}}.bay .bh{{display:flex;justify-content:space-between;gap:.4rem;align-items:baseline;flex-wrap:wrap}}.bay .st{{font-size:.72rem;font-weight:700;text-transform:uppercase;letter-spacing:.06em}}.bay .app{{font-size:.8rem;color:#a9a39a}}.bay code{{font-size:.85rem;color:#e8e4d8}}.bay p{{margin:.2rem 0 0;font-size:.8rem;color:#a9a39a}}.bay.up{{border-left-color:#3fa34d}}.bay.up .st{{color:#8fdc8f}}.bay.down{{border-left-color:#c1121f}}.bay.down .st{{color:#ff8a8a}}.bay.nopass,.bay.closed{{opacity:.6}}.bay.ext .st,.bay.wait .st{{color:#a9a39a}}.bay.deck{{margin-top:.6rem;border-left-color:#e0b84c}}.bay.deck .st{{color:#e0b84c}}.bay a.enter{{display:block;margin:.4rem 0 .2rem;padding:.45rem .6rem;border:1px solid #6b5a2a;border-radius:6px;background:#e0b84c;color:#1a1205;font-weight:800;letter-spacing:.06em;text-align:center;text-decoration:none;text-transform:uppercase;font-size:.8rem}}.bay a.enter:hover,.bay a.enter:focus-visible{{background:#ffe08a}}
button.copy{{display:flex;flex-wrap:wrap;align-items:baseline;justify-content:space-between;column-gap:.5rem;width:100%;margin:.3rem 0;padding:.35rem .5rem;border:1px solid #333;border-radius:6px;background:#12151c;color:inherit;font:inherit;text-align:left;cursor:pointer}}button.copy code{{margin:0;flex:1 1 9rem;overflow-wrap:normal}}button.copy:hover,button.copy:focus-visible{{border-color:#e0b84c}}button.copy .ck{{flex:none;margin-left:auto;font-size:.7rem;font-weight:700;text-transform:uppercase;letter-spacing:.06em;color:#e0b84c}}button.copy.done{{border-color:#3fa34d}}button.copy.done .ck{{color:#8fdc8f}}
@media (max-width:30rem){{.bay p{{display:none}}main{{padding:1.1rem}}}}
.actions{{display:grid;gap:.7rem;max-width:30rem}}
.ff-start-btn,.act>button[type=submit],.ff-next-btn{{width:100%;padding:.85rem 1rem;border-radius:10px;font:700 1rem/1.2 system-ui,sans-serif;letter-spacing:.04em;cursor:pointer}}
.ff-start-btn{{border:1px solid #6b5a2a;background:#171b24;color:#e8e4d8}}.ff-start-btn:hover,.ff-start-btn:focus-visible{{border-color:#e0b84c;outline:none}}
.ff-start-btn.ff-denied{{background:#c1121f;border-color:#c1121f;color:#fff}}.ff-start-note{{margin:-.3rem 0 0;color:#ff8a8a;font-size:.9rem}}
.act>button[type=submit],.ff-next-btn{{margin-top:1rem;border:0;background:#c1121f;color:#fff}}.ff-next-btn{{background:#e0b84c;color:#0b0d12}}
.act{{--ff-accent:#e0b84c;--ff-ok:#3fa34d;--ff-bad:#ff8a8a;--ff-shade:transparent;border-radius:12px}}
.act.ff-expanded{{border:1px solid #6b5a2a;background:#0f1218;padding:1.1rem 1.2rem}}
.act label{{display:block;font-weight:600;font-size:1.05rem}}.act input{{width:100%;box-sizing:border-box;margin-top:.45rem;padding:.75rem;border-radius:8px;border:1px solid #444;background:#0b0d12;color:inherit;font:inherit}}
.signin{{display:block;box-sizing:border-box;width:100%;padding:.85rem 1rem;border-radius:10px;background:#e0b84c;color:#0b0d12;font:700 1rem/1.2 system-ui,sans-serif;letter-spacing:.04em;text-align:center;text-decoration:none}}.signin:hover,.signin:focus-visible{{background:#f0cc66}}
.signin.alt{{background:transparent;border:1px solid #6b5a2a;color:inherit}}.req.reset{{border-color:#c1121f}}.reqs{{display:grid;gap:.7rem}}.req{{border:1px solid #6b5a2a;border-radius:10px;padding:.8rem .9rem;background:#0b0d12}}.req p{{margin:0 0 .35rem}}
.req .row{{display:flex;flex-wrap:wrap;gap:.5rem 1rem;align-items:center;margin:.5rem 0}}.req input[type=text]{{padding:.45rem .55rem;border-radius:6px;border:1px solid #444;background:#12151c;color:inherit;font:inherit;width:12rem}}
.req button{{padding:.55rem 1rem;border-radius:8px;border:0;font:700 .95rem system-ui,sans-serif;cursor:pointer}}.req .yes{{background:#3fa34d;color:#fff}}.req .no{{background:#2a2d36;color:#e8e4d8;margin-left:.4rem}}
.act .ff-done-panel{{padding:1.2rem .5rem}}.ff-line-ok{{color:#8fdc8f}}.ff-line-skip{{color:#a9a39a}}.ff-line-fail{{color:#ff8a8a}}
</style><script src="/app.js" defer></script><script src="/ff/ff.js" defer></script></head><body class="{cls}"><main>{body}</main></body></html>"""


def theme_font(theme: str, font: str | None = None) -> str:
    f = font if font is not None else setting("fonts").get(theme, "")
    return f if f in THEME_FONTS[theme] else ""


def render(body: str, theme: str | None = None, palette: str | None = None, font: str | None = None) -> str:
    """The whole page around body, in the theme, palette and font the admin picked (or an admin's preview)."""
    t = theme if theme in THEMES else setting("theme")
    pal = palette if palette in PALETTES else str(setting("palette"))
    f = theme_font(t, font)
    cls = f"skin t-{t} p-{pal}" + (f" f-{f}" + (" f-body" if FONTS[f][2] else "") if f else "")
    return PAGE.format(body=body, cls=cls)


def fonts_css() -> str:
    """@font-face for every font, and the class that puts each one on the headings (and body, where it reads well).
    A browser only downloads a font a page actually uses."""
    out = []
    for k, (name, weight, _) in FONTS.items():
        out.append(f"@font-face{{font-family:'{name}';src:url(/fonts/{k}.woff2) format('woff2');font-weight:{weight};font-display:swap}}")
        out.append(f".f-{k}{{--fontpick:'{name}'}}")
    return "\n".join(out) + """
.skin[class*=" f-"] h1,.skin[class*=" f-"] h2,.skin[class*=" f-"] .adm h3,.skin[class*=" f-"] details.admin>summary>span,
.skin[class*=" f-"] .stat b,.skin[class*=" f-"] nav.jump a,.skin[class*=" f-"] .signin,.skin[class*=" f-"] .ff-start-btn,
.skin[class*=" f-"] .bay .bh b,.skin[class*=" f-"] .ff-next-btn,.skin[class*=" f-"] .act>button[type=submit]{font-family:var(--fontpick),var(--head,var(--font))}
body.skin.f-body{font-family:var(--fontpick),var(--font)}
.fontpick{display:none;grid-template-columns:repeat(auto-fill,minmax(10rem,1fr));gap:.45rem}
.font{position:relative;display:block;border:1px solid var(--line,#2a2d36);border-radius:8px;padding:.5rem .6rem;cursor:pointer}
.font input{position:absolute;opacity:0}.font b{display:block;font-size:1.15rem;line-height:1.25;font-weight:normal}.font i{font-style:normal;font-size:.72rem;color:var(--muted)}
.skin .font:has(input:checked){border-color:var(--accent);box-shadow:inset 0 0 0 2px var(--accent)}
.font:has(input:focus-visible){outline:2px solid var(--accent)}
""" + "\n".join(f"form:has(input[name=theme][value={t}]:checked) .fontpick.for-{t}{{display:grid}}" for t in THEMES)


def form_token(user: str, ts: int) -> str:
    return hmac.new(FORM_SECRET, f"{user}|{ts}".encode(), hashlib.sha256).hexdigest()


def check_token(user: str, ts_s: str, tok: str) -> bool:
    ts = int(ts_s) if ts_s.isdigit() else 0
    return hmac.compare_digest(tok or "", form_token(user, ts)) and time.time() - ts <= 1800


def pw_pattern() -> str:
    """The password rule as an HTML pattern, so the step can say what's missing at the boundary. The server checks again."""
    return f"(?=.*[0-9])(?=.*[^A-Za-z0-9\\s]).{{{min_len()},}}"


def password_form(user: str, ts: int, msg: str = "") -> str:
    t = form_token(user, ts)
    return f"""<form class="act" id="pw" method="post" action="/f/password" autocomplete="on" data-ff data-ff-steps
 data-ff-start="Change password" data-ff-expand="1" data-ff-next="Next">
<input type="hidden" name="ts" value="{ts}"><input type="hidden" name="token" value="{t}">
{f'<p class="bad">{html.escape(msg)}</p>' if msg else ''}
<div data-ff-field data-ff-step data-ff-check data-ff-deny="collapse">
<input type="text" name="_username" value="{html.escape(user)}" autocomplete="username" hidden>
<label>Your current password<input type="password" name="current" required autocomplete="current-password"></label></div>
<div data-ff-field data-ff-step><label>New password<input type="password" name="new1" required minlength="{min_len()}"
 pattern="{html.escape(pw_pattern())}" data-ff-rule-text="That one doesn't meet the rule below yet." autocomplete="new-password" aria-describedby="pwrule"></label>
<p class="note" id="pwrule">{html.escape(pw_rule())}</p></div>
<div data-ff-field data-ff-step><label>Type the new password again<input type="password" name="new2" required minlength="{min_len()}"
 data-ff-same-as="new1" data-ff-same-text="That doesn't match the new password. Please type it again." autocomplete="new-password"></label>
<p class="note">It changes the gate and every app at once.</p></div>
<button type="submit">Change it everywhere</button></form>"""


def username_form(user: str, ts: int, msg: str = "", ok: str = "") -> str:
    if not FORMS or not setting("username_requests"):
        return ""
    t = form_token(user, ts)
    return f"""<form class="act" id="un" method="post" action="/f/username" autocomplete="off" data-ff data-ff-steps
 data-ff-start="Request new username" data-ff-expand="0" data-ff-next="Next">
<input type="hidden" name="ts" value="{ts}"><input type="hidden" name="token" value="{t}">
{f'<p class="ok">{html.escape(ok)}</p>' if ok else ''}{f'<p class="bad">{html.escape(msg)}</p>' if msg else ''}
<div data-ff-field data-ff-step><label>What username would you like?<input type="text" name="wanted" required maxlength="32"
 autocapitalize="none" spellcheck="false"></label>
<p class="note">Letters, numbers, dots, dashes and underscores work best. Eels changes usernames by hand and lets you know.</p></div>
<div data-ff-field data-ff-step><label>Anything Eels should know? (optional)<input type="text" name="note" maxlength="300"></label></div>
<button type="submit">Send request</button></form>"""


def join_page() -> str:
    """The public page: sign in, or ask for a pass. One question per screen (Formidable's steps mode)."""
    ts = int(time.time())
    t = form_token(JOIN, ts)
    if not setting("accept_requests"):
        return render(f"""<h1>Concourse Multi-pass</h1>
<p class="who">One sign-in for the whole station: TV, music, audiobooks, books, comics and the arcade.</p>
<section class="sec"><div class="actions"><a class="signin" href="{html.escape(SIGN_IN)}">I have a pass: sign in</a>
<p class="note">New passes aren't being handed out right now. Ask Eels directly.</p></div></section>""")
    return render(f"""<h1>Concourse Multi-pass</h1>
<p class="who">One sign-in for the whole station: TV, music, audiobooks, books, comics and the arcade.</p>
<section class="sec"><div class="actions">
<a class="signin" href="{html.escape(SIGN_IN)}">I have a pass: sign in</a>
<a class="signin alt" href="/forgot">I have a pass but forgot my password</a>
<form class="act" id="join" method="post" action="/f/join" autocomplete="on" data-ff data-ff-steps
 data-ff-start="Request access" data-ff-expand="0" data-ff-next="Next">
<input type="hidden" name="ts" value="{ts}"><input type="hidden" name="token" value="{t}">
<input type="text" name="website" value="" tabindex="-1" autocomplete="off" aria-hidden="true" hidden>
<div data-ff-field data-ff-step><label>What's your name?<input type="text" name="name" required maxlength="60" autocomplete="name"></label>
<p class="note">So Eels knows who's asking.</p></div>
<div data-ff-field data-ff-step data-ff-check><label>Pick a username<input type="text" name="username" required maxlength="32"
 pattern="[a-z0-9._\\-]{{2,32}}" data-ff-rule-text="Lowercase letters, numbers, dots, dashes or underscores only (2 to 32)." autocapitalize="none" spellcheck="false" autocomplete="username"></label>
<p class="note">Lowercase letters, numbers, dots, dashes and underscores. You'll use it everywhere on the station.</p></div>
<div data-ff-field data-ff-step><label>How can Eels reach you?<input type="text" name="contact" required maxlength="120" autocomplete="email"></label>
<p class="note">An email address or a phone number. Only Eels sees it, to tell you when you're in.</p></div>
<div data-ff-field data-ff-step><label>Choose a password<input type="password" name="new1" required minlength="{min_len()}"
 pattern="{html.escape(pw_pattern())}" data-ff-rule-text="That one doesn't meet the rule below yet." autocomplete="new-password" aria-describedby="joinrule"></label>
<p class="note" id="joinrule">{html.escape(pw_rule())}</p></div>
<div data-ff-field data-ff-step><label>Type it again<input type="password" name="new2" required minlength="{min_len()}"
 data-ff-same-as="new1" data-ff-same-text="That doesn't match. Please type it again." autocomplete="new-password"></label>
<p class="note">It works as soon as Eels lets you in. Nobody else ever sees it, Eels included.</p></div>
<div data-ff-field data-ff-step><label>Anything Eels should know? (optional)<input type="text" name="note" maxlength="300"></label></div>
<button type="submit">Send request</button></form>
</div></section>""")


def forgot_page() -> str:
    """The public "Forgot password?" page. One question per screen. Same answer whether or not the username exists."""
    ts = int(time.time())
    t = form_token(FORGOT, ts)
    return render(f"""<h1>Forgot your password?</h1>
<p class="who">Pick a new one here. Eels checks it's really you, then it works for the gate. The next time you sign in,
your Multi-Pass sets it in every Bay's app too.</p>
<section class="sec"><div class="actions">
<form class="act" id="forgot" method="post" action="/f/forgot" autocomplete="on" data-ff data-ff-steps
 data-ff-start="Reset my password" data-ff-expand="0" data-ff-next="Next">
<input type="hidden" name="ts" value="{ts}"><input type="hidden" name="token" value="{t}">
<input type="text" name="website" value="" tabindex="-1" autocomplete="off" aria-hidden="true" hidden>
<div data-ff-field data-ff-step><label>Your username<input type="text" name="username" required maxlength="32"
 pattern="[a-z0-9._\\-]{{2,32}}" data-ff-rule-text="Lowercase letters, numbers, dots, dashes or underscores only (2 to 32)." autocapitalize="none" spellcheck="false" autocomplete="username"></label>
<p class="note">The one you sign in with.</p></div>
<div data-ff-field data-ff-step><label>What's your name?<input type="text" name="name" required maxlength="60" autocomplete="name"></label></div>
<div data-ff-field data-ff-step><label>How can Eels reach you?<input type="text" name="contact" required maxlength="120" autocomplete="email"></label>
<p class="note">Eels checks with you before anything changes.</p></div>
<div data-ff-field data-ff-step><label>Choose a new password<input type="password" name="new1" required minlength="{MIN_LEN}"
 pattern="{html.escape(pw_pattern())}" data-ff-rule-text="That one doesn't meet the rule below yet." autocomplete="new-password" aria-describedby="fgrule"></label>
<p class="note" id="fgrule">{html.escape(PW_RULE)}</p></div>
<div data-ff-field data-ff-step><label>Type it again<input type="password" name="new2" required minlength="{MIN_LEN}"
 data-ff-same-as="new1" data-ff-same-text="That doesn't match. Please type it again." autocomplete="new-password"></label>
<p class="note">Your old password keeps working until Eels approves this. Nobody else ever sees the new one, Eels included.</p></div>
<div data-ff-field data-ff-step><label>Anything Eels should know? (optional)<input type="text" name="note" maxlength="300"></label></div>
<button type="submit">Send request</button></form>
<a class="signin alt" href="/join">No pass yet? Request access</a>
</div></section>""")


def resync_block(user: str, ts: int, msg: str = "") -> str:
    """After an approved reset: the gate has the new password, the apps still have the old one. One field fixes it."""
    if user not in load_resync():
        return ""
    t = form_token(user, ts)
    inner = ((f'<p class="bad">{html.escape(msg)}</p>' if msg else '')
             + f"""<form class="act" method="post" action="/f/resync" autocomplete="on">
<input type="hidden" name="ts" value="{ts}"><input type="hidden" name="token" value="{t}">
<label>Your new password<input type="password" name="current" required autocomplete="current-password"></label>
<button type="submit">Set it in every app</button></form>
<p class="note">The one you just signed in with. Until you do this, Jellyfin, the music apps and the rest still want your old password.</p>""")
    return fold("resyncfold", "Finish your reset", "One step left: set your new password in every app", inner, open_=True)


def setup_block(user: str, ts: int, msg: str = "") -> str:
    """First sign-in after Approve: the gate knows their password, the Bays don't have them yet. One field fixes it."""
    if user not in load_setup():
        return ""
    t = form_token(user, ts)
    inner = ((f'<p class="bad">{html.escape(msg)}</p>' if msg else '')
             + f"""<form class="act" method="post" action="/f/setup" autocomplete="on">
<input type="hidden" name="ts" value="{ts}"><input type="hidden" name="token" value="{t}">
<label>Your password<input type="password" name="current" required autocomplete="current-password"></label>
<button type="submit">Open my Bays</button></form>
<p class="note">The one you just signed in with. This makes your account in each Bay on your pass, with the same password.</p>""")
    return fold("setupfold", "Finish your pass", "One step left: open your Bays", inner, open_=True)


def fold(fid: str, title: str, summary: str, body: str, open_: bool = False, sub: bool = False) -> str:
    """An expanding window: the title and a one-line summary on its bar, everything else inside, closed until asked for.
    app.js remembers which ones a person keeps open (this browser only). open_ forces it open, e.g. to show a form's result."""
    o = " open" if open_ else ""
    if sub:
        return (f'<details class="bayfold" id="{fid}" data-remember{o}><summary><b>{title}</b><span>{summary}</span></summary>'
                f'<div class="baybody">{body}</div></details>')
    return (f'<section class="sec"><details class="fold" id="{fid}" data-remember{o}><summary><span class="ft">{title}</span>'
            f'<span class="fs">{summary}</span><span class="chev" aria-hidden="true"></span></summary>'
            f'<div class="fbody">{body}</div></details></section>')


def requests_block(user: str, ts: int, msg: str = "", ok: str = "") -> str:
    """Eels's own Multi-Pass only: the waiting access requests, each with Approve and Decline."""
    if user not in ADMINS:
        return ""
    t = form_token(user, ts)
    hid = f'<input type="hidden" name="ts" value="{ts}"><input type="hidden" name="token" value="{t}">'
    esc = html.escape

    def boxes(chosen: list[str], prefix: str = "") -> str:
        return "".join(f'<label class="chk"><input type="checkbox" name="g_{g}" value="1"{" checked" if g in chosen else ""}> {esc(label)}</label>'
                       for g, label in GROUPS)
    reqs = load_requests()
    cards = []
    for r in reqs:
        when = time.strftime("%b %d, %H:%M", time.localtime(r["at"]))
        if r.get("kind") == "reset":
            cards.append(f"""<form class="req reset" method="post" action="/admin/access">
<input type="hidden" name="ts" value="{ts}"><input type="hidden" name="token" value="{t}"><input type="hidden" name="id" value="{html.escape(r['id'])}">
<p><b>Forgot password:</b> someone calling themselves <b>{html.escape(r['name'])}</b> wants a new password for <b>{html.escape(r['username'])}</b> <span class="note">· {html.escape(when)}</span></p>
<p class="note">They gave: {html.escape(r['contact'])}{(' · “' + html.escape(r['note']) + '”') if r['note'] else ''}</p>
<p class="bad">Before you approve, check it's really {html.escape(r['username'])}: text or call them on a number you already have, not only the one above.</p>
<button class="yes" name="do" value="approve">Approve reset</button><button class="no" name="do" value="decline">Decline</button></form>""")
            continue
        cards.append(f"""<form class="req" method="post" action="/admin/access">
<input type="hidden" name="ts" value="{ts}"><input type="hidden" name="token" value="{t}"><input type="hidden" name="id" value="{html.escape(r['id'])}">
<p><b>{html.escape(r['name'])}</b> asked for <b>{html.escape(r['username'])}</b> <span class="note">· {html.escape(when)}</span></p>
<p class="note">Reach them: {html.escape(r['contact'])}{(' · “' + html.escape(r['note']) + '”') if r['note'] else ''}</p>
<div class="row"><label>Username <input type="text" name="username" value="{html.escape(r['username'])}" maxlength="32" autocapitalize="none" spellcheck="false"></label>
<label><input type="checkbox" name="music" value="1"> Music Bay</label><label><input type="checkbox" name="talk" value="1"> Talk Radio</label><label><input type="checkbox" name="archives" value="1"> The Archives (private)</label></div>
<button class="yes" name="do" value="approve">Approve</button><button class="no" name="do" value="decline">Decline</button></form>""")
    inner = ((f'<p class="ok">{html.escape(ok)}</p>' if ok else '') + (f'<p class="bad">{html.escape(msg)}</p>' if msg else '')
             + (f'<div class="reqs">{"".join(cards)}</div>' if cards else '<p class="note">No one is waiting.</p>')
             + '<p class="note">Approve writes their account into the gate at once, with the password they chose. '
               'Their accounts in Jellyfin, Audiobookshelf, Kavita, RomM and Calibre-Web are still made by hand (step 11\'s list).</p>')
    waiting = f"{len(cards)} waiting" if cards else "No one is waiting"
    return fold("reqfold", "Access requests", waiting, inner, open_=bool(cards or msg or ok))


# ---------------------------------------------------------------- PodPanels (admin proxy; the command service is not this file)

class _NoRedirect(urllib.request.HTTPRedirectHandler):
    """Refuse to follow a redirect. A 30x from PodPanels is relayed as-is, and the key is not sent to a new host."""

    def redirect_request(self, req, fp, code, msg, hdrs, newurl):
        raise urllib.error.HTTPError(getattr(req, "full_url", "") or newurl, code, msg, hdrs, fp)


def _podpanels_opener():
    # ProxyHandler({}) takes the place of the default handler, which would read http_proxy.
    # An empty mapping adds no proxy methods, so the key stays on loopback.
    return urllib.request.build_opener(urllib.request.ProxyHandler({}), _NoRedirect)


def _authelia_opener():
    """No proxy and no redirect. The session cookie is sent only to Authelia, never through http_proxy."""
    return urllib.request.build_opener(urllib.request.ProxyHandler({}), _NoRedirect)


def _header_value(headers, name: str) -> str:
    if not headers:
        return ""
    try:
        value = headers.get(name)
    except Exception:
        return ""
    if value is None:
        return ""
    return str(value).replace("\r", "").replace("\n", "").strip()


def authelia_session(method: str, url_path: str, cookie: str | None) -> tuple[str, str]:
    """Ask Authelia who this visitor is. ('ok', user), ('anon', ''), ('no', '') or ('down', '').

    'anon' is HTTP 401. 'down' means Authelia could not be reached, so the caller fails closed.
    Forwards only Cookie (when the visitor sent one), X-Original-Method, X-Original-URL,
    X-Forwarded-Proto and X-Forwarded-Host. Does not follow redirects. Does not log the cookie.
    """
    target = AUTHELIA_AUTHZ_URL.strip()
    aim = urllib.parse.urlsplit(target)
    if aim.scheme not in ("http", "https") or not aim.hostname or aim.username or aim.password:
        return "down", ""
    if not url_path or len(url_path) > 2048 or any(c in url_path for c in "\r\n\\"):
        return "no", ""
    origin = urllib.parse.urlsplit(ORIGIN)
    proto, host = origin.scheme, origin.netloc
    if proto not in ("http", "https") or not host or any(c in host for c in "\r\n"):
        return "down", ""
    path = url_path if url_path.startswith("/") else "/" + url_path
    method_name = "".join(ch for ch in (method or "").upper() if "A" <= ch <= "Z")
    if method_name not in ("GET", "POST"):
        return "no", ""
    headers = {
        "X-Original-Method": method_name,
        "X-Original-URL": ORIGIN.rstrip("/") + path,
        "X-Forwarded-Proto": proto,
        "X-Forwarded-Host": host,
    }
    if cookie:
        if any(c in cookie for c in "\r\n") or len(cookie) > 16384:
            return "no", ""
        cleaned = cookie.strip()
        if cleaned:
            headers["Cookie"] = cleaned
    req = urllib.request.Request(target, headers=headers, method="GET")
    try:
        with _authelia_opener().open(req, timeout=3) as r:
            try:
                r.read(1024)
            except Exception:
                pass
            status = getattr(r, "status", None) or r.getcode()
            remote = _header_value(getattr(r, "headers", None), "Remote-User").lower()
    except urllib.error.HTTPError as e:
        status = e.code
        remote = _header_value(e.headers, "Remote-User").lower()
        try:
            if e.fp:
                e.read(1024)
        except Exception:
            pass
    except (urllib.error.URLError, TimeoutError, OSError, ValueError):
        return "down", ""
    if status == 401:
        return "anon", ""
    if status == 200 and USER_RE.fullmatch(remote):
        return "ok", remote
    return "no", ""


def podpanels_base() -> str | None:
    """PODPANELS_URL if it is http(s) on loopback, otherwise None. The key is never put in a URL."""
    parts = urllib.parse.urlsplit(PODPANELS_URL.strip())
    host = (parts.hostname or "").lower().rstrip(".")
    if parts.scheme not in ("http", "https") or host not in _POD_LOOPBACK or parts.username or parts.password:
        return None
    port = f":{parts.port}" if parts.port else ""
    netloc = f"[{host}]{port}" if ":" in host else f"{host}{port}"
    return urllib.parse.urlunsplit((parts.scheme, netloc, parts.path.rstrip("/"), "", ""))


def podpanels_upstream(url_path: str) -> str | None:
    """The PodPanels URL for a /admin/pods request, or None when the path is refused.
    Rejects .., %2e (any case), and backslash, including once the path is decoded."""
    path, _, query = url_path.partition("?")
    if path == "/admin/pods":
        sub = "/"
    elif path.startswith("/admin/pods/"):
        sub = path[len("/admin/pods"):]
    else:
        return None
    if not sub.startswith("/"):
        sub = "/" + sub
    decoded = urllib.parse.unquote(path)
    if sub.startswith("//") or "://" in sub or _POD_BAD.search(path) or _POD_BAD.search(decoded):
        return None
    if PODPANELS_KEY and (PODPANELS_KEY in url_path or PODPANELS_KEY in urllib.parse.unquote(url_path)):
        return None
    base = podpanels_base()
    if not base:
        return None
    target = base + sub
    if query:
        if "\\" in query or "\r" in query or "\n" in query or (PODPANELS_KEY and PODPANELS_KEY in query):
            return None
        target += "?" + query
    return target


def _clean_header(value: str, limit: int) -> str:
    return value.replace("\r", "").replace("\n", "").strip()[:limit]


def podpanels_headers(method: str, user: str, accept: str | None, content_type: str | None) -> dict[str, str]:
    """The only headers the proxy adds. Client Cookie, Authorization, Remote-* and X-PodPanels-* are not copied."""
    headers = {
        "X-PodPanels-Key": PODPANELS_KEY,
        "X-PodPanels-User": user,
        "Accept": _clean_header(accept, 300) if accept else "*/*",
    }
    if method == "POST" and content_type:
        ctype = _clean_header(content_type, 200)
        if ctype:
            headers["Content-Type"] = ctype
    return headers


def podpanels_fetch(method: str, target: str, headers: dict[str, str], body: bytes | None, timeout: float):
    """(status, body, content-type), 'big', or None when PodPanels cannot be reached. Redirects are not followed."""
    req = urllib.request.Request(target, data=body if method == "POST" else None, headers=headers, method=method)
    try:
        with _podpanels_opener().open(req, timeout=timeout) as r:
            raw = r.read(POD_MAX_BODY + 1)
            ctype = r.headers.get("Content-Type") if r.headers else None
            status = getattr(r, "status", None) or r.getcode()
    except urllib.error.HTTPError as e:
        raw = e.read(POD_MAX_BODY + 1) if getattr(e, "fp", None) else b""
        ctype = e.headers.get("Content-Type") if e.headers else None
        status = e.code
    except (urllib.error.URLError, TimeoutError, OSError):
        return None
    if len(raw) > POD_MAX_BODY:
        return "big"
    return status, raw, ctype


def _clean_ctype(value: str | None) -> str:
    if not value:
        return "application/octet-stream"
    value = _clean_header(value, 200)
    if not value or any(ord(c) < 32 or ord(c) > 126 for c in value):
        return "application/octet-stream"
    return value


def podpanels_log_sub(url_path: str) -> str:
    """A short path for the log. The key, the query string and newlines are left out."""
    path = url_path.split("?", 1)[0]
    sub = (path[len("/admin/pods"):] if path.startswith("/admin/pods") else path) or "/"
    sub = sub.replace("\r", "").replace("\n", "")[:200]
    if PODPANELS_KEY and PODPANELS_KEY in url_path:
        return "refused"
    if _POD_BAD.search(path) or _POD_BAD.search(urllib.parse.unquote(path)):
        return "refused"
    return sub or "/"


def podpanels_limited(user: str, kind: str) -> bool:
    """True when this admin, or everyone together, has POSTed too often.
    A refused attempt does not add another stamp; the window runs out from the stamps that filled it."""
    if kind == "rotate":
        window, per, all_max, slot = POD_ROTATE_WINDOW, POD_ROTATE_PER, POD_ROTATE_ALL, "rotate"
    else:
        window, per, all_max, slot = POD_POST_WINDOW, POD_POST_PER, POD_POST_ALL, "post"
    now = time.time()
    with POD_LOCK:
        hits = [t for t in POD_HITS.get(f"{slot}:{user}", []) if now - t < window]
        glob = [t for t in POD_ALL.get(slot, []) if now - t < window]
        if len(hits) >= per or len(glob) >= all_max:
            POD_HITS[f"{slot}:{user}"] = hits
            POD_ALL[slot] = glob
            return True
        hits.append(now)
        glob.append(now)
        POD_HITS[f"{slot}:{user}"] = hits
        POD_ALL[slot] = glob
        return False


def podpanels_rates_clear() -> None:
    with POD_LOCK:
        POD_HITS.clear()
        POD_ALL.clear()


def podpanels_probe() -> tuple[str, str]:
    """('Online' or 'Offline', when the key was made or ''). Keyless /health, one second, no key sent."""
    base = podpanels_base()
    if not base:
        return "Offline", ""
    req = urllib.request.Request(base + "/health", method="GET", headers={"Accept": "application/json"})
    try:
        with _podpanels_opener().open(req, timeout=1) as r:
            raw = r.read(4096)
            online = (getattr(r, "status", None) or r.getcode()) == 200
    except urllib.error.HTTPError:
        return "Offline", ""
    except (urllib.error.URLError, TimeoutError, OSError):
        return "Offline", ""
    if not online:
        return "Offline", ""
    created = ""
    try:
        data = json.loads(raw.decode("utf-8", "replace"))
    except ValueError:
        data = None
    if isinstance(data, dict):
        stamp = data.get("key_created")
        if isinstance(stamp, str) and _KEY_CREATED_RE.fullmatch(stamp):
            created = stamp
    return "Online", created


def podpanels_block(user: str, ts: int, msg: str = "", ok: str = "", new_key: str = "") -> str:
    """Admin Multi-Pass only. No key: a note and no link. With a key: the new-tab link, whether a key
    exists, when PodPanels says it was made, and Make new key. The installed key is never rendered."""
    if user not in ADMINS:
        return ""
    if not PODPANELS_KEY:
        return fold("podfold", "PodPanels", "Key not installed",
                    '<p class="note">Key not installed on the gate (step 16).</p>')
    status, made = podpanels_probe()
    summary = f"Gate pods - {status} - opens in a new tab"
    made_line = (f'<p class="note">A key is installed. Made {html.escape(made)}.</p>' if made
                 else '<p class="note">A key is installed. PodPanels has not reported when it was made.</p>')
    once = ""
    if new_key:
        if _NEW_KEY_RE.fullmatch(new_key):
            once = ('<p class="ok">New key, shown this once:</p>'
                    f'<p><code>{html.escape(new_key)}</code></p>'
                    '<p class="note">Reload and it is gone. It is not kept on this page, in a file, or in the log. '
                    'Restart eo-account when you can so the proxy reads the new secret. Until that restart, '
                    'PodPanels still accepts the previous key.</p>')
        else:
            once = '<p class="bad">PodPanels answered, but this page did not show the reply. Nothing was saved here.</p>'
    token = html.escape(form_token(user, ts))
    inner = (once
             + (f'<p class="ok">{html.escape(ok)}</p>' if ok else '')
             + (f'<p class="bad">{html.escape(msg)}</p>' if msg else '')
             + made_line
             + f'<p class="note">PodPanels is {html.escape(status)}. Admin only. The installed key stays on the gate and is not shown here.</p>'
             + '<p><a class="podlink" href="/admin/pods/" target="_blank" rel="noopener noreferrer">Open PodPanels</a></p>'
             + f'<form method="post" action="/admin/pods/rotate" autocomplete="off">'
             + f'<input type="hidden" name="ts" value="{ts}"><input type="hidden" name="token" value="{token}">'
             + '<button class="podnew" type="submit">Make new key</button></form>'
             + '<p class="note">Make new key asks PodPanels to generate a key and replace the podman secret. '
               'This page cannot change the secret itself. The first key is still made by step 16, which only generates one.</p>')
    return fold("podfold", "PodPanels", summary, inner, open_=bool(new_key or msg or ok))


ADMIN_BAYS_DEFAULT = [
    # The Commander's own pods: on nobody's pass, shown only in the ADMIN section. open = where the link goes,
    # probe = where the gate checks it's up (127.0.0.1 = inside the gate pod; 10.6.9.20 = the SGIN), lan = home or WireGuard only.
    # /data/admin-bays.json, if it exists, replaces this list (same fields), so a new pod needs no code change.
    {"name": "Vaultwarden", "open": "https://vault.songofeo.com", "probe": "http://127.0.0.1:8222/alive", "lan": True,
     "what": "Password vault (Bitwarden apps and browser add-on). Home Wi-Fi or WireGuard only."},
    {"name": "Paperless-ngx", "open": "https://papers.songofeo.com", "probe": "http://127.0.0.1:8000/",
     "what": "Scanned mail, receipts and documents, searchable (OCR)."},
    {"name": "MeTube", "open": "https://metube.songofeo.com", "probe": "http://127.0.0.1:8081/",
     "what": "Paste a video link, get the file or its audio on the media drives."},
    {"name": "Homepage", "open": "https://command.songofeo.com", "probe": "http://127.0.0.1:3000/",
     "what": "One dashboard of every pod and the network gear."},
    {"name": "Smart home (Home Assistant)", "open": "https://ha.songofeo.com", "probe": "http://10.6.9.11:8123/manifest.json",
     "what": "Lights, switches and the thermostat. Admins only, password + TOTP. Its own window below: Smart home."},
    {"name": "Uptime Kuma", "open": "https://status.songofeo.com", "probe": "http://127.0.0.1:3001/",
     "what": "Watches every pod and tells you when one goes down."},
    {"name": "Radio (Liquidsoap + Icecast)", "open": "http://10.6.9.20:8000", "probe": "http://10.6.9.20:8000/", "lan": True,
     "what": "The station's own 24/7 radio stream."},
    {"name": "ErsatzTV", "open": "http://10.6.9.20:8409", "probe": "http://10.6.9.20:8409/", "lan": True,
     "what": "Builds the live TV channels Jellyfin shows."},
    {"name": "Audiobooks admin", "open": "http://10.6.9.20:13378", "probe": "http://10.6.9.20:13378/ping", "lan": True,
     "what": "The main Audiobookshelf (the audiobooks themselves, audio.): users, libraries, scans."},
    {"name": "Talk Radio & Comedy Club admin", "open": "http://10.6.9.20:13379", "probe": "http://10.6.9.20:13379/ping", "lan": True,
     "what": "Its own Audiobookshelf: users, libraries, scans."},
    {"name": "The Archives admin", "open": "http://10.6.9.20:13380", "probe": "http://10.6.9.20:13380/ping", "lan": True,
     "what": "Its own walled Audiobookshelf: users, libraries, scans."},
    {"name": "Kavita Comics admin", "open": "http://10.6.9.20:5000", "probe": "http://10.6.9.20:5000/", "lan": True,
     "what": "Its own walled Kavita: comics."},
    {"name": "Kavita Books admin", "open": "http://10.6.9.20:5001", "probe": "http://10.6.9.20:5001/", "lan": True,
     "what": "Its own walled Kavita: novels and e-books (replaces Calibre-Web)."},
    {"name": "Kavita RPG Vault admin", "open": "http://10.6.9.20:5002", "probe": "http://10.6.9.20:5002/", "lan": True,
     "what": "Its own walled Kavita: RPG rulebooks and sheets."},
    {"name": "RomM admin", "open": "http://10.6.9.20:8080", "probe": "http://10.6.9.20:8080/", "lan": True,
     "what": "The Arcade's users, scans and BIOS files."},
    {"name": "High scores", "open": "", "probe": "http://127.0.0.1:8090/healthz",
     "what": "The cabinet's hiscore board (no public address yet)."},
    {"name": "eo-art", "open": "https://art.songofeo.com", "probe": "http://127.0.0.1:8790/",
     "what": "The live pictures on the concourse windows."},
    {"name": "Forms inbox (Formidable)", "open": "https://forms.songofeo.com", "probe": "http://127.0.0.1:8097/",
     "what": "Seek Council petitions and every form's inbox."},
    {"name": "PodPanels", "open": "/admin/pods/", "probe": "",
     "what": "Start, stop and check pods from buttons (fixed list)."},
    {"name": "Feishin (music player)", "open": "https://player.songofeo.com", "probe": "http://127.0.0.1:9180/",
     "what": "The nicer web player for Navidrome. Friends with Music on their pass can use it too."},
    {"name": "OPNsense", "open": "https://10.6.9.1", "probe": "", "lan": True, "what": "The router and firewall."},
    {"name": "Proxmox", "open": "https://10.6.9.2:8006", "probe": "", "lan": True, "what": "The VM host."},
]


def load_admin_bays() -> list[dict]:
    try:
        return json.loads((APPS_FILE.parent / "admin-bays.json").read_text())
    except FileNotFoundError:
        return ADMIN_BAYS_DEFAULT
    except Exception as e:
        log(f"admin-bays.json unreadable ({e}); using the built-in list")
        return ADMIN_BAYS_DEFAULT


def admin_bays_block(user: str, groups: set[str]) -> str:
    """Admin Bays: the Commander's personal pods, each with its state (the same once-a-minute check as the Bays)."""
    if not is_admin(user, groups):
        return ""
    esc, tiles, up = html.escape, [], 0
    bays = load_admin_bays()
    for b in bays:
        st = STATUS.get(b.get("probe", ""), "unknown") if b.get("probe") else "ext"
        state, label = {"up": ("up", "Active"), "down": ("down", "Down"), "ext": ("ext", "Not checked")}.get(st, ("wait", "Checking ..."))
        up += st == "up"
        link = b.get("open", "")
        door = (f'<a class="enter" href="{esc(link)}" rel="noopener">Open</a>'
                if re.match(r"^(https?://|/admin/)", link) else "")
        lan = '<div class="app">Home Wi-Fi or WireGuard</div>' if b.get("lan") else ""
        tiles.append(f'<div class="bay {state}"><div class="bh"><b>{esc(b.get("name", ""))}</b><span class="st">{label}</span></div>'
                     f'{lan}{door}<p>{esc(b.get("what", ""))}</p></div>')
    checked = sum(1 for b in bays if b.get("probe"))
    return fold("adminbays", "Admin Bays", f"{up} of {checked} checked pods answering", f'<div class="grid">{"".join(tiles)}</div>'
                '<p class="note">Only admins see this. A pod marked Down: run the pod health check (F40) on its machine.</p>')


# ---------------------------------------------------------------- Smart home (Home Assistant), admin only (v3.8 draft)
# The Multi-Pass talks to Home Assistant's REST API with a long-lived token the Commander makes in Home Assistant
# (Profile -> Security -> Long-lived access tokens). It lives in apps.json under "home" (mode 600, like the app
# tokens) and is never logged or written into the page:
#   "home": {"url": "http://10.6.9.11:8123", "token": "<long-lived token>", "enabled": true}
# The url may only be Home Assistant in VM 120 (cobra-home, 10.6.9.11:8123) or loopback, so a bad apps.json can't make the
# gate fetch anything else. Only lights, switches and thermostats are shown, and only these calls can be made:
#   light/toggle, switch/toggle, climate/set_temperature, climate/set_hvac_mode
# on an entity that Home Assistant listed in the same request. Every change is logged as: home <user> <call> <entity>.

HOME_URL_OK = re.compile(r"^http://(10\.6\.9\.11|127\.0\.0\.1):8123$")
HOME_DOMAINS = ("light", "switch", "climate")
HOME_ENTITY = re.compile(r"^(light|switch|climate)\.[a-z0-9_]{1,64}$")
HOME_MAX = 80                     # tiles shown; more than this means it needs rooms first (Grok's research)
HOME_WINDOW, HOME_PER = 60, 30    # at most 30 changes a minute per admin
HOME_HITS: dict[str, list[float]] = {}
HOME_LOCK = threading.Lock()
# Home Assistant bans an address after 5 refused logins (ip_ban_enabled). The Multi-Pass calls it straight from the
# gate (10.6.9.10, no X-Forwarded-For), so a wrong or revoked token would get the gate itself banned after 5 page
# loads. After one 401/403 it stops calling until the token in apps.json changes (or eo-account restarts).
HOME_REFUSED: dict[str, str] = {"token": ""}
# The admin page shouldn't wait on Home Assistant every time: the device list is kept 15 s (a change clears it).
HOME_CACHE: dict[str, object] = {"at": 0.0, "ents": None}
HOME_CACHE_SECS = 15


def home_config() -> tuple[str, str] | None:
    """(url, token) when apps.json has an enabled "home" entry with an allowed url, else None."""
    try:
        h = json.loads(APPS_FILE.read_text()).get("home") or {}
    except Exception:
        return None
    url, tok = str(h.get("url", "")).strip().rstrip("/"), str(h.get("token", "")).strip()
    if not h.get("enabled") or not tok or not HOME_URL_OK.match(url):
        return None
    return url, tok


def home_call(method: str, path: str, body: dict | None = None, timeout: float = 3):
    """(status, parsed JSON or None). No proxy, no redirects, token only in the Authorization header."""
    cfg = home_config()
    if not cfg:
        return 0, None
    url, tok = cfg
    if HOME_REFUSED["token"] == tok:
        return 401, None                  # this token was refused once: don't feed Home Assistant's lock-out
    data = json.dumps(body).encode() if body is not None else None
    req = urllib.request.Request(url + path, data=data, method=method,
                                 headers={"Authorization": f"Bearer {tok}", "Content-Type": "application/json"})
    try:
        with _podpanels_opener().open(req, timeout=timeout) as r:
            raw = r.read(2_000_000)
            return r.status, (json.loads(raw) if raw else None)
    except urllib.error.HTTPError as e:
        if e.code in (401, 403):
            HOME_REFUSED["token"] = tok
            log("home token refused by Home Assistant; not calling it again until apps.json has a new token")
        return e.code, None
    except Exception:
        return 0, None


def home_num(v, default: float) -> float:
    """A number from Home Assistant's attributes, or the default when it's missing, null or not a number."""
    try:
        return float(v)
    except (TypeError, ValueError):
        return default


def home_entities() -> list[dict] | None:
    """Lights, switches and thermostats, sorted by name. None when Home Assistant can't be reached."""
    now = time.time()
    with HOME_LOCK:
        if HOME_CACHE["ents"] is not None and now - float(HOME_CACHE["at"]) < HOME_CACHE_SECS:
            return HOME_CACHE["ents"]     # type: ignore[return-value]
    status, states = home_call("GET", "/api/states", timeout=2)
    if status != 200 or not isinstance(states, list):
        return None
    out = [s for s in states if isinstance(s, dict) and HOME_ENTITY.match(str(s.get("entity_id", "")))]
    out.sort(key=lambda s: (str(s.get("attributes", {}).get("friendly_name") or s["entity_id"])).lower())
    with HOME_LOCK:
        HOME_CACHE["at"], HOME_CACHE["ents"] = now, out
    return out


def home_forget() -> None:
    """Drop the cached device list (after a change, so the next page shows the new state)."""
    with HOME_LOCK:
        HOME_CACHE["at"], HOME_CACHE["ents"] = 0.0, None


def home_limited(user: str) -> bool:
    now = time.time()
    with HOME_LOCK:
        hits = [t for t in HOME_HITS.get(user, []) if now - t < HOME_WINDOW]
        if len(hits) >= HOME_PER:
            HOME_HITS[user] = hits
            return True
        hits.append(now)
        HOME_HITS[user] = hits
        return False


def home_change(entity_id: str, do: str, value: str, ents: list[dict]) -> tuple[bool, str]:
    """Checks the request against what Home Assistant just listed, then makes one call. (ok, message)."""
    ent = next((e for e in ents if e.get("entity_id") == entity_id), None)
    if not HOME_ENTITY.match(entity_id) or ent is None:
        return False, "That device isn't in Home Assistant's list any more. Reload the page."
    domain, attrs = entity_id.split(".", 1)[0], ent.get("attributes", {}) or {}
    name = str(attrs.get("friendly_name") or entity_id)
    if do == "toggle" and domain in ("light", "switch"):
        call, body = f"{domain}/toggle", {"entity_id": entity_id}
    elif do == "settemp" and domain == "climate":
        try:
            t = float(value)
        except ValueError:
            return False, "Type a number for the temperature."
        lo, hi = home_num(attrs.get("min_temp"), 45), home_num(attrs.get("max_temp"), 90)
        if not (lo <= t <= hi):
            return False, f"{name} takes {lo:g} to {hi:g}."
        call, body = "climate/set_temperature", {"entity_id": entity_id, "temperature": t}
    elif do == "mode" and domain == "climate":
        if value not in (attrs.get("hvac_modes") or []):
            return False, f"{name} doesn't have a mode called “{value}”."
        call, body = "climate/set_hvac_mode", {"entity_id": entity_id, "hvac_mode": value}
    else:
        return False, "That button doesn't do anything for this device."
    status, _ = home_call("POST", f"/api/services/{call}", body)
    home_forget()
    if status != 200:
        return False, f"Home Assistant didn't accept that ({status or 'no answer'}). Nothing changed here."
    return True, f"{name}: done."


def home_block(user: str, groups: set[str], ts: int, msg: str = "", ok: str = "") -> str:
    """Smart home: lights, switches and thermostats from Home Assistant, with buttons. Admin only."""
    if not is_admin(user, groups):
        return ""
    esc = html.escape
    flash = (f'<p class="ok flash">{esc(ok)}</p>' if ok else '') + (f'<p class="bad flash">{esc(msg)}</p>' if msg else '')
    link = '<p><a class="podlink" href="https://ha.songofeo.com" target="_blank" rel="noopener noreferrer">Open Home Assistant</a></p>'
    if not home_config():
        return fold("homefold", "Smart home", "Not connected yet",
                    flash + '<p class="note">Add a Home Assistant long-lived token to apps.json under "home" '
                    '(README Part 9). Until then this window stays empty.</p>' + link, open_=bool(msg or ok))
    ents = home_entities()
    cfg = home_config()
    if cfg and HOME_REFUSED["token"] == cfg[1]:
        return fold("homefold", "Smart home", "Token refused",
                    flash + '<p class="note">Home Assistant refused the Multi-Pass\'s token, so it isn\'t being asked '
                    'again (5 refusals would lock out the whole gate). Make a new long-lived token and run F63 '
                    '(README Help 9.37).</p>' + link, open_=True)
    if ents is None:
        return fold("homefold", "Smart home", "Home Assistant isn't answering",
                    flash + '<p class="note">The gate couldn\'t reach Home Assistant (VM 120, 10.6.9.11:8123). '
                    'Check VM 120 is running in Proxmox (https://10.6.9.2:8006).</p>' + link, open_=True)
    hid = f'<input type="hidden" name="ts" value="{ts}"><input type="hidden" name="token" value="{form_token(user, ts)}">'
    tiles, on = [], 0
    for e in ents[:HOME_MAX]:
        eid, st, a = str(e["entity_id"]), str(e.get("state", "")), e.get("attributes", {}) or {}
        name = esc(str(a.get("friendly_name") or eid))
        base = f'<form method="post" action="/admin/home" class="pform">{hid}<input type="hidden" name="entity" value="{esc(eid)}">'
        if eid.startswith("climate."):
            cur, tgt = a.get("current_temperature"), a.get("temperature")
            modes = "".join(f'<option value="{esc(str(m))}"{" selected" if str(m) == st else ""}>{esc(str(m))}</option>'
                            for m in (a.get("hvac_modes") or []))
            body = (f'<p>Now {esc(str(cur))}° · set to {esc(str(tgt))}°</p>'
                    f'{base}<input type="hidden" name="do" value="settemp">'
                    f'<input name="value" type="number" step="0.5" min="{home_num(a.get("min_temp"), 45):g}" '
                    f'max="{home_num(a.get("max_temp"), 90):g}" value="{esc(str(tgt or ""))}" required>'
                    f'<button class="yes">Set</button></form>'
                    f'{base}<input type="hidden" name="do" value="mode"><select name="value">{modes}</select>'
                    f'<button class="yes">Mode</button></form>')
            state = "up" if st not in ("off", "unavailable") else ("down" if st == "unavailable" else "ext")
        else:
            body = f'{base}<input type="hidden" name="do" value="toggle"><button class="yes">{"Turn off" if st == "on" else "Turn on"}</button></form>'
            state = {"on": "up", "unavailable": "down"}.get(st, "ext")
            on += st == "on"
        label = {"unavailable": "Unreachable"}.get(st, st.capitalize() or "?")
        tiles.append(f'<div class="bay {state}"><div class="bh"><b>{name}</b><span class="st">{esc(label)}</span></div>{body}</div>')
    more = (f'<p class="note">Showing {HOME_MAX} of {len(ents)}. Group them into rooms in Home Assistant.</p>'
            if len(ents) > HOME_MAX else '')
    return fold("homefold", "Smart home", f"{len(ents)} devices · {on} lights or switches on",
                flash + f'<div class="grid">{"".join(tiles)}</div>' + more
                + '<p class="note">Admin only. Every change is logged on the gate. Unreachable = Home Assistant can\'t talk to it '
                  '(the bulb is off at the wall, or it only works through the Eufy or Alexa cloud).</p>' + link,
                open_=bool(msg or ok))


def admin_block(user: str, groups: set[str], ts: int, msg: str = "", ok: str = "", open_: bool = False) -> str:
    """The ADMIN section (people, add someone, theme and settings). Access requests keep their own fold."""
    if not is_admin(user, groups):
        return ""
    t = form_token(user, ts)
    hid = f'<input type="hidden" name="ts" value="{ts}"><input type="hidden" name="token" value="{t}">'
    esc = html.escape

    def boxes(chosen: list[str], prefix: str = "") -> str:
        return "".join(f'<label class="chk"><input type="checkbox" name="g_{g}" value="1"{" checked" if g in chosen else ""}> {esc(label)}</label>'
                       for g, label in GROUPS)
    people = read_users()
    rows = []
    for u in people:
        chips = "".join(f'<span class="chip">{esc(dict(GROUPS).get(g, g))}</span>' for g in u["groups"])
        off = '<span class="chip off">Off</span>' if u["disabled"] else ""
        me = u["name"] == user
        rows.append(f"""<details class="person"><summary><b>{esc(u['name'])}</b><span class="dn">{esc(u['displayname'])}</span>{chips}{off}</summary>
<form method="post" action="/admin/user" class="pform">{hid}<input type="hidden" name="name" value="{esc(u['name'])}">
<div class="row"><label>Display name <input type="text" name="displayname" value="{esc(u['displayname'])}" maxlength="60"></label>
<label>Email <input type="text" name="email" value="{esc(u['email'])}" maxlength="120"></label></div>
<div class="row">{boxes(u['groups'])}</div>
<button class="yes" name="do" value="save">Save</button>{'' if me else f'<button class="no" name="do" value="{"enable" if u["disabled"] else "disable"}">{"Switch on" if u["disabled"] else "Switch off"}</button>'}</form>
<form method="post" action="/admin/user" class="pform" autocomplete="off">{hid}<input type="hidden" name="name" value="{esc(u['name'])}"><input type="hidden" name="do" value="password">
<div class="row"><label>New password <input type="password" name="new1" minlength="{min_len()}" autocomplete="new-password"></label>
<label>Again <input type="password" name="new2" minlength="{min_len()}" autocomplete="new-password"></label></div>
<button class="no">Set password everywhere</button><p class="note">The gate and every app at once. {esc(pw_rule())}</p></form></details>""")
    add = f"""<form method="post" action="/admin/adduser" class="card" autocomplete="off">{hid}
<div class="row"><label>Username <input type="text" name="name" maxlength="32" autocapitalize="none" spellcheck="false" required></label>
<label>Display name <input type="text" name="displayname" maxlength="60"></label><label>Email <input type="text" name="email" maxlength="120"></label></div>
<div class="row">{boxes([])}</div>
<div class="row"><label>Password <input type="password" name="new1" minlength="{min_len()}" autocomplete="new-password" required></label>
<label>Again <input type="password" name="new2" minlength="{min_len()}" autocomplete="new-password" required></label></div>
<button class="yes">Add to the station</button><p class="note">Writes their gate account and sets the same password in every app where they already have an account.</p></form>"""
    theme, pal = setting("theme"), str(setting("palette"))
    looks = "".join(f"""<label class="look look-{k}"><input type="radio" name="theme" value="{k}"{" checked" if k == theme else ""}><span class="sw"></span><b>{esc(v)}</b>
<a href="/?theme={k}&amp;palette={pal}&amp;font={theme_font(k)}#admin">Preview</a></label>""" for k, v in THEMES.items())
    chosen = setting("fonts")

    def font_opt(t: str, k: str) -> str:
        name = FONTS[k][0] if k else "Theme default"
        style = f' style="font-family:\'{FONTS[k][0]}\'"' if k else ""
        on = " checked" if (chosen.get(t, "") if chosen.get(t, "") in THEME_FONTS[t] else "") == k else ""
        return (f'<label class="font"><input type="radio" name="font_{t}" value="{k}"{on}>'
                f'<b{style}>Multi-pass 1984</b><i>{esc(name)}</i></label>')
    fontpicks = "".join(f'<div class="fontpick for-{t}">{"".join(font_opt(t, k) for k in ks)}</div>' for t, ks in THEME_FONTS.items())
    swatches = "".join(f"""<label class="pal p-{k}" title="{esc(v)}"><input type="radio" name="palette" value="{k}"{" checked" if k == pal else ""}><span></span>{esc(v)}</label>"""
                       for k, v in PALETTES.items())

    def dial(key: str, label: str, unit: str) -> str:
        lo, hi = SETTING_RANGES[key]
        return (f'<label class="dial">{esc(label)} <output>{setting(key)}</output> {esc(unit)}'
                f'<input type="range" name="{key}" min="{lo}" max="{hi}" value="{setting(key)}"></label>')

    def switch(key: str, label: str, on: bool) -> str:
        return f'<label class="switch"><input type="checkbox" name="{key}" value="1"{" checked" if on else ""}><span></span>{esc(label)}</label>'
    try:
        appcfg = json.loads(APPS_FILE.read_text()).get("apps", {})
    except (OSError, ValueError):
        appcfg = {}
    app_switches = "".join(switch("app_" + k, KINDS[k].title, bool(c.get("enabled"))) for k, c in appcfg.items() if k in KINDS)
    settings = f"""<form method="post" action="/admin/settings" class="card">{hid}
<h4>Theme (everyone's Multi-Pass and the Request access page)</h4><div class="looks">{looks}</div>
<h4>Palette</h4><div class="pals">{swatches}</div>
<h4>Font (for the theme ticked above)</h4>{fontpicks}
<h4>Dials</h4>{dial("min_len", "Shortest password", "characters")}{dial("stats_minutes", "Stats refresh", "minutes")}
<h4>Switches</h4>{switch("accept_requests", "Accept new access requests (Request access page)", setting("accept_requests"))}
{switch("username_requests", "Show “Request new username”", setting("username_requests"))}
<h4>Password sync reaches</h4>{app_switches or '<p class="note">No apps set up yet (step 15).</p>'}
<button class="yes">Save settings</button></form>"""
    flash = (f'<p class="ok flash">{esc(ok)}</p>' if ok else '') + (f'<p class="bad flash">{esc(msg)}</p>' if msg else '')
    inner = (flash + '<div class="adm-grid">'
             + f'<section class="adm"><h3>People</h3>{"".join(rows) or "<p class=note>No users file found.</p>"}</section>'
             + f'<section class="adm"><h3>Add someone</h3>{add}</section>'
             + f'<section class="adm"><h3>Settings</h3>{settings}</section></div>'
             + '<p class="note">Changes go into the gate\'s users file at once (Authelia re-reads it); the file before each '
               'change is kept as users.yml.bak-account.</p>')
    return fold("admin", "Admin", f"{len(people)} people · theme and settings", inner, open_=bool(open_ or msg or ok))


def form_page(user: str, msg: str = "", groups: set[str] | None = None, rmsg: str = "", rok: str = "",
              amsg: str = "", aok: str = "", smsg: str = "", pmsg: str = "", pok: str = "", new_key: str = "",
              theme: str | None = None, palette: str | None = None, font: str | None = None, admin_open: bool = False,
              admmsg: str = "", admok: str = "", hmsg: str = "", hok: str = "") -> str:
    ts = int(time.time())
    groups = groups or set()
    return render(f"""<h1>Your Concourse Multi-Pass</h1>
<p class="who">Signed in as <b>{html.escape(user)}</b></p>
{setup_block(user, ts, smsg)}
{resync_block(user, ts, smsg)}
{requests_block(user, ts, amsg, aok)}
{podpanels_block(user, ts, pmsg, pok, new_key)}
{admin_bays_block(user, groups)}
{home_block(user, groups, ts, hmsg, hok)}
{admin_block(user, groups, ts, admmsg, admok, admin_open)}
{stats_block()}
{directory(user, groups)}
{fold("passfold", "Your pass", "Change your password · Ask for a new username",
      fold("pwfold", "Change your password", "One password for the gate and every Bay", password_form(user, ts, msg) + '<p class="note">Forgot your current password? <a href="/forgot">Ask for a new one</a> (Eels checks it\'s you first).</p>', open_=bool(msg), sub=True)
      + fold("unfold", "Ask for a new username", "Eels makes the change by hand", username_form(user, ts, rmsg, rok), open_=bool(rmsg or rok), sub=True),
      open_=bool(msg or rmsg or rok))}
<section class="sec out"><a class="signout" href="{html.escape(SIGNOUT)}">Sign out</a>
<p class="note">Signs you out of the whole station on this browser. You'll land on the sign-in page again.</p></section>""", theme, palette, font)


def result_page(user: str, results: list[tuple[str, str, str]], setup: bool = False) -> str:
    marks = {"ok": "✓", "skip": "–", "fail": "✗"}
    rows = "".join(f'<li class="{s}">{marks[s]} {html.escape(t)}: {html.escape(d)}</li>' for t, s, d in results)
    failed = any(s == "fail" for _, s, _ in results)
    if setup:
        tail = ("<p class='bad'>Some Bays didn't open. The rest are ready. Press <b>Open my Bays</b> again later, "
                "or tell Eels which line is red.</p>" if failed
                else "<p class='note'>Your Bays are ready. Phone and TV apps use the same username and password.</p>")
        return render(f"<h1>Welcome aboard, {html.escape(user)}</h1><ul>{rows}</ul>{tail}"
                                "<p><a href='/'>Back to your Multi-Pass</a></p>")
    tail = ("<p class='bad'>Some apps didn't take it. Your gate password <b>did</b> change; tell Eels which line is red.</p>"
            if failed else "<p class='note'>Phone and TV apps: sign out and back in with the new password when they ask.</p>")
    return render(f"<h1>Done, {html.escape(user)}</h1><ul><li class='ok'>✓ The gate (Authelia): updated</li>{rows}</ul>{tail}<p><a href='/'>Back to your Multi-Pass</a></p>")


def result_json(results: list[tuple[str, str, str]]) -> dict:
    lines = [{"kind": "ok", "text": "The gate (sign-in): updated"}] + [
        {"kind": s, "text": f"{t}: {'updated' if s == 'ok' else d}"} for t, s, d in results]
    failed = any(s == "fail" for _, s, _ in results)
    return {"ok": True, "title": "Password changed everywhere" if not failed else "Password changed, with a problem",
            "lines": lines,
            "message": ("Some apps didn't take it. Your gate password did change; tell Eels which line is red." if failed
                        else "Phone and TV apps: sign out and back in with the new password when they ask.")}


# The form "schemas" ff.js asks for (GET /s/<form>): the fields and their autofill hints. No secrets in here.
SCHEMAS = {
    "password": {"id": "password", "fields": [{"name": "current", "autocomplete": "current-password"},
                                              {"name": "new1", "autocomplete": "new-password"},
                                              {"name": "new2", "autocomplete": "new-password"}]},
    "username": {"id": "username", "fields": [{"name": "wanted", "max": 32}, {"name": "note", "max": 300}]},
    "join": {"id": "join", "fields": [{"name": "name", "max": 60}, {"name": "username", "max": 32},
                                      {"name": "contact", "max": 120}, {"name": "new1", "autocomplete": "new-password"},
                                      {"name": "new2", "autocomplete": "new-password"}, {"name": "note", "max": 300}]},
    "forgot": {"id": "forgot", "fields": [{"name": "username", "max": 32}, {"name": "name", "max": 60},
                                          {"name": "contact", "max": 120}, {"name": "new1", "autocomplete": "new-password"},
                                          {"name": "new2", "autocomplete": "new-password"}, {"name": "note", "max": 300}]},
}
PUBLIC_GET = ("/join", "/join/", "/s/join", "/forgot", "/forgot/", "/s/forgot")      # the only pages nginx lets through without the gate (with the files below)
PUBLIC_POST = ("/f/join", "/c/join", "/f/forgot")


def parse_form(ctype: str, body: bytes) -> dict[str, str]:
    """Text fields from a urlencoded or multipart form (ff.js sends FormData, plain browsers send urlencoded)."""
    ctype_main = ctype.split(";", 1)[0].strip().lower()
    if ctype_main == "multipart/form-data":
        from email.parser import BytesParser
        from email.policy import HTTP
        msg = BytesParser(policy=HTTP).parsebytes(b"Content-Type: " + ctype.encode("latin-1", "replace") + b"\r\n\r\n" + body)
        out: dict[str, str] = {}
        for part in msg.iter_parts():
            name = part.get_param("name", header="content-disposition")
            if name and part.get_filename() is None:
                out.setdefault(name, part.get_payload(decode=True).decode("utf-8", "replace"))
        return out
    return {k: v[0] for k, v in urllib.parse.parse_qs(body.decode("utf-8", "replace")).items()}


APP_JS = """(function () {
  document.addEventListener('click', function (ev) {
    var b = ev.target.closest('button.copy');
    if (!b) return;
    var text = b.getAttribute('data-copy'), tag = b.querySelector('.ck');
    function done(ok) {
      if (window.getSelection) window.getSelection().removeAllRanges();
      tag.textContent = ok ? 'Copied' : 'Press and hold to copy';
      b.classList.toggle('done', ok);
      setTimeout(function () { tag.textContent = 'Copy'; b.classList.remove('done'); }, 1800);
    }
    function fallback() {
      var t = document.createElement('textarea');
      t.value = text; t.setAttribute('readonly', ''); t.style.position = 'fixed'; t.style.opacity = '0';
      document.body.appendChild(t); t.select();
      var ok = false; try { ok = document.execCommand('copy'); } catch (e) {}
      document.body.removeChild(t); return ok;
    }
    if (navigator.clipboard && window.isSecureContext) {
      navigator.clipboard.writeText(text).then(function () { done(true); }, function () { done(fallback()); });
    } else { done(fallback()); }
  });
  function stats() {
    var box = document.getElementById('stats'), sum = document.getElementById('statsum'),
        fold = document.getElementById('statsfold');
    if (!box) return;
    var COLORS = ['#e0b84c', '#c1121f', '#b78cff', '#5ff2ff', '#9dff7a', '#ef7a1a', '#ff4f8b', '#6b7280'];
    function el(tag, cls, text) { var n = document.createElement(tag); if (cls) n.className = cls; if (text != null) n.textContent = text; return n; }
    function num(v) { return typeof v === 'number' ? v.toLocaleString() : '–'; }
    function remember(d, key) {
      try { if (localStorage.getItem(key) === '1') d.open = true; } catch (e) {}
      d.addEventListener('toggle', function () { try { localStorage.setItem(key, d.open ? '1' : '0'); } catch (e) {} });
    }
    if (fold) remember(fold, 'eo-stats-open');
    Array.prototype.forEach.call(document.querySelectorAll('details[data-remember]'), function (d) { if (d.id) remember(d, 'eo-fold-' + d.id); });
    function say(t) { if (sum) sum.textContent = t; }
    function bar(b) {
      var total = 0; b.parts.forEach(function (p) { total += p.value; });
      var wrap = el('div', 'sbar'), strip = el('div', 'strip'), legend = el('ul', 'legend');
      wrap.appendChild(el('h4', null, b.title));
      strip.setAttribute('role', 'img');
      strip.setAttribute('aria-label', b.title + ': ' + b.parts.map(function (p) { return p.name + ' ' + Math.round(100 * p.value / total) + '%'; }).join(', '));
      b.parts.forEach(function (p, i) {
        var seg = el('span'); seg.style.width = (100 * p.value / total) + '%'; seg.style.background = COLORS[i % COLORS.length];
        strip.appendChild(seg);
        var li = el('li'); var dot = el('i'); dot.style.background = COLORS[i % COLORS.length];
        li.appendChild(dot); li.appendChild(el('b', null, p.name));
        li.appendChild(el('span', null, Math.round(100 * p.value / total) + '% · ' + p.value.toLocaleString() + ' ' + (p.value === 1 ? b.unit.replace(/s$/, '') : b.unit)));
        legend.appendChild(li);
      });
      wrap.appendChild(strip); wrap.appendChild(legend);
      return wrap;
    }
    var x = new XMLHttpRequest();
    x.open('GET', '/api/stats');
    x.onload = function () {
      if (x.status !== 200) { say('Couldn’t reach the apps just now'); return; }
      var s = {}; try { s = JSON.parse(x.responseText); } catch (e) {}
      var bays = s.bays || {}, names = s.names || {}, heads = [];
      box.textContent = '';
      Object.keys(bays).forEach(function (id) {
        var r = bays[id], tiles = (r.tiles || []).filter(function (t) { return typeof t.n === 'number'; });
        if (!tiles.length && !(r.bars || []).length) return;
        var d = el('details', 'bayfold'), sm = el('summary');
        sm.appendChild(el('b', null, names[id] || id));
        sm.appendChild(el('span', null, tiles.slice(0, 2).map(function (t) { return num(t.n) + ' ' + t.label; }).join(' · ')));
        d.appendChild(sm);
        var body = el('div', 'baybody'), grid = el('div', 'stats');
        tiles.forEach(function (t) { var c = el('div', 'stat'); c.appendChild(el('b', null, num(t.n))); c.appendChild(el('span', null, t.label)); grid.appendChild(c); });
        body.appendChild(grid);
        var bars = (r.bars || []).filter(function (b) { return b.parts && b.parts.length; }), facts = r.facts || [], lists = r.lists || [];
        function factList(fs) {
          var dl = el('dl', 'facts');
          fs.forEach(function (f) { dl.appendChild(el('dt', null, f.label)); dl.appendChild(el('dd', null, f.value)); });
          return dl;
        }
        if (bars[0]) body.appendChild(bar(bars[0]));
        if (facts.length) body.appendChild(factList(facts.slice(0, 4)));
        var restBars = bars.slice(1), restFacts = facts.slice(4);
        if (restBars.length || lists.length || restFacts.length) {
          var more = el('details', 'more'), ms = el('summary');
          var bits = [];
          if (lists.length) bits.push(lists.length + (lists.length === 1 ? ' top-10 list' : ' top-10 lists'));
          if (restBars.length) bits.push(restBars.length + (restBars.length === 1 ? ' more chart' : ' more charts'));
          if (restFacts.length) bits.push(restFacts.length + (restFacts.length === 1 ? ' more fact' : ' more facts'));
          ms.appendChild(el('b', null, 'More'));
          ms.appendChild(el('span', null, bits.join(' \u00b7 ')));
          more.appendChild(ms);
          var mb = el('div', 'baybody');
          if (lists.length) {
            var rk = el('div', 'ranks');
            lists.forEach(function (l) {
              var col = el('div', 'rank'); col.appendChild(el('h4', null, l.title));
              var ol = el('ol');
              l.items.forEach(function (it) { var li = el('li'); li.appendChild(el('b', null, it.name)); li.appendChild(el('span', null, it.value.toLocaleString() + ' ' + (it.value === 1 ? l.unit.replace(/s$/, '') : l.unit))); ol.appendChild(li); });
              col.appendChild(ol); rk.appendChild(col);
            });
            mb.appendChild(rk);
          }
          restBars.forEach(function (b) { mb.appendChild(bar(b)); });
          if (restFacts.length) mb.appendChild(factList(restFacts));
          more.appendChild(mb);
          remember(more, 'eo-stats-more-' + id);
          body.appendChild(more);
        }
        d.appendChild(body);
        remember(d, 'eo-stats-' + id);
        box.appendChild(d);
        if (tiles[0] && tiles[0].n > 0 && heads.length < 3) heads.push(num(tiles[0].n) + ' ' + tiles[0].label);
      });
      if (!box.children.length) box.appendChild(el('p', 'note', 'Nothing counted yet. Watch, listen or read a little, then look again.'));
      say(heads.length ? heads.join(' · ') : 'Nothing counted yet');
    };
    x.onerror = function () { say('Couldn’t reach the apps just now'); };
    x.send();
  }
  document.addEventListener('input', function (ev) {
    var r = ev.target;
    if (r.type !== 'range') return;
    var o = r.parentNode.querySelector('output');
    if (o) o.textContent = r.value;
  });
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', stats); else stats();
})();
"""
# The ADMIN section, the six themes and the seven palettes (served as /look.css: the page's policy allows only its own stylesheets).
LOOK_CSS = r"""/* ---- palettes: a hue for the theme's own tones, and two accents ---- */
.p-1{--h:42;--a1:#e0b84c;--a2:#e5484d}
.p-2{--h:355;--a1:#ff4d5e;--a2:#ffb347}
.p-3{--h:186;--a1:#2ee6d6;--a2:#ff4fb0}
.p-4{--h:262;--a1:#a593ff;--a2:#ffb547}
.p-5{--h:150;--a1:#3fdc8a;--a2:#e6e15a}
.p-6{--h:20;--a1:#ff8a3d;--a2:#4dc8ff}
.p-7{--h:210;--a1:#8ec5ff;--a2:#f2f2f2}

/* ---- every theme: the page's parts painted from the theme's variables ---- */
body.skin{background:var(--bg);color:var(--ink);font-family:var(--font)}
.skin main{background:var(--panel);border-color:var(--line);border-radius:var(--radius)}
.skin a{color:var(--link,var(--accent))}
.skin h1{color:var(--accent);font-family:var(--head,var(--font))}
.skin h2,.skin .adm h3{color:var(--accent);font-family:var(--head,var(--font))}
.skin .who,.skin .note,.skin .bay p,.skin .stat i,.skin .bay .app,.skin .person .dn,.skin .adm h4,.skin details.admin>summary i{color:var(--muted)}
.skin .who b,.skin .stat b,.skin .bay code,.skin button.copy code,.skin .bay .bh b{color:var(--ink)}
.skin .stat,.skin .bay,.skin .card,.skin .req,.skin .person,.skin button.copy{background:var(--card);border-color:var(--line);border-radius:var(--r2)}
.skin .bay.deck{border-left-color:var(--accent)}.skin .bay.deck .st{color:var(--accent)}
.skin button.copy .ck{color:var(--accent)}.skin button.copy:hover,.skin button.copy:focus-visible{border-color:var(--accent)}
.skin details.admin{background:var(--card);border-color:var(--line);border-radius:var(--radius)}
.skin details.admin>summary{color:var(--accent2)}
.skin .ff-start-btn{background:var(--card);border-color:var(--line);color:var(--ink);border-radius:var(--r2)}
.skin .ff-start-btn:hover,.skin .ff-start-btn:focus-visible{border-color:var(--accent)}
.skin .signin,.skin .ff-next-btn{background:var(--accent);color:var(--on-accent);border-radius:var(--r2)}
.skin .act>button[type=submit]{background:var(--accent2);color:var(--on-accent2,#0b0d12);border-radius:var(--r2)}
.skin .act{--ff-accent:var(--accent)}
.skin .act.ff-expanded{background:var(--card);border-color:var(--line);border-radius:var(--radius)}
.skin .act input,.skin .admin input[type=text],.skin .admin input[type=password]{background:var(--field);border-color:var(--line);color:var(--ink);border-radius:var(--r3,6px)}
.skin .chip{border-color:var(--line);color:var(--accent)}
.skin .dial output{color:var(--accent)}.skin .dial input{accent-color:var(--accent)}
.skin .admin .yes{background:var(--accent);color:var(--on-accent)}.skin .admin .no{background:var(--field);color:var(--ink);box-shadow:inset 0 0 0 1px var(--line)}
.skin .switch span{background:var(--field);box-shadow:inset 0 0 0 1px var(--line)}.skin .switch input:checked+span{background:var(--accent)}
.skin .look:has(input:checked),.skin .pal:has(input:checked){border-color:var(--accent);box-shadow:inset 0 0 0 2px var(--accent)}

/* ---- the ADMIN section ---- */
nav.jump{display:none}
details.admin{margin-top:1.4rem;border:1px solid #6b5a2a}
details.admin>summary{list-style:none;cursor:pointer;display:flex;align-items:center;gap:1rem;padding:.8rem 1rem;font-weight:800;letter-spacing:.22em;text-transform:uppercase}
details.admin>summary::-webkit-details-marker{display:none}
details.admin>summary::after{content:"+";font-size:1.3rem;line-height:1}
details.admin[open]>summary::after{content:"\2013"}
details.admin>summary i{font-style:normal;font-weight:600;letter-spacing:.03em;text-transform:none;font-size:.85rem;margin-left:auto}
.adm-grid{display:grid;gap:1rem;padding:0 1rem 1rem}
@media (min-width:48rem){.adm-grid{grid-template-columns:1fr 1fr}}
.adm h3{margin:0 0 .5rem;font-size:.8rem;letter-spacing:.14em;text-transform:uppercase}
.adm h4{margin:.9rem 0 .3rem;font-size:.72rem;letter-spacing:.12em;text-transform:uppercase}
.card,.req,.person{border:1px solid #2a2d36;padding:.7rem .8rem;margin-bottom:.6rem}
.person>summary{cursor:pointer;display:flex;flex-wrap:wrap;gap:.45rem;align-items:baseline}
.person .dn{font-size:.85rem}
.chip{font-size:.68rem;padding:.08rem .45rem;border-radius:999px;border:1px solid;text-transform:uppercase;letter-spacing:.06em}
.skin .chip.off{border-color:#c1121f;color:#e5484d}
.admin .row{display:flex;flex-wrap:wrap;gap:.5rem 1rem;align-items:end;margin:.5rem 0}
.admin label{font-size:.85rem}
.admin input[type=text],.admin input[type=password]{display:block;margin-top:.2rem;padding:.45rem .55rem;border:1px solid #444;font:inherit;width:11rem;max-width:100%;box-sizing:border-box}
.admin button{padding:.55rem 1rem;border-radius:8px;border:0;font:700 .9rem system-ui,sans-serif;cursor:pointer;margin:.2rem .4rem .2rem 0}
.chk{display:inline-flex;gap:.35rem;align-items:center}
.looks{display:grid;grid-template-columns:repeat(auto-fill,minmax(7.5rem,1fr));gap:.5rem}
.look{position:relative;display:block;border:1px solid var(--line,#2a2d36);border-radius:10px;padding:2.6rem .6rem .5rem;cursor:pointer;font-size:.85rem}
.look input,.pal input{position:absolute;opacity:0}
.look .sw{position:absolute;top:.45rem;left:.45rem;right:.45rem;height:1.8rem;border-radius:6px;box-shadow:inset 0 0 0 1px rgba(128,128,128,.4)}
.look-modern .sw{background:linear-gradient(90deg,#1b1f27 55%,#e0b84c 55% 78%,#e5484d 78%);border-radius:10px}
.look-hitek .sw{background:repeating-linear-gradient(0deg,#040a0b 0 3px,#0b1517 3px 4px),#040a0b;border-left:10px solid #2ee6d6;border-right:10px solid #ff4fb0;border-radius:0}
.look-synthwave .sw{background:linear-gradient(180deg,#ff4fb0,#ffb347 48%,#1a0533 50%)}
.look-pixel .sw{background:conic-gradient(#2a2340 25%,#3a3158 0 50%,#2a2340 0 75%,#3a3158 0) 0 0/10px 10px;border-radius:0;box-shadow:3px 3px 0 #000}
.look-kingdom .sw{background:linear-gradient(90deg,#2a1d12,#4a3320);outline:3px double #c9a24a;outline-offset:-5px}
.look-clinical .sw{background:radial-gradient(circle at 85% 40%,rgba(130,20,20,.35) 0 .5rem,transparent .55rem),#f4f6f6;border-left:8px solid #b3121b}
.look a{display:block;font-size:.75rem;margin-top:.15rem}
.pals{display:flex;flex-wrap:wrap;gap:.45rem}
.pal{position:relative;display:inline-flex;align-items:center;gap:.4rem;padding:.3rem .55rem .3rem .3rem;border:1px solid var(--line,#2a2d36);border-radius:999px;font-size:.8rem;cursor:pointer}
.pal span{width:1.5rem;height:1.5rem;border-radius:50%;background:linear-gradient(135deg,var(--a1) 50%,var(--a2) 50%)}
.dial{display:block;margin:.5rem 0}.dial output{font-weight:800}.dial input{display:block;width:100%}
.switch{position:relative;display:flex;align-items:center;gap:.6rem;margin:.45rem 0;cursor:pointer}
.switch input{position:absolute;opacity:0}
.switch span{flex:none;width:2.4rem;height:1.35rem;border-radius:999px;position:relative;transition:background-color .2s}
.switch span::after{content:"";position:absolute;top:.15rem;left:.15rem;width:1.05rem;height:1.05rem;border-radius:50%;background:#f4f4f4;box-shadow:0 1px 2px rgba(0,0,0,.4);transition:transform .2s}
.switch input:checked+span::after{transform:translateX(1.05rem)}
.switch input:focus-visible+span,.pal input:focus-visible+span{outline:2px solid currentColor;outline-offset:2px}
.flash{margin:0 1rem .6rem}details.admin>.note{margin:0;padding:0 1rem 1rem}
@media (prefers-reduced-motion:reduce){.switch span,.switch span::after{transition:none}}

/* ---- Modern: quiet, rounded, roomy; Bays three across on a wide screen ---- */
.t-modern{--font:system-ui,-apple-system,"Segoe UI",Roboto,sans-serif;--bg:hsl(var(--h) 16% 7%);--panel:hsl(var(--h) 14% 10%);
  --card:hsl(var(--h) 12% 13%);--field:hsl(var(--h) 12% 8%);--line:hsl(var(--h) 12% 21%);--ink:#eef0f3;--muted:hsl(var(--h) 8% 64%);
  --accent:var(--a1);--accent2:var(--a2);--on-accent:#0b0d12;--radius:22px;--r2:14px;--r3:10px}
.t-modern main{width:min(96vw,66rem);border:0;box-shadow:0 24px 70px rgba(0,0,0,.4);padding:2rem}
.t-modern h1{text-transform:none;letter-spacing:-.01em;font-size:2rem;font-weight:800}
.t-modern h2{letter-spacing:.12em}
.t-modern .stat{border:0;background:linear-gradient(160deg,hsl(var(--h) 14% 16%),hsl(var(--h) 12% 12%))}
.t-modern .stat b{font-size:1.9rem;color:var(--accent)}
.t-modern .bay{border-width:0 0 0 4px}
@media (min-width:56rem){.t-modern .grid{grid-template-columns:repeat(3,1fr)}.t-modern .actions{max-width:none;grid-template-columns:1fr 1fr;align-items:start}}

/* ---- Hi-tek: cyberpunk console. Scanlines, cut corners, mono type, two columns ---- */
.t-hitek{--font:ui-monospace,"Cascadia Mono",Menlo,Consolas,monospace;--bg:hsl(var(--h) 45% 3%);--panel:hsl(var(--h) 45% 5%);
  --card:hsl(var(--h) 50% 7%);--field:hsl(var(--h) 50% 4%);--line:color-mix(in srgb,var(--a1) 32%,transparent);--ink:hsl(var(--h) 55% 90%);
  --muted:hsl(var(--h) 22% 60%);--accent:var(--a1);--accent2:var(--a2);--on-accent:#020607;--radius:0;--r2:0;--r3:0}
body.t-hitek{background:repeating-linear-gradient(0deg,transparent 0 3px,rgba(255,255,255,.028) 3px 4px),var(--bg)}
.t-hitek main{width:min(96vw,76rem);border:1px solid var(--line);clip-path:polygon(0 0,calc(100% - 22px) 0,100% 22px,100% 100%,22px 100%,0 calc(100% - 22px))}
.t-hitek h1{letter-spacing:.26em;text-shadow:0 0 14px var(--a1)}
.t-hitek h2::before{content:"// ";color:var(--accent2)}
.t-hitek .stat,.t-hitek .bay,.t-hitek .card,.t-hitek .person,.t-hitek .ff-start-btn{clip-path:polygon(0 0,calc(100% - 10px) 0,100% 10px,100% 100%,10px 100%,0 calc(100% - 10px))}
.t-hitek .stat b{color:var(--accent);text-shadow:0 0 10px color-mix(in srgb,var(--a1) 60%,transparent)}
.t-hitek .signin,.t-hitek .ff-next-btn,.t-hitek .act>button[type=submit]{text-transform:uppercase;letter-spacing:.14em}
.t-hitek details.admin>summary{text-shadow:0 0 10px var(--a2)}
@media (min-width:60rem){.t-hitek main{display:grid;grid-template-columns:1fr 1fr;column-gap:1.8rem;align-items:start}
  .t-hitek header.top{grid-column:1/-1;grid-row:1}.t-hitek details.admin{grid-column:1/-1;grid-row:2}
  .t-hitek .stats-sec{grid-column:1;grid-row:3}.t-hitek .pass{grid-column:1;grid-row:4}.t-hitek .bays{grid-column:2;grid-row:3/span 2}}

/* ---- Synthwave: a retro sunset sky over a grid floor, chrome-gradient titles ---- */
.t-synthwave{--font:"Trebuchet MS","Segoe UI",system-ui,sans-serif;--bg:#0d0220;--panel:rgba(14,3,34,.82);--card:rgba(30,8,62,.78);
  --field:rgba(8,1,22,.9);--line:color-mix(in srgb,var(--a2) 45%,transparent);--ink:#fbeaff;--muted:#b9a2d6;
  --accent:var(--a1);--accent2:var(--a2);--on-accent:#12021f;--radius:8px;--r2:6px}
body.t-synthwave{background:linear-gradient(180deg,#0d0220 0%,hsl(var(--h) 70% 14%) 30%,color-mix(in srgb,var(--a2) 55%,#2a0645) 52%,#0d0220 52.2%) 0 0/100% 100vh no-repeat #0d0220}
body.t-synthwave::before{content:"";position:fixed;left:-50%;right:-50%;bottom:0;height:48vh;z-index:-1;pointer-events:none;
  background:repeating-linear-gradient(90deg,color-mix(in srgb,var(--a1) 45%,transparent) 0 2px,transparent 2px 80px),
             repeating-linear-gradient(0deg,color-mix(in srgb,var(--a1) 45%,transparent) 0 2px,transparent 2px 60px);
  transform:perspective(320px) rotateX(58deg);transform-origin:50% 100%}
.t-synthwave main{width:min(96vw,62rem);border:1px solid var(--line);box-shadow:0 0 0 1px rgba(0,0,0,.4),0 30px 80px rgba(0,0,0,.55)}
.t-synthwave h1{font-style:italic;font-size:2rem;letter-spacing:.12em;background:linear-gradient(180deg,#fff 0%,var(--a1) 48%,var(--a2) 52%,#fff 100%);-webkit-background-clip:text;background-clip:text;color:transparent}
.t-synthwave h2{font-style:italic;letter-spacing:.2em;color:var(--accent2)}
.t-synthwave .stat b{color:var(--accent)}
.t-synthwave .signin,.t-synthwave .ff-next-btn{background:linear-gradient(90deg,var(--a2),var(--a1))}
@media (min-width:56rem){.t-synthwave .stats{grid-template-columns:repeat(4,1fr)}}

/* ---- Pixel: the 16-bit look. Hard edges, stepped shadows, a checkered floor, a menu bar ---- */
.t-pixel{--font:ui-monospace,"Lucida Console",Consolas,monospace;--bg:hsl(var(--h) 30% 9%);--panel:hsl(var(--h) 32% 14%);
  --card:hsl(var(--h) 34% 19%);--field:hsl(var(--h) 34% 10%);--line:#000;--ink:#f6f2e6;--muted:hsl(var(--h) 18% 70%);
  --accent:var(--a1);--accent2:var(--a2);--on-accent:#000;--radius:0;--r2:0;--r3:0}
body.t-pixel{background:conic-gradient(hsl(var(--h) 30% 9%) 25%,hsl(var(--h) 30% 12%) 0 50%,hsl(var(--h) 30% 9%) 0 75%,hsl(var(--h) 30% 12%) 0) 0 0/24px 24px;font-weight:700}
.t-pixel main{width:min(96vw,58rem);border:4px solid #000;box-shadow:8px 8px 0 #000,inset 0 0 0 4px hsl(var(--h) 30% 24%)}
.t-pixel h1{text-shadow:3px 3px 0 var(--a2);letter-spacing:.08em}
.t-pixel h2{letter-spacing:.1em}.t-pixel h2::before{content:"\25B6  "}
.t-pixel .stat,.t-pixel .bay,.t-pixel .card,.t-pixel .person,.t-pixel details.admin,.t-pixel button.copy,.t-pixel .ff-start-btn{border:3px solid #000;box-shadow:4px 4px 0 #000}
.t-pixel .bay{border-left-width:8px}
.t-pixel .signin,.t-pixel .ff-next-btn,.t-pixel .act>button[type=submit],.t-pixel .admin button{border:3px solid #000;box-shadow:4px 4px 0 #000;border-radius:0}
.t-pixel .signin:active,.t-pixel .ff-next-btn:active,.t-pixel .admin button:active{transform:translate(3px,3px);box-shadow:1px 1px 0 #000}
.t-pixel .stat b{color:var(--accent)}
.t-pixel nav.jump{display:flex;gap:0;margin-top:1rem;border:3px solid #000;width:max-content;max-width:100%;flex-wrap:wrap}
.t-pixel nav.jump a{padding:.4rem .8rem;background:var(--card);color:var(--ink);text-decoration:none;text-transform:uppercase;border-right:3px solid #000}
.t-pixel nav.jump a:hover,.t-pixel nav.jump a:focus-visible{background:var(--accent);color:#000}
.t-pixel .switch span,.t-pixel .switch span::after,.t-pixel .pal span,.t-pixel .look,.t-pixel .chip,.t-pixel .pal{border-radius:0}

/* ---- Kingdom: a fantasy RPG ledger. Serif, double gilt borders, ornaments, a quest menu at the side ---- */
.t-kingdom{--font:"Palatino Linotype",Palatino,"Book Antiqua",Georgia,serif;--bg:hsl(var(--h) 28% 6%);--panel:hsl(var(--h) 26% 10%);
  --card:hsl(var(--h) 24% 13%);--field:hsl(var(--h) 26% 8%);--line:color-mix(in srgb,var(--a1) 45%,#2a2016);--ink:#f1e6cf;--muted:#bba98a;
  --accent:var(--a1);--accent2:var(--a2);--on-accent:#1a1208;--radius:6px;--r2:4px}
body.t-kingdom{background:radial-gradient(ellipse at 50% 0%,hsl(var(--h) 30% 13%),var(--bg) 70%) 0 0/100% 100vh no-repeat var(--bg)}
.t-kingdom main{width:min(98vw,74rem);background:transparent;border:0;padding:1rem}
.t-kingdom header.top,.t-kingdom .sec,.t-kingdom details.admin{background:var(--panel);border:3px double var(--line);border-radius:var(--radius);padding:1.2rem 1.3rem;margin-top:1rem}
.t-kingdom details.admin{padding:0}
.t-kingdom h1{font-variant:small-caps;text-transform:none;letter-spacing:.06em;font-size:1.6rem;text-align:center}
.t-kingdom h1::before,.t-kingdom h1::after{content:" \2726 ";color:var(--accent2)}
.t-kingdom .who{text-align:center;font-style:italic}
.t-kingdom h2{display:flex;align-items:center;gap:.7rem;font-variant:small-caps;text-transform:none;letter-spacing:.08em;font-size:1.05rem}
.t-kingdom h2::before,.t-kingdom h2::after{content:"";flex:1;height:1px;background:var(--line)}
.t-kingdom .stat,.t-kingdom .bay,.t-kingdom .card,.t-kingdom .person{border-style:double;border-width:3px}
.t-kingdom .stat b{color:var(--accent);font-size:1.8rem}
.t-kingdom details.admin>summary{font-variant:small-caps;letter-spacing:.12em}
.t-kingdom nav.jump{display:flex;flex-wrap:wrap;gap:.35rem;margin-top:1rem;justify-content:center}
.t-kingdom nav.jump a{padding:.4rem .8rem;border:1px solid var(--line);color:var(--ink);text-decoration:none;font-variant:small-caps;letter-spacing:.06em}
.t-kingdom nav.jump a::before{content:"\2694  ";color:var(--accent)}
.t-kingdom nav.jump a:hover,.t-kingdom nav.jump a:focus-visible{background:var(--accent);color:var(--on-accent)}
@media (min-width:60rem){.t-kingdom main{display:grid;grid-template-columns:16rem minmax(0,1fr);column-gap:1.2rem;align-items:start}
  .t-kingdom header.top{grid-column:1;grid-row:1/span 6;position:sticky;top:1rem}
  .t-kingdom nav.jump{flex-direction:column}.t-kingdom main>:not(header){grid-column:2}}

/* ---- Clinical: a horror ward's patient chart. Sterile and pale, mono labels, a red cross, a stain ---- */
.t-clinical{--font:system-ui,"Segoe UI",Roboto,sans-serif;--head:ui-monospace,"Cascadia Mono",Menlo,Consolas,monospace;
  --bg:hsl(var(--h) 28% 88%);--panel:hsl(var(--h) 30% 98%);--card:#fff;--field:#fff;--line:hsl(var(--h) 22% 76%);--ink:#1c2226;--muted:#5d686d;
  --accent:color-mix(in srgb,var(--a1) 55%,#000);--accent2:#a3121b;--link:color-mix(in srgb,var(--a1) 45%,#000);--on-accent:#fff;--on-accent2:#fff;
  --radius:3px;--r2:3px;--r3:3px}
.t-clinical main{width:min(96vw,74rem);border:1px solid var(--line);border-left:10px solid #a3121b;
  background:radial-gradient(circle at 93% 5%,rgba(120,18,18,.10) 0 3.4rem,transparent 3.5rem),
             radial-gradient(circle at 88% 11%,rgba(120,18,18,.07) 0 1.3rem,transparent 1.4rem),
             radial-gradient(circle at 96% 13%,rgba(120,18,18,.08) 0 .6rem,transparent .65rem),var(--panel)}
.t-clinical h1{text-transform:uppercase;letter-spacing:.14em;color:#1c2226;font-size:1.3rem}
.t-clinical h1::before{content:"+";display:inline-grid;place-items:center;width:1.6rem;height:1.6rem;margin-right:.6rem;background:#a3121b;color:#fff;font-weight:900;vertical-align:.1rem}
.t-clinical .who::before{content:"PATIENT \2014  ";font-family:var(--head);font-size:.8rem;letter-spacing:.12em}
.t-clinical h2{letter-spacing:.16em;border-bottom:2px solid color-mix(in srgb,var(--a1) 60%,transparent);padding-bottom:.35rem}
.t-clinical .stat{border-top:4px solid color-mix(in srgb,var(--a1) 70%,#000)}
.t-clinical .stat b{font-family:var(--head)}
.t-clinical .bay.up .st,.t-clinical .ok{color:#1d6e2c}.t-clinical .bay.down .st,.t-clinical .bad{color:#a3121b}
.t-clinical .admin .yes{background:#1d6e2c}
@media (min-width:60rem){.t-clinical main{display:grid;grid-template-columns:1fr 1fr;column-gap:2rem;align-items:start}
  .t-clinical header.top{grid-column:1/-1;grid-row:1}.t-clinical details.admin{grid-column:1/-1;grid-row:2}
  .t-clinical .stats-sec{grid-column:1;grid-row:3}.t-clinical .pass{grid-column:1;grid-row:4}.t-clinical .bays{grid-column:2;grid-row:3/span 2}}
"""
FF_DIR = Path(os.environ.get("ACCOUNT_FF", "/app/ff"))
FONTS_CSS = fonts_css()   # Formidable's client (ff.js, ff.css), copied here by script 15


class Handler(BaseHTTPRequestHandler):
    server_version = "eo-account"

    def log_message(self, fmt, *args):            # requests are in nginx's log already; ours carries only the events
        pass

    def _send(self, code: int, body: str | bytes, ctype: str = "text/html; charset=utf-8", csp: str | None = None) -> None:
        data = body.encode() if isinstance(body, str) else body
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("X-Frame-Options", "DENY")
        self.send_header("Referrer-Policy", "same-origin")         # same-origin: a plain form post still carries Origin (no-referrer makes it "null")
        self.send_header("Content-Security-Policy", csp or PAGE_CSP)
        self.end_headers()
        self.wfile.write(data)

    def _redirect(self, loc: str) -> None:
        self.send_response(302)
        self.send_header("Location", loc)
        self.send_header("Content-Length", "0")
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("X-Frame-Options", "DENY")
        self.send_header("Referrer-Policy", "same-origin")
        self.send_header("Content-Security-Policy", PAGE_CSP)
        self.end_headers()

    def _json(self, code: int, obj: dict) -> None:
        self._send(code, json.dumps(obj), "application/json")

    def _user(self) -> str | None:
        u = (self.headers.get("Remote-User") or "").strip().lower()
        return u if USER_RE.match(u) else None

    def _groups(self) -> set[str]:
        return {g.strip().lower() for g in (self.headers.get("Remote-Groups") or "").split(",") if g.strip()}

    def _ip(self) -> str:
        return self.headers.get("X-Real-IP", "0.0.0.0")

    def _pods_redirect(self) -> None:
        query = self.path.split("?", 1)[1] if "?" in self.path else ""
        loc = "/admin/pods/"
        if query and "\r" not in query and "\n" not in query and "\\" not in query \
                and (not PODPANELS_KEY or PODPANELS_KEY not in query):
            loc += "?" + query
        return self._redirect(loc)

    def _require_pod_session(self, user: str, method: str) -> bool:
        return self._require_admin_session(user, method, "podpanels")

    def _require_admin_session(self, user: str, method: str, what: str) -> bool:
        """True when Authelia confirms this cookie is `user` and `user` is an admin.
        what = "podpanels" or "access" (only the log word and the refusal text differ).

        Otherwise sends 503 (Authelia unreachable), 401 (a link to the gate sign-in) or 403.
        The cookie is not logged. A second call in the same request does not ask Authelia again.
        """
        if getattr(self, "_pod_session_ok", False):
            return True
        label = "PodPanels" if what == "podpanels" else "The approval"
        verdict, who = authelia_session(method, self.path, self.headers.get("Cookie"))
        if verdict == "down":
            log(f"{what} {user} session check unreachable")
            self.close_connection = True
            self._send(503, f"{label} sign-in check is offline\n", "text/plain; charset=utf-8")
            return False
        if verdict == "anon":
            log(f"{what} {user} session check refused")
            self.close_connection = True
            self._send(401, render(
                "<h1>Sign in first</h1><p><a class='signin' href='"
                + html.escape(SIGN_IN) + "'>Sign in</a></p>"))
            return False
        if verdict != "ok" or who != user or not is_admin(user, self._groups()):   # Remote-Groups comes from nginx, after Authelia
            log(f"{what} {user} session check refused")
            self.close_connection = True
            self._send(403, ("Only an admin can open PodPanels\n" if what == "podpanels"
                             else "Only an admin can answer requests\n"), "text/plain; charset=utf-8")
            return False
        self._pod_session_ok = True
        return True

    def _pods_post(self, user: str | None, path: str, wants_json: bool) -> None:
        """POST /admin/pods/* : Authelia session, signed-in admin, same Origin rule as the other forms,
        body at most 64KB, then the proxy. Make new key is the one path that is not relayed raw."""
        if not user:
            self.close_connection = True
            return self._json(403, {"ok": False, "message": "Sign in first."}) if wants_json else self._send(403, render("<h1>Sign in first</h1>"))
        if not self._require_pod_session(user, "POST"):
            return
        if user not in ADMINS:
            self.close_connection = True
            return self._send(403, "Only an admin can open PodPanels\n", "text/plain; charset=utf-8")
        if (self.headers.get("Origin") or ORIGIN) != ORIGIN:
            self.close_connection = True
            return self._json(403, {"ok": False, "message": "That form came from another website."}) if wants_json \
                else self._send(403, render("<h1>Refused</h1><p>That form came from another website.</p>"))
        raw_n = (self.headers.get("Content-Length") or "0").strip()
        if len(raw_n) > 8 or not raw_n.isdigit():
            self.close_connection = True
            return self._send(400, "Bad request\n", "text/plain; charset=utf-8")
        n = int(raw_n)
        if n > 65536:
            self.close_connection = True
            return self._send(413, "Too big\n", "text/plain; charset=utf-8")
        rotate = path.rstrip("/") == "/admin/pods/rotate"
        limited = podpanels_limited(user, "rotate") if rotate else False
        if limited or podpanels_limited(user, "post"):
            self.close_connection = True
            log(f"podpanels {user} POST rate limit")
            text = "Too many PodPanels requests. Wait and try again."
            if rotate:
                return self._send(429, form_page(user, groups=self._groups(), pmsg=text))
            return self._send(429, text + "\n", "text/plain; charset=utf-8")
        body = self.rfile.read(n) if n else b""
        if rotate:
            return self._podpanels_rotate(user, body)
        return self._podpanels(user, "POST", body)

    def _podpanels(self, user: str, method: str, body: bytes = b"") -> None:
        """Forward one /admin/pods request. The Authelia session is confirmed first. 403 if not admin,
        503 if there is no key, 502 if PodPanels is down. Relays status, body and Content-Type only.
        No iframe, and the proxied page cannot be framed."""
        if not self._require_pod_session(user, method):
            return
        if user not in ADMINS:
            return self._send(403, "Only an admin can open PodPanels\n", "text/plain; charset=utf-8")
        sub = podpanels_log_sub(self.path)
        if method == "POST":
            log(f"podpanels {user} POST {sub}")
        if sub == "/rotate" or sub.startswith("/rotate/"):
            return self._send(405, "Use the Make new key button\n", "text/plain; charset=utf-8")
        if not PODPANELS_KEY:
            return self._send(503, "PodPanels key not installed\n", "text/plain; charset=utf-8")
        if not podpanels_base():
            return self._send(503, "PodPanels service offline\n", "text/plain; charset=utf-8")
        target = podpanels_upstream(self.path)
        if target is None or sub == "refused":
            return self._send(400, "Bad path\n", "text/plain; charset=utf-8")
        headers = podpanels_headers(
            method, user, self.headers.get("Accept"),
            self.headers.get("Content-Type") if method == "POST" else None)
        got = podpanels_fetch(method, target, headers, body if method == "POST" else None, 10)
        if got is None or got == "big":
            return self._send(502, "PodPanels service offline\n", "text/plain; charset=utf-8")
        status, raw, ctype = got
        return self._send(int(status), raw, _clean_ctype(ctype), csp=PROXY_CSP)

    def _podpanels_rotate(self, user: str, body: bytes) -> None:
        """Make new key. The Authelia session is confirmed first. PodPanels generates the key and replaces the
        podman secret. This page shows a 64-hex key once and does not store it. The answer is never logged."""
        if not self._require_pod_session(user, "POST"):
            return
        groups = self._groups()

        def page(msg: str = "", new_key: str = ""):
            return self._send(200, form_page(user, groups=groups, pmsg=msg, new_key=new_key))

        if user not in ADMINS:
            return self._send(403, "Only an admin can open PodPanels\n", "text/plain; charset=utf-8")
        if not PODPANELS_KEY or not podpanels_base():
            return page("Key not installed on the gate (step 16)." if not PODPANELS_KEY else "PodPanels service offline")
        f = parse_form(self.headers.get("Content-Type", ""), body)
        if not check_token(user, f.get("ts", ""), f.get("token", "")):
            return page("That page was open too long. Reload it and press Make new key again.")
        log(f"podpanels {user} POST /rotate")
        headers = podpanels_headers("POST", user, "application/json", "application/json")
        got = podpanels_fetch("POST", podpanels_base() + "/rotate", headers, b"{}", 10)
        if got is None or got == "big":
            return page("PodPanels service offline")
        status, raw, _ctype = got
        if status != 200:
            return page("PodPanels did not rotate the key. Nothing was shown and nothing was saved here.")
        new = ""
        try:
            data = json.loads(raw.decode("utf-8", "replace"))
        except ValueError:
            data = None
        if isinstance(data, dict) and isinstance(data.get("key"), str):
            new = data["key"]
        if not _NEW_KEY_RE.fullmatch(new):
            return page("PodPanels answered, but this page did not show the reply. Nothing was saved here.")
        return page(new_key=new)

    def do_GET(self):
        path = self.path.split("?", 1)[0]
        if path == "/health":
            return self._send(200, "ok\n", "text/plain")
        if path == "/app.js":
            return self._send(200, APP_JS, "text/javascript; charset=utf-8")
        if path == "/look.css":
            return self._send(200, LOOK_CSS + "\n" + FONTS_CSS, "text/css; charset=utf-8")
        m = re.fullmatch(r"/fonts/([a-z0-9]+)\.woff2", path)
        if m and m[1] in FONTS and (FONTS_DIR / f"{m[1]}.woff2").is_file():
            data = (FONTS_DIR / f"{m[1]}.woff2").read_bytes()
            self.send_response(200)
            self.send_header("Content-Type", "font/woff2")
            self.send_header("Content-Length", str(len(data)))
            self.send_header("Cache-Control", "public, max-age=604800")
            self.send_header("X-Content-Type-Options", "nosniff")
            self.end_headers()
            self.wfile.write(data)
            return
        if path in ("/ff/ff.js", "/ff/ff.css"):
            f = FF_DIR / path[4:]
            if not f.is_file():
                return self._send(404, "", "text/plain")
            return self._send(200, f.read_text("utf-8"), "text/javascript; charset=utf-8" if path.endswith(".js") else "text/css; charset=utf-8")
        if path in ("/join", "/join/"):
            return self._send(200, join_page())
        if path == "/s/join":
            ts = int(time.time())
            return self._json(200, {"form": SCHEMAS["join"], "token": f"{ts}:{form_token(JOIN, ts)}"})
        if path in ("/forgot", "/forgot/"):
            return self._send(200, forgot_page())
        if path == "/s/forgot":
            ts = int(time.time())
            return self._json(200, {"form": SCHEMAS["forgot"], "token": f"{ts}:{form_token(FORGOT, ts)}"})
        user = self._user()
        if not user:
            return self._send(403, render(f"<h1>Sign in first</h1><p><a class='signin' href='{html.escape(SIGN_IN)}'>Sign in</a></p>"
                                                    "<p>No pass yet? <a href='/join'>Request access</a>. Forgot your password? <a href='/forgot'>Ask for a new one</a>.</p>"))
        if path in ("/", "/index.html"):
            groups = self._groups()
            q = urllib.parse.parse_qs(self.path.partition("?")[2])
            preview = is_admin(user, groups) and ("theme" in q or "palette" in q)     # an admin's preview, nothing saved
            th = q.get("theme", [""])[0] if preview else None
            pa = q.get("palette", [""])[0] if preview else None
            fo = q.get("font", [None])[0] if preview else None
            return self._send(200, form_page(user, groups=groups, theme=th, palette=pa, font=fo, admin_open=preview))
        if path.startswith("/s/") and path[3:] in SCHEMAS:
            ts = int(time.time())
            return self._json(200, {"form": SCHEMAS[path[3:]], "token": f"{ts}:{form_token(user, ts)}"})
        if path == "/api/stats":
            return self._json(200, user_stats(user))
        if path == "/admin/pods" or path.startswith("/admin/pods/"):
            if not self._require_pod_session(user, "GET"):
                return
            if user not in ADMINS:
                return self._send(403, "Only an admin can open PodPanels\n", "text/plain; charset=utf-8")
            if path == "/admin/pods":
                return self._pods_redirect()
            if path.rstrip("/") == "/admin/pods/rotate":
                return self._send(405, "Use the Make new key button\n", "text/plain; charset=utf-8")
            return self._podpanels(user, "GET")
        return self._send(404, render("<h1>Not here</h1>"))

    def do_POST(self):
        path = self.path.split("?", 1)[0]
        wants_json = "application/json" in (self.headers.get("Accept") or "")
        if path == "/f/forgot":
            return self._forgot_post(wants_json)
        if path in PUBLIC_POST:
            return self._join_post(path, wants_json)
        user = self._user()
        if path == "/admin/pods" or path.startswith("/admin/pods/"):
            return self._pods_post(user, path, wants_json)
        routes = ("/f/password", "/f/username", "/c/password", "/change", "/request", "/admin/access", "/f/resync", "/f/setup",
                  "/admin/user", "/admin/adduser", "/admin/settings", "/admin/home")
        if path not in routes or not user:
            return self._json(403, {"ok": False, "message": "Sign in first."}) if wants_json else self._send(403, render("<h1>Sign in first</h1>"))
        if (self.headers.get("Origin") or ORIGIN) != ORIGIN:
            return self._json(403, {"ok": False, "message": "That form came from another website."}) if wants_json \
                else self._send(403, render("<h1>Refused</h1><p>That form came from another website.</p>"))
        n = int(self.headers.get("Content-Length") or 0)
        if n > 16384:
            return self._json(413, {"ok": False, "message": "Too big."}) if wants_json else self._send(413, render("<h1>Too big</h1>"))
        body = self.rfile.read(n)
        if path == "/c/password":
            return self._check_current(user, body)
        f = parse_form(self.headers.get("Content-Type", ""), body)
        if path == "/admin/access":
            return self._answer_request(user, f)
        if path == "/f/resync":
            return self._resync(user, f)
        if path == "/f/setup":
            return self._setup(user, f)
        if path in ("/admin/user", "/admin/adduser", "/admin/settings"):
            return self._admin(user, path, f)
        if path == "/admin/home":
            return self._home(user, f)
        username_route = path in ("/f/username", "/request")
        if not check_token(user, f.get("ts", ""), f.get("token", "")):
            text = "That form was too old. Please reload the page and type it again."
            if wants_json:
                return self._json(200, {"ok": False, "message": text})
            return self._send(200, form_page(user, groups=self._groups(), rmsg=text) if username_route else form_page(user, text, self._groups()))
        if username_route:
            return self._request(user, f, wants_json)
        return self._change(user, f, wants_json)

    def _brake(self, user: str) -> bool:
        """True when this person has tried too often (5 in 10 minutes): a light brake on top of Authelia's own."""
        now = time.time()
        RECENT[user] = [t for t in RECENT.get(user, []) if now - t < 600] + [now]
        return len(RECENT[user]) > 5

    def _check_current(self, user: str, body: bytes):
        """Step 1 of the password flow: is this their current password? Nothing changes here."""
        try:
            d = json.loads(body or b"{}")
        except ValueError:
            d = {}
        ts, _, tok = str(d.get("token", "")).partition(":")
        if not check_token(user, ts, tok):
            return self._json(200, {"ok": False, "message": "This page was open too long. Please reload it."})
        if self._brake(user):
            return self._json(429, {"ok": False, "message": "Too many tries. Wait ten minutes."})
        if user not in users_in_file():
            return self._json(200, {"ok": False, "message": "Your account isn't in the gate's users file. Ask Eels."})
        ok = authelia_check_password(user, str(d.get("value", "")), self._ip())
        if not ok:
            log(f"check {user}: current password wrong (from {self._ip()})")
        return self._json(200, {"ok": True} if ok else {"ok": False, "message": "That wasn't your current password."})

    def _change(self, user: str, f: dict[str, str], wants_json: bool):
        def refuse(text: str, field: str = "", code: int = 200):
            if wants_json:
                return self._json(code, {"ok": False, "message": text, **({"errors": {field: text}} if field else {})})
            return self._send(code, form_page(user, text, self._groups()))
        cur, new1, new2 = f.get("current", ""), f.get("new1", ""), f.get("new2", "")
        if new1 != new2:
            return refuse("The two new passwords didn't match.", "new2")
        if password_problem(new1):
            return refuse(password_problem(new1), "new1")
        if new1 == cur:
            return refuse("That's the same as the current password.", "new1")
        if self._brake(user):
            return refuse("Too many tries. Wait ten minutes.", code=429)
        ip = self._ip()
        with LOCK:
            if user not in users_in_file():
                return refuse("Your account isn't in the gate's users file. Ask Eels.")
            if not authelia_check_password(user, cur, ip):
                log(f"change {user}: current password wrong (from {ip})")
                return refuse("The current password wasn't right.", "current")
            try:
                authelia_set_password(user, authelia_hash(new1))
            except Exception as e:
                log(f"change {user}: users file not updated: {e}")
                return refuse("The gate couldn't save it, so nothing changed. Tell Eels.", code=500)
            log(f"change {user}: gate password updated (from {ip})")
            STATS.pop(user, None)
            results = sync_apps(user, new1)
            set_resync(user, False)
        if wants_json:
            return self._json(200, result_json(results))
        return self._send(200, result_page(user, results))

    def _request(self, user: str, f: dict[str, str], wants_json: bool):
        groups = self._groups()

        def answer(text: str, sent: bool, field: str = "", code: int = 200):
            if wants_json:
                if sent:
                    return self._json(200, {"ok": True, "title": "Request sent", "message": text})
                return self._json(code, {"ok": False, "message": text, **({"errors": {field: text}} if field else {})})
            return self._send(code, form_page(user, groups=groups, rok=text) if sent else form_page(user, groups=groups, rmsg=text))
        if not FORMS:
            return answer("Username requests aren't switched on. Ask Eels.", False, code=404)
        wanted = re.sub(r"\s+", " ", f.get("wanted", "")).strip()[:32]
        note = re.sub(r"\s+", " ", f.get("note", "")).strip()[:300]
        if not wanted:
            return answer("Type the username you'd like.", False, "wanted")
        if wanted.lower() == user:
            return answer("That's already your username.", False, "wanted")
        now = time.time()
        ASKED[user] = [t for t in ASKED.get(user, []) if now - t < 3600]
        if len(ASKED[user]) >= 3:
            return answer("You've sent 3 requests this hour. Eels has them; please wait.", False, code=429)
        ASKED[user].append(now)
        sent, text = send_rename_request(user, wanted, note, groups, self._ip())
        if not sent:
            ASKED[user].pop()                          # a request that didn't go out doesn't count
        return answer(text, sent)


    def _join_post(self, path: str, wants_json: bool):
        """The public request form. Nobody is signed in here; nothing is created, only a request is kept."""
        def answer(code: int, obj: dict):
            if wants_json:
                return self._json(code, obj)
            body = (f"<h1>{html.escape(obj.get('title', 'Request access'))}</h1><p class='{'ok' if obj.get('ok') else 'bad'}'>"
                    f"{html.escape(obj.get('message', ''))}</p><p><a href='/join'>Back</a></p>")
            return self._send(code, render(body))
        if (self.headers.get("Origin") or ORIGIN) != ORIGIN:
            return answer(403, {"ok": False, "message": "That form came from another website."})
        n = int(self.headers.get("Content-Length") or 0)
        if n > 16384:
            return answer(413, {"ok": False, "message": "Too big."})
        body = self.rfile.read(n)
        ip = self._ip()
        if path == "/c/join":                          # step 2's check: is the username free?
            try:
                d = json.loads(body or b"{}")
            except ValueError:
                d = {}
            ts, _, tok = str(d.get("token", "")).partition(":")
            if not check_token(JOIN, ts, tok):
                return self._json(200, {"ok": False, "message": "This page was open too long. Please reload it."})
            problem = username_problem(str(d.get("value", "")).strip())
            return self._json(200, {"ok": not problem, **({"message": problem} if problem else {})})
        f = parse_form(self.headers.get("Content-Type", ""), body)
        if not setting("accept_requests"):
            return answer(200, {"ok": False, "message": "New passes aren't being handed out right now. Ask Eels directly."})
        if f.get("website"):                           # the hidden field only a robot fills in
            log(f"access request refused: robot field filled (from {ip})")
            return answer(200, {"ok": True, "title": "Request sent", "message": "Thanks."})
        if not check_token(JOIN, f.get("ts", ""), f.get("token", "")):
            return answer(200, {"ok": False, "message": "That page was open too long. Please reload it and try again."})
        name = re.sub(r"\s+", " ", f.get("name", "")).strip()[:60]
        username = f.get("username", "").strip().lower()
        contact = re.sub(r"\s+", " ", f.get("contact", "")).strip()[:120]
        note = re.sub(r"\s+", " ", f.get("note", "")).strip()[:300]
        new1, new2 = f.get("new1", ""), f.get("new2", "")

        def refuse(text: str, field: str = "", code: int = 200):
            return answer(code, {"ok": False, "message": text, **({"errors": {field: text}} if field else {})})
        if not name:
            return refuse("Please tell us your name.", "name")
        if not contact:
            return refuse("Please say how Eels can reach you.", "contact")
        if new1 != new2:
            return refuse("The two passwords didn't match.", "new2")
        if password_problem(new1):
            return refuse(password_problem(new1).replace("new password", "password"), "new1")
        now = time.time()
        JOINED[ip] = [t for t in JOINED.get(ip, []) if now - t < 3600]
        if len(JOINED[ip]) >= 3:
            return refuse("Three requests from your connection this hour already. Eels has them; please wait.", code=429)
        with REQ_LOCK:
            problem = username_problem(username)
            if problem:
                return refuse(problem, "username")
            reqs = load_requests()
            if len(reqs) >= MAX_WAITING:
                return refuse("Eels has a lot of requests waiting right now. Please try again in a few days.", code=429)
            req = {"id": secrets.token_hex(8), "at": int(now), "name": name, "username": username, "contact": contact,
                   "note": note, "hash": authelia_hash(new1), "ip": ip}
            reqs.append(req)
            save_requests(reqs)
        JOINED[ip].append(now)
        log(f"access request: {username} ({name}) from {ip}")
        tell_eels_access(req, ip)
        return answer(200, {"ok": True, "title": "Request sent",
                            "message": f"Eels will look at it and let you know at {contact}. Once you're in, sign in with "
                                       f"“{username}” and the password you just chose: same one for the website and every Bay."})

    def _forgot_post(self, wants_json: bool):
        """The public forgot-password form. Nobody is signed in here; nothing changes, only a request is kept.
        The answer is the same whether or not the username exists, so the page can't be used to find usernames."""
        def answer(code: int, obj: dict):
            if wants_json:
                return self._json(code, obj)
            body = (f"<h1>{html.escape(obj.get('title', 'Forgot password'))}</h1><p class='{'ok' if obj.get('ok') else 'bad'}'>"
                    f"{html.escape(obj.get('message', ''))}</p><p><a href='/forgot'>Back</a></p>")
            return self._send(code, render(body))

        def refuse(text: str, field: str = "", code: int = 200):
            return answer(code, {"ok": False, "message": text, **({"errors": {field: text}} if field else {})})
        if (self.headers.get("Origin") or ORIGIN) != ORIGIN:
            return answer(403, {"ok": False, "message": "That form came from another website."})
        n = int(self.headers.get("Content-Length") or 0)
        if n > 16384:
            return answer(413, {"ok": False, "message": "Too big."})
        f = parse_form(self.headers.get("Content-Type", ""), self.rfile.read(n))
        ip = self._ip()
        sent = {"ok": True, "title": "Request sent",
                "message": "If that username has a pass, Eels will check with you and then switch it on. Your old password "
                           "works until then. Next time you sign in with the new one, your Multi-Pass asks you to set it in every app."}
        if f.get("website"):                           # the hidden field only a robot fills in
            log(f"reset request refused: robot field filled (from {ip})")
            return answer(200, sent)
        if not check_token(FORGOT, f.get("ts", ""), f.get("token", "")):
            return refuse("That page was open too long. Please reload it and try again.")
        username = f.get("username", "").strip().lower()
        name = re.sub(r"\s+", " ", f.get("name", "")).strip()[:60]
        contact = re.sub(r"\s+", " ", f.get("contact", "")).strip()[:120]
        note = re.sub(r"\s+", " ", f.get("note", "")).strip()[:300]
        new1, new2 = f.get("new1", ""), f.get("new2", "")
        if not USER_RE.match(username):
            return refuse("Use the username you sign in with (lowercase letters, numbers, . _ -).", "username")
        if not name:
            return refuse("Please tell us your name.", "name")
        if not contact:
            return refuse("Please say how Eels can reach you.", "contact")
        if new1 != new2:
            return refuse("The two passwords didn't match.", "new2")
        if password_problem(new1):
            return refuse(password_problem(new1).replace("new password", "password"), "new1")
        now = time.time()
        JOINED[ip] = [t for t in JOINED.get(ip, []) if now - t < 3600]
        if len(JOINED[ip]) >= 3:                       # shared with Request access: 3 requests an hour per connection
            return refuse("Three requests from your connection this hour already. Eels has them; please wait.", code=429)
        JOINED[ip].append(now)
        pw_hash = authelia_hash(new1)                  # made for unknown usernames too, so both answers take as long
        if username not in users_in_file():
            log(f"reset request for unknown username {username!r} from {ip}: not kept")
            return answer(200, sent)
        with REQ_LOCK:
            reqs = [r for r in load_requests() if not (r.get("kind") == "reset" and r["username"] == username)]
            if len(reqs) >= MAX_WAITING:
                return refuse("Eels has a lot of requests waiting right now. Please try again in a few days.", code=429)
            req = {"id": secrets.token_hex(8), "kind": "reset", "at": int(now), "name": name, "username": username,
                   "contact": contact, "note": note, "hash": pw_hash, "ip": ip}
            reqs.append(req)
            save_requests(reqs)
        log(f"reset request: {username} ({name}) from {ip}")
        tell_eels_reset(req, ip)
        return answer(200, sent)

    def _resync(self, user: str, f: dict[str, str]):
        """After an approved reset: check the password they type is the gate's new one, then set it in every app."""
        groups = self._groups()
        if user not in load_resync():
            return self._send(200, form_page(user, groups=groups))
        if not check_token(user, f.get("ts", ""), f.get("token", "")):
            return self._send(200, form_page(user, groups=groups, smsg="That page was open too long. Please type it again."))
        if self._brake(user):
            return self._send(429, form_page(user, groups=groups, smsg="Too many tries. Wait ten minutes."))
        pw, ip = f.get("current", ""), self._ip()
        with LOCK:
            if not authelia_check_password(user, pw, ip):
                log(f"resync {user}: password wrong (from {ip})")
                return self._send(200, form_page(user, groups=groups, smsg="That isn't the password you signed in with."))
            STATS.pop(user, None)
            results = sync_apps(user, pw)
            set_resync(user, False)
        log(f"resync {user}: copied to the apps (from {ip})")
        return self._send(200, result_page(user, results))

    def _setup(self, user: str, f: dict[str, str]):
        """First sign-in after Approve: check the password they type is the gate's, then make their Bay accounts.
        If an app fails, they stay on the list and can press again; accounts already made are then left alone."""
        groups = self._groups()
        if user not in load_setup():
            return self._send(200, form_page(user, groups=groups))
        if not check_token(user, f.get("ts", ""), f.get("token", "")):
            return self._send(200, form_page(user, groups=groups, smsg="That page was open too long. Please type it again."))
        if self._brake(user):
            return self._send(429, form_page(user, groups=groups, smsg="Too many tries. Wait ten minutes."))
        pw, ip = f.get("current", ""), self._ip()
        verdict = authelia_password_verdict(user, pw, ip)
        if verdict != "ok":
            log(f"setup {user}: password check {verdict} (from {ip})")
            text = {"wrong": "That isn't the password you signed in with.",
                    "locked": "Too many wrong tries: the gate has locked this for a few minutes. Wait, then try again.",
                    "down": "The sign-in check is offline right now. Nothing was changed; try again in a minute."}[verdict]
            return self._send(503 if verdict == "down" else 200, form_page(user, groups=groups, smsg=text))
        with LOCK:
            STATS.pop(user, None)
            results = setup_apps(user, pw, user_record(user))
            if not any(r[1] == "fail" for r in results):
                set_setup(user, False)
        log(f"setup {user}: done (from {ip})")
        return self._send(200, result_page(user, results, setup=True))

    def _home(self, user: str, f: dict[str, str]):
        """Smart home buttons: one Home Assistant call, checked against the devices it lists right now. Admin only."""
        groups = self._groups()

        def page(msg: str = "", ok: str = ""):
            return self._send(200, form_page(user, groups=groups, hmsg=msg, hok=ok))
        if not is_admin(user, groups):
            return self._send(403, render("<h1>Admins only</h1>"))
        # The same check as the ADMIN section: Authelia confirms the cookie really is this admin.
        if not self._require_admin_session(user, "POST", "access"):
            return
        if not check_token(user, f.get("ts", ""), f.get("token", "")):
            return page("That page was open too long. Here it is again; press the button once more.")
        if home_limited(user):
            log(f"home {user} rate limit")
            return page("Too many changes in a minute. Wait a moment and try again.")
        entity, do, value = f.get("entity", "")[:80], f.get("do", "")[:12], f.get("value", "")[:40]
        ents = home_entities()
        if ents is None:
            return page("Home Assistant isn't answering. Nothing changed.")
        done, text = home_change(entity, do, value, ents)
        if HOME_ENTITY.match(entity):
            log(f"home {user} {do} {entity} {'ok' if done else 'refused'}")
        return page("" if done else text, text if done else "")

    def _answer_request(self, user: str, f: dict[str, str]):
        """Eels's Approve or Decline. Approve writes the account into Authelia's users file (it reloads by itself)."""
        groups = self._groups()

        def page(msg: str = "", ok: str = ""):
            return self._send(200, form_page(user, groups=groups, amsg=msg, aok=ok))
        if user not in ADMINS:
            return self._send(403, render("<h1>Only Eels answers access requests</h1>"))
        # The same Authelia session check as /admin/pods: Remote-User alone is not trusted for an approval.
        if not self._require_admin_session(user, "POST", "access"):
            return
        if not check_token(user, f.get("ts", ""), f.get("token", "")):
            return page("That page was open too long. Here it is again; press the button once more.")
        with REQ_LOCK:
            reqs = load_requests()
            req = next((r for r in reqs if r["id"] == f.get("id")), None)
            if not req:
                return page("That request isn't waiting any more (already answered?).")
            if f.get("do") == "decline":
                save_requests([r for r in reqs if r is not req])
                log(f"{req.get('kind', 'access')} request {req['username']}: declined by {user}")
                return page(ok=f"Declined {req['name']}'s request. It's gone, with the password they chose.")
            if f.get("do") != "approve":
                return page("Press Approve or Decline.")
            if req.get("kind") == "reset":
                who = req["username"]
                if who not in users_in_file():
                    save_requests([r for r in reqs if r is not req])
                    return page(f"{who} isn't in the gate's users file any more, so there was nothing to reset.")
                try:
                    authelia_set_password(who, req["hash"])
                    set_resync(who, True)
                except Exception as e:
                    log(f"reset request {who}: users file not updated: {e}")
                    return page("The gate couldn't save it, so nothing changed. Check: podman logs eo-account")
                save_requests([r for r in reqs if r is not req])
                STATS.pop(who, None)
                log(f"reset request {who}: approved by {user}")
                return page(ok=f"{who}'s new password works on the gate now. Tell them at {req['contact']}. When they next "
                               "sign in, their Multi-Pass asks for it once and sets it in every app.")
            name = f.get("username", "").strip().lower() or req["username"]
            if not USER_RE.match(name):
                return page(f"“{name}” isn't a username the station can use (2 to 32 lowercase letters, numbers, . _ -).")
            if name in users_in_file():
                return page(f"{name} is already in the gate's users file. Pick another name for {req['name']}.")
            email = req["contact"] if re.match(r"^[^@\s]+@[^@\s]+\.[^@\s]+$", req["contact"]) else f"{name}@users.songofeo.com"
            grp = [g for g in ("music", "talk", "archives") if f.get(g) == "1"]   # each off unless ticked
            try:
                authelia_add_user(name, req["name"], email, req["hash"], grp)
            except Exception as e:
                log(f"access request {name}: users file not updated: {e}")
                return page("The gate couldn't save it, so nothing changed. Check: podman logs eo-account")
            try:
                set_setup(name, True)
            except Exception as e:
                log(f"access request {name}: gate account made, setup list not saved: {e}")
                save_requests([r for r in reqs if r is not req])
                return page(f"{name} can sign in to the gate, but their Bay setup couldn't be queued, so their "
                            "Multi-Pass won't offer it. Make their Bay accounts by hand, or check: podman logs eo-account")
            save_requests([r for r in reqs if r is not req])
        log(f"access request {name}: approved by {user} (groups: {', '.join(grp) or 'none'})")
        renamed = f" as {name} (they asked for {req['username']}, so tell them)" if name != req["username"] else ""
        return page(ok=f"{req['name']} is in{renamed}. They sign in with their own password, and their Multi-Pass asks for it "
                       f"once to open their Bays. Let them know at {req['contact']}.")


    def _admin(self, user: str, path: str, f: dict[str, str]):
        """The ADMIN section's buttons: edit a person, switch them off or on, set their password, add someone, settings."""
        groups = self._groups()

        def page(msg: str = "", ok: str = ""):
            return self._send(200, form_page(user, groups=groups, admmsg=msg, admok=ok, admin_open=True))
        if not is_admin(user, groups):
            return self._send(403, render("<h1>Admins only</h1>"))
        # Remote-User alone is not trusted for a change: Authelia confirms the cookie is this admin (ACCOUNT_ADMINS).
        if not self._require_admin_session(user, "POST", "access"):
            return
        if not check_token(user, f.get("ts", ""), f.get("token", "")):
            return page("That page was open too long. Here it is again; press the button once more.")
        chosen = [g for g, _ in GROUPS if f.get("g_" + g) == "1"]
        display = re.sub(r"\s+", " ", f.get("displayname", "")).strip()[:60]
        email = f.get("email", "").strip()[:120]
        if email and not re.match(r"^[^@\s]+@[^@\s]+\.[^@\s]+$", email):
            return page(f"“{email}” isn't an email address.")

        if path == "/admin/settings":
            new = {"theme": f.get("theme") if f.get("theme") in THEMES else setting("theme"),
                   "palette": f.get("palette") if f.get("palette") in PALETTES else str(setting("palette")),
                   "fonts": {t: f.get("font_" + t, "") for t in THEMES if f.get("font_" + t, "") in THEME_FONTS[t]},
                   "accept_requests": f.get("accept_requests") == "1", "username_requests": f.get("username_requests") == "1"}
            for key, (lo, hi) in SETTING_RANGES.items():
                v = f.get(key, "")
                new[key] = max(lo, min(hi, int(v))) if v.isdigit() else setting(key)
            save_settings(new)
            # The password sync's on/off per app: only the "enabled" flag in apps.json changes (logins stay as they are).
            try:
                with LOCK:
                    cfg = json.loads(APPS_FILE.read_text())
                    for k, c in cfg.get("apps", {}).items():
                        if k in KINDS:
                            c["enabled"] = f.get("app_" + k) == "1"
                    tmp = APPS_FILE.with_name(APPS_FILE.name + ".new")
                    tmp.write_text(json.dumps(cfg, indent=2) + "\n")
                    os.chmod(tmp, 0o600)
                    os.replace(tmp, APPS_FILE)
            except (OSError, ValueError) as e:
                log(f"admin {user}: apps.json not changed: {e}")
            log(f"admin {user}: settings saved {json.dumps(new)}")
            return page(ok="Settings saved.")

        name = f.get("name", "").strip().lower()
        if not USER_RE.match(name):
            return page("Use 2 to 32 lowercase letters, numbers, dots, dashes or underscores for the username.")
        new1, new2 = f.get("new1", ""), f.get("new2", "")

        def set_pw() -> str:
            if new1 != new2:
                return "The two passwords didn't match."
            return password_problem(new1).replace("new password", "password")

        if path == "/admin/adduser":
            if name in users_in_file():
                return page(f"{name} is already on the station. Open them under People to change them.")
            problem = set_pw()
            if problem:
                return page(problem)
            with LOCK:
                try:
                    authelia_add_user(name, display or name, email or f"{name}@users.songofeo.com", authelia_hash(new1), chosen)
                except Exception as e:
                    log(f"admin {user}: add {name} failed: {e}")
                    return page("The gate couldn't save it, so nothing changed. Check: podman logs eo-account")
                results = sync_apps(name, new1)
            log(f"admin {user}: added {name} (groups: {', '.join(chosen) or 'none'})")
            got = [t for t, st, _ in results if st == "ok"]
            return page(ok=f"{name} is on the station." + (f" Password also set in: {', '.join(got)}." if got else
                                                           " No app has an account for them yet; make those in each app."))

        person = next((u for u in read_users() if u["name"] == name), None)
        if not person:
            return page(f"{name} isn't in the users file any more.")
        do = f.get("do")
        if do == "password":
            problem = set_pw()
            if problem:
                return page(problem)
            with LOCK:
                try:
                    authelia_set_password(name, authelia_hash(new1))
                except Exception as e:
                    log(f"admin {user}: password for {name} failed: {e}")
                    return page("The gate couldn't save it, so nothing changed.")
                results = sync_apps(name, new1)
            STATS.pop(name, None)
            log(f"admin {user}: set a new password for {name}")
            bad = [t for t, st, _ in results if st == "fail"]
            return page(ok=f"New password set for {name} on the gate and every app that has them."
                        + (f" These didn't take it: {', '.join(bad)}." if bad else ""))
        if do in ("disable", "enable"):
            if name == user:
                return page("You can't switch yourself off.")
            disabled = do == "disable"
            groups_keep, disp, mail = person["groups"], person["displayname"], person["email"]
        elif do == "save":
            if name == user and is_admin(user, groups) and user not in ADMINS and ADMIN_GROUP not in chosen:
                return page("You can't take your own Admin away.")
            known = {g for g, _ in GROUPS}   # groups the page has no tick for (e.g. "talk-dj") are kept as they were
            disabled, groups_keep, disp, mail = person["disabled"], chosen + [g for g in person["groups"] if g not in known], display or person["displayname"], email or person["email"]
        else:
            return page("Press one of the buttons.")
        try:
            authelia_update_user(name, disp, mail, groups_keep, disabled)
        except Exception as e:
            log(f"admin {user}: update {name} failed: {e}")
            return page("The gate couldn't save it, so nothing changed.")
        log(f"admin {user}: {do} {name}")
        return page(ok={"save": f"Saved {name}.", "disable": f"{name} is switched off: the gate won't let them in.",
                        "enable": f"{name} is switched back on."}[do])


# ---------------------------------------------------------------- command line


# ---------------------------------------------------------------- Audiobookshelf library walls
#
# audio. and sessions. phone-app paths skip Authelia and hit this same server, so the Talk and Archives
# group walls only hold if Audiobookshelf itself hides those libraries. Walls match BAYS_DEFAULT
# (and templates/configuration.yml): talk is eels, rachel and group talk; archives is eels and group archives.
# This block is gate code. Cross-check it before it runs on a server.

def authelia_groups(text: str) -> dict[str, set[str]]:
    """username -> group names. Password lines are never returned."""
    users: dict[str, set[str]] = {}
    user: str | None = None
    in_groups = False
    for line in text.splitlines():
        m = re.match(r"^  ([a-z0-9._-]+):\s*$", line)
        if m:
            user = m.group(1)
            users.setdefault(user, set())
            in_groups = False
            continue
        if user is None:
            continue
        if re.match(r"^  \S", line):
            user, in_groups = None, False
            continue
        gm = re.match(r"^    groups:\s*(.*)$", line)
        if gm:
            rest = gm.group(1).strip()
            in_groups = True
            if rest.startswith("[") and rest.endswith("]"):
                inner = rest[1:-1].strip()
                if inner:
                    for part in inner.split(","):
                        name = part.strip().strip("'\"")
                        if name:
                            users[user].add(name)
                in_groups = False
            continue
        if in_groups:
            im = re.match(r"^      - (.+?)\s*$", line)
            if im:
                users[user].add(im.group(1).strip().strip("'\""))
            elif re.match(r"^    \S", line):
                in_groups = False
    return users


def library_walls() -> dict[str, tuple[str, set[str]]]:
    """bay -> (Authelia group, usernames who may enter without that group). From the built-in Bay list."""
    walls: dict[str, tuple[str, set[str]]] = {}
    for bay in BAYS_DEFAULT:
        if bay.get("bay") in ("talk", "archives") and bay.get("need"):
            walls[bay["bay"]] = (bay["need"], {u.casefold() for u in bay.get("also", [])})
    return walls


def _may_enter(username: str, groups: set[str], wall: tuple[str, set[str]]) -> bool:
    group, also = wall
    return username.casefold() in also or group.casefold() in {g.casefold() for g in groups}


def _user_access_all(user: dict) -> bool:
    perms = user.get("permissions") or {}
    if "accessAllLibraries" in perms:
        return bool(perms["accessAllLibraries"])
    return bool(user.get("accessAllLibraries"))


def _user_library_ids(user: dict) -> list[str]:
    perms = user.get("permissions") or {}
    libs = user.get("librariesAccessible")
    if not isinstance(libs, list):
        libs = perms.get("librariesAccessible") or []
    return [i for i in libs if isinstance(i, str)]


def plan_abs_libraries(users: list, libraries: list, groups_by_user: dict[str, set[str]],
                       specs: list | None = None) -> tuple[list[str], list[dict]]:
    """READ-ONLY plan. One WARN line per user who can see a walled library they should not, or who has
    accessAllLibraries on. The returned writes are what apply would send; this function sends nothing."""
    spec_notes: list[str] = []
    if specs is None:
        specs, spec_notes = abs_library_specs()
    claimed = match_abs_libraries(libraries, specs)
    walls = library_walls()
    lines = list(spec_notes)
    claimed_ids = {lib.get("id") for lib in claimed.values()}
    for lib in libraries:
        name = (lib.get("name") or "").strip()
        if lib.get("id") not in claimed_ids and name and _ABS_NAME_HINT.search(name):
            lines.append(f'WARN  libraries  "{name}" matched neither Talk nor Archives, so it was left alone. '
                         "Rename it, or set ABS_LIBRARY_TALK / ABS_LIBRARY_ARCHIVES to that exact name.")
    for bay in ("talk", "archives"):
        if bay not in claimed:
            label = "Talk Radio & Comedy Club" if bay == "talk" else "The Archives"
            lines.append(f"WARN  libraries  no library matched {label}. The wall for that Bay cannot be checked until the name matches.")
    catalog = [lib["id"] for lib in libraries if isinstance(lib.get("id"), str)]
    catalog_pos = {i: n for n, i in enumerate(catalog)}
    walled_ids = {bay: claimed[bay]["id"] for bay in ("talk", "archives") if bay in claimed}
    writes: list[dict] = []
    seen = False
    for user in users:
        if not isinstance(user, dict):
            continue
        name = str(user.get("username") or user.get("userName") or "").strip()
        if not name:
            continue
        seen = True
        groups = groups_by_user.get(name.casefold(), set())
        allowed = {bay for bay, wall in walls.items() if _may_enter(name, groups, wall)}
        access_all = _user_access_all(user)
        current = _user_library_ids(user)
        base = list(catalog) if access_all else list(current)
        drop = {walled_ids[bay] for bay in walled_ids if bay not in allowed}
        desired = []
        for lid in base:
            if lid not in drop and lid not in desired:
                desired.append(lid)
        desired.sort(key=lambda i: (catalog_pos.get(i, 10**9), i))
        problems = []
        if access_all:
            problems.append("accessAllLibraries is on, so the phone app can open every library, including Talk and Archives")
        effective = set(catalog) if access_all else set(current)
        for bay, lid in walled_ids.items():
            if lid in effective and bay not in allowed:
                wall_group, also = walls[bay]
                who = ", ".join(sorted(also))
                lib_name = (claimed[bay].get("name") or bay)
                problems.append(f"has {lib_name} without the {wall_group} wall ({who}, or group {wall_group})")
        changed = access_all or set(desired) != set(current)
        write = None
        if changed and not user.get("id"):
            problems.append("no user id, so this check cannot update them")
        elif changed and not desired and current:
            problems.append("Audiobookshelf ignores an empty library list, so untick their libraries in Settings -> Users")
        elif changed and user.get("id"):
            body: dict = {"permissions": {"accessAllLibraries": False}}
            if desired:
                body["librariesAccessible"] = desired
            write = {"id": user["id"], "username": name, "body": body}
        if problems:
            lines.append("WARN  " + name + "  " + "; ".join(problems))
        elif [bay for bay in ("talk", "archives") if bay not in claimed]:
            lines.append(f"OK    {name}  accessAllLibraries off; a Bay library was not found, so that wall was not checked")
        else:
            lines.append(f"OK    {name}  accessAllLibraries off; Talk and Archives follow the walls")
        if write:
            writes.append(write)
    if not seen:
        lines.append("WARN  setup  Audiobookshelf returned no users")
    return lines, writes


class _AbsClient:
    """Admin calls only. The bearer token stays on the request and out of every error string."""

    def __init__(self, base: str, token: str, opener=None):
        self.base = base.rstrip("/")
        self._token = token
        self.opener = opener or urllib.request.build_opener()

    def call(self, method: str, path: str, body: dict | None = None):
        data = None
        headers = {"Authorization": f"Bearer {self._token}", "Accept": "application/json"}
        if body is not None:
            data = json.dumps(body).encode()
            headers["Content-Type"] = "application/json"
        req = urllib.request.Request(self.base + path, data=data, method=method, headers=headers)
        try:
            with self.opener.open(req, timeout=TIMEOUT) as r:
                raw = r.read()
        except urllib.error.HTTPError as e:
            e.read()
            raise RuntimeError(f"Audiobookshelf answered HTTP {e.code} for {method} {path}") from None
        except urllib.error.URLError as e:
            raise RuntimeError(f"can't reach Audiobookshelf at {self.base}: {e.reason}") from None
        return json.loads(raw) if raw.strip() else None


def _abs_list(payload, key: str) -> list:
    if isinstance(payload, dict):
        rows = payload.get(key)
        return rows if isinstance(rows, list) else []
    return payload if isinstance(payload, list) else []


def run_abs_library_check(mode: str, *, token: str, base: str, users_text: str, opener=None,
                          apply_flag: bool = False) -> tuple[int, list[str]]:
    """verify is read-only. apply writes only when apply_flag is true (the shell sets that after a y)."""
    if not token:
        return 2, ["WARN  setup  ABS_API_TOKEN is empty. The token belongs in a podman secret, not in git."]
    if mode not in ("verify", "apply"):
        return 2, ["WARN  setup  abs-libraries expects verify or apply"]
    groups = authelia_groups(users_text)
    client = _AbsClient(base, token, opener)
    try:
        libraries = _abs_list(client.call("GET", "/api/libraries"), "libraries")
        users = _abs_list(client.call("GET", "/api/users"), "users")
    except RuntimeError as e:
        return 2, [f"WARN  setup  {e}"]
    before, writes = plan_abs_libraries(users, libraries, groups)
    if mode != "apply":
        warns = [ln for ln in before if ln.startswith("WARN")]
        return (1 if warns else 0), before
    if not apply_flag:
        before.append("WARN  setup  refusing to write: ABS_APPLY is not 1")
        return 2, before
    wrote: list[str] = []
    for write in writes:
        try:
            client.call("PATCH", f"/api/users/{write['id']}", write["body"])
            wrote.append(f"WROTE {write['username']}  accessAllLibraries off, libraries set to the plan")
        except RuntimeError as e:
            wrote.append(f"WARN  {write['username']}  not changed: {e}")
    try:
        users = _abs_list(client.call("GET", "/api/users"), "users")
        libraries = _abs_list(client.call("GET", "/api/libraries"), "libraries")
    except RuntimeError as e:
        wrote.append(f"WARN  setup  wrote, then could not re-read: {e}")
        return 1, before + wrote
    after, _ = plan_abs_libraries(users, libraries, groups)
    # The exit code is the state after the writes. The earlier WARN lines stay in the output so the
    # owner can see what was wrong.
    warns = [ln for ln in wrote + after if ln.startswith("WARN")]
    return (1 if warns else 0), before + wrote + ["-- after --"] + after


def cmd_abs_libraries(mode: str) -> int:
    token = os.environ.get("ABS_API_TOKEN", "")
    base = os.environ.get("ABS_URL", "http://10.6.9.20:13378").strip() or "http://10.6.9.20:13378"
    try:
        text = USERS_FILE.read_text()
    except OSError:
        print(f"WARN  setup  cannot read Authelia users at {USERS_FILE}")
        return 2
    code, lines = run_abs_library_check(
        mode, token=token, base=base, users_text=text, apply_flag=os.environ.get("ABS_APPLY") == "1")
    for line in lines:
        print(line)
    return code


def cmd_check() -> int:
    """READ-ONLY: can each app's admin login work, and which station users does each app know?"""
    people = users_in_file()
    print(f"Station users (Authelia, {USERS_FILE}): {', '.join(people) or 'none found'}")
    apps = load_apps()
    if not apps:
        print("No apps enabled in", APPS_FILE)
    bad = 0
    for app in apps:
        try:
            known = app.users()
        except Exception as e:
            print(f"  FAIL  {app.title}: {e}")
            bad += 1
            continue
        missing = [p for p in people if p not in known]
        print(f"  OK    {app.title}: admin login works, {len(known)} accounts"
              + (f"; no account yet for: {', '.join(missing)}" if missing else "; every station user has one"))
    return 1 if bad else 0


def main() -> int:
    if len(sys.argv) > 1:
        cmd = sys.argv[1]
        if cmd == "check":
            return cmd_check()
        if cmd == "hash":
            print(authelia_hash(sys.stdin.readline().rstrip("\n")))
            return 0
        if cmd == "abs-libraries":
            mode = sys.argv[2] if len(sys.argv) > 2 else "verify"
            return cmd_abs_libraries(mode)
        if cmd == "apps" and len(sys.argv) == 3 and USER_RE.match(sys.argv[2]):
            pw = sys.stdin.readline().rstrip("\n")
            if len(pw) < min_len():
                print("password too short", file=sys.stderr)
                return 2
            res = sync_apps(sys.argv[2], pw)
            for t, s, d in res:
                print(f"  {s.upper():4}  {t}: {d}")
            return 1 if any(s == "fail" for _, s, _ in res) else 0
        print(__doc__)
        return 2
    global SERVING
    SERVING = True
    host, port = ADDR.rsplit(":", 1)
    pod = "ready" if PODPANELS_KEY and podpanels_base() else "off"
    log(f"eo-account listening on {ADDR}; users file {USERS_FILE}; {len(load_apps())} apps enabled; podpanels {pod}")
    threading.Thread(target=watch_bays, daemon=True).start()
    threading.Thread(target=record_stats, daemon=True).start()
    ThreadingHTTPServer((host, int(port)), Handler).serve_forever()
    return 0


if __name__ == "__main__":
    sys.exit(main())
