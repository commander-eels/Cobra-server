"""Audiobookshelf library walls: names, permissions, and the read-only check.

No network. The token in here is a test string and must not show up in the printed lines.
"""

from __future__ import annotations

import io
import json
import os
import subprocess
import sys
import unittest
import urllib.error
import urllib.parse
from email.message import EmailMessage
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import eo_account  # noqa: E402

ROOT = Path(__file__).resolve().parents[3]
TOKEN = "test-token-not-a-secret"


class Resp:
    def __init__(self, body: bytes):
        self._body = body

    def read(self) -> bytes:
        return self._body

    def __enter__(self):
        return self

    def __exit__(self, *args) -> bool:
        return False


class Api:
    def __init__(self, users: list, libraries: list, fail: int | None = None):
        self.users = users
        self.libraries = libraries
        self.fail = fail
        self.calls: list[tuple[str, str, dict | None]] = []

    def open(self, req, timeout=None):
        method = req.get_method()
        path = urllib.parse.urlparse(req.full_url).path
        body = json.loads(req.data.decode()) if req.data else None
        self.calls.append((method, path, body))
        if self.fail:
            hdrs = EmailMessage()
            raise urllib.error.HTTPError(req.full_url, self.fail, "no", hdrs, io.BytesIO(b"no"))
        if method == "GET" and path == "/api/libraries":
            payload = {"libraries": self.libraries}
        elif method == "GET" and path == "/api/users":
            payload = {"users": self.users}
        elif method == "PATCH" and path.startswith("/api/users/"):
            uid = path.rsplit("/", 1)[-1]
            for user in self.users:
                if user["id"] == uid:
                    user["permissions"] = {**(user.get("permissions") or {}), **(body or {}).get("permissions", {})}
                    if "librariesAccessible" in (body or {}):
                        user["librariesAccessible"] = body["librariesAccessible"]
            payload = {"success": True, "user": {"id": uid}}
        else:
            raise AssertionError(method + " " + path)
        return Resp(json.dumps(payload).encode())


LIBS = [
    {"id": "a", "name": "Audiobooks"},
    {"id": "t", "name": "Talk Radio & Comedy Club"},
    {"id": "r", "name": "The Archives"},
    {"id": "s", "name": "Sessions"},
]
USERS_YML = """users:
  eels:
    displayname: Eels
    password: '$argon2id$v=19$m=65536$not-a-real-hash'
    groups:
      - archives
  rachel:
    displayname: Rachel
    password: '$argon2id$also-not-real'
    groups: []
  sam:
    displayname: Sam
    password: '$pbkdf2-sha512$nope'
    groups:
      - talk
      - music
  pat:
    displayname: Pat
    password: '$argon2id$nope'
    groups: []
"""


def users():
    return [
        {"id": "1", "username": "eels", "type": "root",
         "permissions": {"accessAllLibraries": False, "download": True},
         "librariesAccessible": ["a", "t", "r", "s"]},
        {"id": "2", "username": "rachel",
         "permissions": {"accessAllLibraries": True, "download": True},
         "librariesAccessible": []},
        {"id": "3", "username": "sam",
         "permissions": {"accessAllLibraries": False},
         "librariesAccessible": ["a", "t", "r"]},
        {"id": "4", "username": "pat",
         "permissions": {"accessAllLibraries": False},
         "librariesAccessible": ["a", "s"]},
    ]


class LibraryWallTests(unittest.TestCase):
    def setUp(self):
        self._env = {k: os.environ.get(k) for k in (
            "ABS_LIBRARY_TALK", "ABS_LIBRARY_ARCHIVES", "ABS_LIBRARY_TALK_RE", "ABS_LIBRARY_ARCHIVES_RE")}
        for k in self._env:
            os.environ.pop(k, None)

    def tearDown(self):
        for k, v in self._env.items():
            if v is None:
                os.environ.pop(k, None)
            else:
                os.environ[k] = v

    def test_comedy_archives_matches_neither_bay(self):
        libs = LIBS + [{"id": "c", "name": "Comedy Archives"}]
        claimed = eo_account.match_abs_libraries(libs)
        self.assertEqual(claimed["talk"]["id"], "t")
        self.assertEqual(claimed["archives"]["id"], "r")
        self.assertNotIn("c", {lib["id"] for lib in claimed.values()})
        lines, _ = eo_account.plan_abs_libraries(users(), libs, eo_account.authelia_groups(USERS_YML))
        self.assertTrue(any("Comedy Archives" in ln and ln.startswith("WARN") for ln in lines))
        self.assertFalse(any("argon" in ln or "pbkdf" in ln for ln in lines))

    def test_exact_name_beats_a_wide_pattern_and_a_library_is_used_once(self):
        specs = [
            ("talk", {"talk radio"}, re_all()),
            ("archives", {"the archives"}, re_all()),
        ]
        libs = [{"id": "r", "name": "The Archives"}, {"id": "t", "name": "Talk Radio"}]
        claimed = eo_account.match_abs_libraries(libs, specs)
        self.assertEqual(claimed["archives"]["id"], "r")
        self.assertEqual(claimed["talk"]["id"], "t")
        self.assertEqual(len({claimed["talk"]["id"], claimed["archives"]["id"]}), 2)

    def test_walls_follow_the_bay_list(self):
        lines, writes = eo_account.plan_abs_libraries(users(), LIBS, eo_account.authelia_groups(USERS_YML))
        by_user = {ln.split()[1]: ln for ln in lines if ln.startswith(("WARN  ", "OK    "))}
        self.assertTrue(by_user["eels"].startswith("OK"))
        self.assertIn("accessAllLibraries is on", by_user["rachel"])
        self.assertIn("The Archives", by_user["rachel"])
        self.assertIn("The Archives", by_user["sam"])
        self.assertNotIn("Talk Radio", by_user["sam"])
        self.assertTrue(by_user["pat"].startswith("OK"))
        wrote = {w["username"]: w["body"] for w in writes}
        self.assertNotIn("eels", wrote)
        self.assertNotIn("pat", wrote)
        self.assertNotIn("password", json.dumps(wrote))
        self.assertFalse(wrote["rachel"]["permissions"]["accessAllLibraries"])
        self.assertNotIn("r", wrote["rachel"]["librariesAccessible"])
        self.assertIn("t", wrote["rachel"]["librariesAccessible"])
        self.assertEqual(wrote["sam"]["librariesAccessible"], ["a", "t"])

    def test_a_person_inside_the_wall_is_not_granted_a_library_they_lack(self):
        people = [{"id": "1", "username": "rachel", "permissions": {"accessAllLibraries": False},
                   "librariesAccessible": ["a"]}]
        lines, writes = eo_account.plan_abs_libraries(
            people, LIBS, {"rachel": set()})
        self.assertTrue(lines[-1].startswith("OK"))
        self.assertEqual(writes, [])

    def test_eels_may_enter_both_without_a_group(self):
        walls = eo_account.library_walls()
        self.assertTrue(eo_account._may_enter("Eels", set(), walls["talk"]))
        self.assertTrue(eo_account._may_enter("eels", set(), walls["archives"]))
        self.assertTrue(eo_account._may_enter("rachel", set(), walls["talk"]))
        self.assertFalse(eo_account._may_enter("rachel", set(), walls["archives"]))
        self.assertTrue(eo_account._may_enter("sam", {"talk"}, walls["talk"]))
        self.assertFalse(eo_account._may_enter("sam", {"talk"}, walls["archives"]))

    def test_verify_is_read_only_and_hides_the_token(self):
        api = Api(users(), LIBS)
        code, lines = eo_account.run_abs_library_check(
            "verify", token=TOKEN, base="http://abs.test", users_text=USERS_YML, opener=api, apply_flag=True)
        self.assertEqual(code, 1)
        self.assertEqual({c[0] for c in api.calls}, {"GET"})
        self.assertNotIn(TOKEN, "\n".join(lines))
        code, lines = eo_account.run_abs_library_check(
            "apply", token=TOKEN, base="http://abs.test", users_text=USERS_YML, opener=api, apply_flag=False)
        self.assertEqual(code, 2)
        self.assertTrue(any("refusing to write" in ln for ln in lines))
        self.assertEqual({c[0] for c in api.calls}, {"GET"})

    def test_apply_writes_only_the_planned_libraries(self):
        api = Api(users(), LIBS)
        code, lines = eo_account.run_abs_library_check(
            "apply", token=TOKEN, base="http://abs.test", users_text=USERS_YML, opener=api, apply_flag=True)
        patches = [c for c in api.calls if c[0] == "PATCH"]
        self.assertEqual(sorted(c[1] for c in patches), ["/api/users/2", "/api/users/3"])
        for _, _, body in patches:
            self.assertEqual(set(body), {"permissions", "librariesAccessible"})
            self.assertFalse(body["permissions"]["accessAllLibraries"])
            self.assertNotIn("password", body)
        self.assertNotIn(TOKEN, "\n".join(lines))
        self.assertEqual(code, 0)
        self.assertTrue(any(ln.startswith("OK    rachel") for ln in lines))

    def test_a_refused_token_does_not_echo_it(self):
        api = Api(users(), LIBS, fail=401)
        code, lines = eo_account.run_abs_library_check(
            "verify", token=TOKEN, base="http://abs.test", users_text=USERS_YML, opener=api)
        self.assertEqual(code, 2)
        text = "\n".join(lines)
        self.assertIn("HTTP 401", text)
        self.assertNotIn(TOKEN, text)

    def test_bad_pattern_falls_back_to_the_default(self):
        os.environ["ABS_LIBRARY_TALK_RE"] = "("
        _, notes = eo_account.abs_library_specs()
        self.assertTrue(any("not a valid pattern" in n for n in notes))
        claimed = eo_account.match_abs_libraries(LIBS + [{"id": "c", "name": "Comedy Archives"}])
        self.assertEqual(claimed["talk"]["id"], "t")
        self.assertNotIn("c", {lib["id"] for lib in claimed.values()})

    def test_talk_and_archives_have_their_own_servers(self):
        # 2026-11-21, the Commander's call: Talk and Archives are separate Audiobookshelf servers, and The Archives
        # (personal recordings) is reachable only at home or over WireGuard, never through the gate.
        talk = next(b for b in eo_account.BAYS_DEFAULT if b["bay"] == "talk")
        self.assertEqual(talk["address"], "https://talk.songofeo.com")
        self.assertIn(":13379", talk["probe"])
        arch = next(b for b in eo_account.BAYS_DEFAULT if b["bay"] == "archives")
        self.assertEqual(arch["address"], "http://10.6.9.20:13380")
        self.assertNotIn("songofeo.com", arch["address"])
        self.assertEqual(eo_account.APP_BAY[eo_account.AudiobookshelfTalk], "talk")
        self.assertEqual(eo_account.APP_BAY[eo_account.AudiobookshelfArchives], "archives")
        self.assertIn("audiobookshelf-talk", eo_account.KINDS)
        self.assertIn("audiobookshelf-archives", eo_account.KINDS)

    def test_groups_parser_skips_password_lines(self):
        groups = eo_account.authelia_groups(USERS_YML)
        self.assertEqual(groups["eels"], {"archives"})
        self.assertEqual(groups["rachel"], set())
        self.assertEqual(groups["sam"], {"talk", "music"})
        self.assertNotIn("argon", json.dumps({k: sorted(v) for k, v in groups.items()}))

    def test_window_js_patterns_and_bookmark_pages(self):
        js = (ROOT / "web/bays/window.js").read_text()
        self.assertNotIn("/talk|comedy/i", js)
        self.assertNotIn("/archive/i", js)
        self.assertNotIn("inLib", js)
        start = js.index("  const ABS_LIB")
        end = js.index("  const absBay")
        script = "const window = {};\n" + js[start:end] + """
const libs = [
  {id:"a", name:"Audiobooks"},
  {id:"c", name:"Comedy Archives"},
  {id:"t", name:"Talk Radio & Comedy Club"},
  {id:"r", name:"The Archives"},
];
const claimed = matchAbsLibraries(libs);
if (!claimed.talk || claimed.talk.id !== "t" || claimed.archives.id !== "r") {
  throw new Error("claim " + JSON.stringify(claimed));
}
if (Object.values(claimed).some((l) => l.id === "c")) throw new Error("Comedy Archives was claimed");
const pages = {0: {total: 3, results: [{id:"p1"}, {id:"p2"}]}, 1: {total: 3, results: [{id:"done"}]}};
const C = { items: (id, page) => Promise.resolve(pages[page]) };
absLibraryItemIds(C, {id:"t"}, pages[0]).then((ids) => {
  const marks = [{libraryItemId:"p1"}, {libraryItemId:"done"}, {libraryItemId:"other"}];
  const n = marks.filter((b) => ids.has(b.libraryItemId)).length;
  if (n !== 2 || !ids.has("done")) throw new Error("bookmarks " + n);
});
"""
        subprocess.run(["node", "-e", script], check=True)

    def test_scripts_keep_the_token_off_the_command_line(self):
        shell = (ROOT / "home/cobra-setup/abs-libraries.sh").read_text()
        verify = (ROOT / "home/cobra-setup/90-verify-gate.sh").read_text()
        step15 = (ROOT / "home/cobra-setup/15-gate-accounts.sh").read_text()
        self.assertIn('--secret "$secret,type=env,target=ABS_API_TOKEN"', shell)
        self.assertNotIn("echo \"$ABS_API_TOKEN\"", shell)
        self.assertNotIn("Bearer ", shell)
        self.assertIn("paste-the-token", shell)
        self.assertIn("abs_libraries_run verify", verify)
        self.assertNotIn("abs_libraries_run apply", verify)
        self.assertIn("--apply-abs-libraries", step15)
        self.assertIn("ABS_APPLY=1 abs_libraries_run apply", step15)
        self.assertIn("refusing to write", shell)
        api = (ROOT / "web/app/eo-api.js").read_text()
        self.assertIn("&& (await CLIENTS[f].connect())", api)
        self.assertNotIn("&&(await", api)


def re_all():
    import re
    return re.compile(r".*")


if __name__ == "__main__":
    unittest.main()
