"""Proxy checks for the admin PodPanels door.

The hex strings in here are repeated letters so a test can see a leak. They are not keys.
"""

from __future__ import annotations

import io
import json
import sys
import tempfile
import time
import unittest
import urllib.error
import urllib.parse
import urllib.request
from email.message import EmailMessage
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import eo_account  # noqa: E402

ROOT = Path(__file__).resolve().parents[3]
INSTALLED = "ab" * 32
ROTATED = "cd" * 32
HEALTH_KEY = "ef" * 32


class FakeResp:
    def __init__(self, status: int, body: bytes, headers: dict):
        self.status = status
        self.headers = headers
        self._body = body

    def read(self, n: int = -1) -> bytes:
        return self._body if n < 0 else self._body[:n]

    def getcode(self) -> int:
        return self.status

    def __enter__(self):
        return self

    def __exit__(self, *args) -> bool:
        return False


class FakeOpener:
    def __init__(self, status: int = 200, body: bytes = b"ok", headers: dict | None = None, error: BaseException | None = None):
        self.status = status
        self.body = body
        self.headers = headers or {"Content-Type": "text/plain"}
        self.error = error
        self.calls: list[tuple] = []

    def open(self, req, timeout=None):
        self.calls.append((req, timeout))
        if self.error:
            raise self.error
        if self.status >= 400 or self.status in (301, 302, 303, 307, 308):
            hdrs = EmailMessage()
            for k, v in self.headers.items():
                hdrs[k] = v
            raise urllib.error.HTTPError(req.full_url, self.status, "status", hdrs, io.BytesIO(self.body))
        return FakeResp(self.status, self.body, self.headers)


class AuthFake:
    """Stand-in for Authelia's auth-request. Default is HTTP 200 for eels."""

    def __init__(self, status: int = 200, user: str = "eels", error: BaseException | None = None):
        self.status = status
        self.user = user
        self.error = error
        self.calls: list[tuple] = []

    def open(self, req, timeout=None):
        self.calls.append((req, timeout))
        if self.error:
            raise self.error
        hdrs = {"Remote-User": self.user} if self.user else {}
        if self.status != 200:
            em = EmailMessage()
            for k, v in hdrs.items():
                em[k] = v
            raise urllib.error.HTTPError(req.full_url, self.status, "status", em, io.BytesIO(b""))
        return FakeResp(self.status, b"", hdrs)


class Dummy(eo_account.Handler):
    def __init__(self, path: str, headers: dict, body: bytes = b""):
        self.path = path
        self.headers = headers
        self.rfile = io.BytesIO(body)
        self.wfile = io.BytesIO()
        self.close_connection = False
        self.code = None
        self.sent: list[tuple[str, str]] = []

    def send_response(self, code, message=None):
        self.code = code

    def send_header(self, key, value):
        self.sent.append((key.lower(), value))

    def end_headers(self):
        pass


class PodPanelsTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        root = Path(self.tmp.name)
        self.saved = {
            "PODPANELS_KEY": eo_account.PODPANELS_KEY,
            "PODPANELS_URL": eo_account.PODPANELS_URL,
            "ADMINS": set(eo_account.ADMINS),
            "POD_POST_PER": eo_account.POD_POST_PER,
            "POD_POST_ALL": eo_account.POD_POST_ALL,
            "POD_ROTATE_PER": eo_account.POD_ROTATE_PER,
            "POD_ROTATE_ALL": eo_account.POD_ROTATE_ALL,
            "APPS_FILE": eo_account.APPS_FILE,
            "REQUESTS_FILE": eo_account.REQUESTS_FILE,
            "RESYNC_FILE": eo_account.RESYNC_FILE,
            "_podpanels_opener": eo_account._podpanels_opener,
            "_authelia_opener": eo_account._authelia_opener,
            "AUTHELIA_AUTHZ_URL": eo_account.AUTHELIA_AUTHZ_URL,
            "log": eo_account.log,
        }
        eo_account.PODPANELS_URL = "http://127.0.0.1:8100"
        eo_account.PODPANELS_KEY = INSTALLED
        eo_account.APPS_FILE = root / "apps.json"
        eo_account.REQUESTS_FILE = root / "requests.json"
        eo_account.RESYNC_FILE = root / "resync.json"
        eo_account.podpanels_rates_clear()
        self.logs: list[str] = []
        eo_account.log = lambda *parts: self.logs.append(" ".join(str(p) for p in parts))
        self.opener = FakeOpener(error=urllib.error.URLError("down"))
        eo_account._podpanels_opener = lambda: self.opener
        self.auth = AuthFake()
        eo_account._authelia_opener = lambda: self.auth

    def tearDown(self):
        for name, value in self.saved.items():
            setattr(eo_account, name, value)
        eo_account.podpanels_rates_clear()
        self.tmp.cleanup()

    def _headers(self, user: str = "eels", length: int = 0, origin: str | None = None, **extra) -> dict:
        headers = {
            "Remote-User": user,
            "Origin": eo_account.ORIGIN if origin is None else origin,
            "Content-Length": str(length),
            "Content-Type": "application/json",
            "Accept": "text/html",
            "Cookie": "session=nope",
            "Authorization": "Bearer nope",
            "Remote-Groups": "admins",
            "X-PodPanels-Key": "client-supplied",
            "X-PodPanels-User": "root",
            "X-Forwarded-For": "203.0.113.5",
        }
        headers.update(extra)
        return headers

    def test_paths_and_loopback_only(self):
        self.assertTrue(eo_account.podpanels_upstream("/admin/pods/").endswith(":8100/"))
        self.assertTrue(eo_account.podpanels_upstream("/admin/pods/app.js?v=1").endswith("/app.js?v=1"))
        for path in (
            "/admin/pods/../x",
            "/admin/pods/%2e%2e/x",
            "/admin/pods/%2E%2E/x",
            "/admin/pods/foo%2ebar",
            "/admin/pods/a\\b",
            "/admin/pods//evil.example",
            "/admin/pods/foo/../../etc",
            "/admin/pods/" + INSTALLED,
        ):
            self.assertIsNone(eo_account.podpanels_upstream(path), path)
        eo_account.PODPANELS_URL = "http://example.com:8100"
        self.assertIsNone(eo_account.podpanels_base())
        eo_account.PODPANELS_URL = "file:///etc/passwd"
        self.assertIsNone(eo_account.podpanels_base())
        self.assertIsNone(eo_account.podpanels_upstream("/admin/pods/"))
        eo_account.PODPANELS_URL = "http://user:secret@127.0.0.1:8100"
        self.assertIsNone(eo_account.podpanels_base())
        eo_account.PODPANELS_URL = "http://[::1]:8100"
        self.assertEqual(eo_account.podpanels_upstream("/admin/pods/a"), "http://[::1]:8100/a")

    def test_redirects_are_not_followed_and_proxy_env_is_ignored(self):
        req = urllib.request.Request("http://127.0.0.1:8100/")
        with self.assertRaises(urllib.error.HTTPError):
            eo_account._NoRedirect().redirect_request(req, None, 302, "Found", None, "http://169.254.169.254/")
        opener = self.saved["_podpanels_opener"]()
        # An empty ProxyHandler installs no proxy methods, so http_proxy is not used and the key stays on loopback.
        self.assertFalse(any(isinstance(h, urllib.request.ProxyHandler) for h in opener.handlers))
        self.assertTrue(any(isinstance(h, eo_account._NoRedirect) for h in opener.handlers))
        self.assertTrue(any(isinstance(h, urllib.request.HTTPHandler) for h in opener.handlers))

    def test_headers_carry_only_the_server_key(self):
        headers = eo_account.podpanels_headers("POST", "eels", "text/html\r\nCookie: a=b", "application/json\nX-Extra: 1")
        self.assertEqual(headers["X-PodPanels-Key"], INSTALLED)
        self.assertEqual(headers["X-PodPanels-User"], "eels")
        self.assertNotIn("\n", headers["Accept"])
        self.assertNotIn("\n", headers["Content-Type"])
        self.assertNotIn("Cookie", headers)
        self.assertNotIn("Authorization", headers)

    def test_health_sends_no_key_and_drops_a_key_field(self):
        seen = []

        class Rec:
            def open(self, req, timeout=None):
                seen.append((req, timeout))
                raise urllib.error.URLError("down")

        eo_account._podpanels_opener = lambda: Rec()
        status, made = eo_account.podpanels_probe()
        self.assertEqual((status, made), ("Offline", ""))
        self.assertEqual(seen[0][1], 1)
        self.assertTrue(seen[0][0].full_url.endswith("/health"))
        names = {k.lower() for k, _ in seen[0][0].header_items()}
        self.assertNotIn("x-podpanels-key", names)

        body = json.dumps({"ok": True, "key": HEALTH_KEY, "key_created": "2026-11-18T20:00:00Z"}).encode()
        eo_account._podpanels_opener = lambda: FakeOpener(200, body, {"Content-Type": "application/json"})
        status, made = eo_account.podpanels_probe()
        self.assertEqual(status, "Online")
        self.assertEqual(made, "2026-11-18T20:00:00Z")
        self.assertNotIn(HEALTH_KEY, made)
        eo_account._podpanels_opener = lambda: FakeOpener(
            200, json.dumps({"key_created": "not a time"}).encode(), {"Content-Type": "application/json"})
        self.assertEqual(eo_account.podpanels_probe()[1], "")

    def test_fold_hides_the_installed_key(self):
        page = eo_account.podpanels_block("ada", 1)
        self.assertEqual(page, "")
        eo_account.PODPANELS_KEY = ""
        empty = eo_account.podpanels_block("eels", 1)
        self.assertIn("Key not installed on the gate (step 16)", empty)
        self.assertNotIn("podlink", empty)
        self.assertNotIn("Make new key", empty)
        eo_account.PODPANELS_KEY = INSTALLED
        body = json.dumps({"key": HEALTH_KEY, "key_created": "2026-11-18T20:00:00Z"}).encode()
        eo_account._podpanels_opener = lambda: FakeOpener(200, body, {"Content-Type": "application/json"})
        fold = eo_account.podpanels_block("eels", 1)
        self.assertIn("Open PodPanels", fold)
        self.assertIn('class="podlink"', fold)
        self.assertIn('target="_blank"', fold)
        self.assertIn('rel="noopener noreferrer"', fold)
        self.assertIn("Make new key", fold)
        self.assertIn("2026-11-18T20:00:00Z", fold)
        self.assertIn("Gate pods - Online - opens in a new tab", fold)
        self.assertNotIn(INSTALLED, fold)
        self.assertNotIn(HEALTH_KEY, fold)
        self.assertNotIn("<script", fold)
        self.assertNotIn("iframe", fold.lower())
        self.assertNotIn("<!--", fold)
        shown = eo_account.podpanels_block("eels", 1, new_key=ROTATED)
        self.assertEqual(shown.count(ROTATED), 1)
        self.assertNotIn(INSTALLED, shown)
        hidden = eo_account.podpanels_block("eels", 1, new_key="<script>alert(1)</script>")
        self.assertNotIn("<script>", hidden)
        self.assertIn("did not show", hidden)

    def test_page_css_and_no_comments(self):
        page = eo_account.form_page("eels")
        self.assertIn("a.podlink{display:inline-block", page)
        self.assertIn("#e0b84c", page)
        self.assertIn("a.podlink:hover,a.podlink:focus-visible{background:#e0b84c", page)
        self.assertNotIn("a.podlink{{", page)
        self.assertNotIn("<!--", page)
        self.assertNotIn(INSTALLED, page)
        self.assertIn("Open PodPanels", page)

    def test_get_redirect_and_proxy(self):
        redir = Dummy("/admin/pods?x=1", self._headers())
        redir.do_GET()
        self.assertEqual(redir.code, 302)
        self.assertIn(("location", "/admin/pods/?x=1"), redir.sent)
        leak = Dummy("/admin/pods?" + INSTALLED, self._headers())
        leak.do_GET()
        self.assertNotIn(INSTALLED, dict(leak.sent).get("location", ""))

        self.opener.error = None
        self.opener.status = 200
        self.opener.body = b"\xff\xfepanel"
        self.opener.headers = {"Content-Type": "text/html; charset=utf-8"}
        got = Dummy("/admin/pods/app.js", self._headers())
        got.do_GET()
        self.assertEqual(got.code, 200)
        self.assertEqual(got.wfile.getvalue(), b"\xff\xfepanel")
        sent = dict(got.sent)
        self.assertEqual(sent["content-security-policy"], eo_account.PROXY_CSP)
        self.assertEqual(sent["x-frame-options"], "DENY")
        self.assertEqual(sent["cache-control"], "no-store")
        self.assertEqual(self.opener.calls[0][1], 10)
        self.assertTrue(self.opener.calls[0][0].full_url.endswith("/app.js"))
        self.assertNotIn(INSTALLED, self.opener.calls[0][0].full_url)

        guest = Dummy("/admin/pods/app.js", {})
        guest.do_GET()
        self.assertEqual(guest.code, 403)
        self.assertIn(b"Sign in first", guest.wfile.getvalue())

        other = Dummy("/admin/pods/app.js", self._headers(user="ada"))
        other.do_GET()
        self.assertEqual(other.code, 403)
        self.assertIn(b"Only an admin", other.wfile.getvalue())

        rotate = Dummy("/admin/pods/rotate", self._headers())
        rotate.do_GET()
        self.assertEqual(rotate.code, 405)

    def test_post_forwards_allowlisted_headers_only(self):
        self.opener.error = None
        self.opener.body = b"<p>ok</p>"
        self.opener.headers = {"Content-Type": "text/html"}
        handler = Dummy("/admin/pods/status", self._headers(length=2), b"{}")
        handler.do_POST()
        self.assertEqual(handler.code, 200)
        self.assertEqual(handler.wfile.getvalue(), b"<p>ok</p>")
        sent = dict(handler.sent)
        self.assertEqual(sent["content-security-policy"], eo_account.PROXY_CSP)
        req = self.opener.calls[0][0]
        names = {k.lower(): v for k, v in req.header_items()}
        self.assertEqual(names["x-podpanels-key"], INSTALLED)
        self.assertEqual(names["x-podpanels-user"], "eels")
        self.assertNotIn("cookie", names)
        self.assertNotIn("authorization", names)
        self.assertNotIn("remote-user", names)
        self.assertNotIn("remote-groups", names)
        self.assertNotIn("x-forwarded-for", names)
        self.assertNotEqual(names["x-podpanels-key"], "client-supplied")
        self.assertNotIn("client-supplied", names.values())
        self.assertTrue(req.full_url.endswith("/status"))
        self.assertEqual(req.get_method(), "POST")
        self.assertEqual(req.data, b"{}")
        self.assertTrue(any(line == "podpanels eels POST /status" for line in self.logs))
        self.assertNotIn(INSTALLED, "\n".join(self.logs))

    def test_post_refuses_bad_origin_size_path_and_outage(self):
        bad = Dummy("/admin/pods/status", self._headers(length=2, origin="https://evil.example"), b"{}")
        bad.do_POST()
        self.assertEqual(bad.code, 403)
        self.assertEqual(self.opener.calls, [])

        huge = Dummy("/admin/pods/status", self._headers(length=65537), b"")
        huge.do_POST()
        self.assertEqual(huge.code, 413)
        self.assertEqual(huge.rfile.tell(), 0)

        path = Dummy("/admin/pods/%2e%2e/secret", self._headers(length=2), b"{}")
        path.do_POST()
        self.assertEqual(path.code, 400)
        self.assertTrue(any(line == "podpanels eels POST refused" for line in self.logs))
        self.assertNotIn("%2e", "\n".join(self.logs))

        self.opener.error = urllib.error.URLError("down")
        down = Dummy("/admin/pods/status", self._headers(length=2), b"{}")
        down.do_POST()
        self.assertEqual(down.code, 502)
        self.assertEqual(down.wfile.getvalue(), b"PodPanels service offline\n")
        self.assertNotIn(INSTALLED.encode(), down.wfile.getvalue())

        self.opener.error = None
        self.opener.status = 302
        self.opener.body = b"go"
        self.opener.headers = {"Content-Type": "text/plain", "Location": "http://169.254.169.254/latest"}
        before = len(self.opener.calls)
        bounced = Dummy("/admin/pods/status", self._headers(length=2), b"{}")
        bounced.do_POST()
        self.assertEqual(bounced.code, 302)
        self.assertNotIn("location", dict(bounced.sent))
        self.assertEqual(len(self.opener.calls), before + 1)

        eo_account.PODPANELS_KEY = ""
        missing = Dummy("/admin/pods/status", self._headers(length=2), b"{}")
        missing.do_POST()
        self.assertEqual(missing.code, 503)
        self.assertIn(b"key not installed", missing.wfile.getvalue())

    def test_rotate_shows_a_generated_key_once_and_does_not_keep_it(self):
        ts = int(time.time())
        token = eo_account.form_token("eels", ts)
        body = urllib.parse.urlencode({"ts": str(ts), "token": token}).encode()
        payload = json.dumps({"key": ROTATED, "note": HEALTH_KEY}).encode()
        self.opener.error = None
        self.opener.status = 200
        self.opener.body = payload
        self.opener.headers = {"Content-Type": "application/json"}
        handler = Dummy(
            "/admin/pods/rotate",
            self._headers(length=len(body), **{"Content-Type": "application/x-www-form-urlencoded"}),
            body,
        )
        handler.do_POST()
        page = handler.wfile.getvalue().decode()
        self.assertEqual(handler.code, 200)
        self.assertEqual(page.count(ROTATED), 1)
        self.assertNotIn(INSTALLED, page)
        self.assertNotIn(HEALTH_KEY, page)
        self.assertNotIn("<!--", page)
        self.assertEqual(eo_account.PODPANELS_KEY, INSTALLED)
        req = self.opener.calls[0][0]
        self.assertTrue(req.full_url.endswith("/rotate"))
        self.assertEqual(req.data, b"{}")
        self.assertTrue(any(line == "podpanels eels POST /rotate" for line in self.logs))
        logged = "\n".join(self.logs)
        self.assertNotIn(ROTATED, logged)
        self.assertNotIn(INSTALLED, logged)

        self.opener.calls.clear()
        self.logs.clear()
        ugly = Dummy(
            "/admin/pods/rotate",
            self._headers(length=len(body), **{"Content-Type": "application/x-www-form-urlencoded"}),
            body,
        )
        self.opener.body = json.dumps({"key": "<script>alert(1)</script>"}).encode()
        ugly.do_POST()
        text = ugly.wfile.getvalue().decode()
        self.assertNotIn("<script>", text)
        self.assertIn("did not show", text)

        stale = urllib.parse.urlencode({"ts": "1", "token": "nope"}).encode()
        self.opener.calls.clear()
        old = Dummy(
            "/admin/pods/rotate",
            self._headers(length=len(stale), **{"Content-Type": "application/x-www-form-urlencoded"}),
            stale,
        )
        old.do_POST()
        self.assertIn(b"too long", old.wfile.getvalue().lower())
        self.assertEqual(len(self.opener.calls), 1)
        health, health_timeout = self.opener.calls[0]
        self.assertEqual(health_timeout, 1)
        self.assertTrue(health.full_url.endswith("/health"))

    def test_rate_limits(self):
        eo_account.POD_POST_PER = 1
        self.opener.error = None
        first = Dummy("/admin/pods/status", self._headers(length=2), b"{}")
        first.do_POST()
        self.assertEqual(first.code, 200)
        second = Dummy("/admin/pods/status", self._headers(length=2), b"{}")
        second.do_POST()
        self.assertEqual(second.code, 429)
        self.assertTrue(any("rate limit" in line for line in self.logs))
        self.assertNotIn(INSTALLED, "\n".join(self.logs))

        eo_account.podpanels_rates_clear()
        eo_account.POD_POST_PER = 30
        eo_account.POD_POST_ALL = 1
        eo_account.ADMINS.add("boss")
        one = Dummy("/admin/pods/status", self._headers(length=2), b"{}")
        one.do_POST()
        self.assertEqual(one.code, 200)
        self.auth.user = "boss"
        other = Dummy("/admin/pods/status", self._headers(user="boss", length=2), b"{}")
        other.do_POST()
        self.assertEqual(other.code, 429)
        self.auth.user = "eels"

        eo_account.podpanels_rates_clear()
        eo_account.POD_POST_ALL = 60
        eo_account.POD_ROTATE_PER = 1
        ts = int(time.time())
        body = urllib.parse.urlencode({"ts": str(ts), "token": eo_account.form_token("eels", ts)}).encode()
        self.opener.body = json.dumps({"key": ROTATED}).encode()
        headers = self._headers(length=len(body), **{"Content-Type": "application/x-www-form-urlencoded"})
        ok = Dummy("/admin/pods/rotate", headers, body)
        ok.do_POST()
        self.assertEqual(ok.code, 200)
        again = Dummy("/admin/pods/rotate", headers, body)
        again.do_POST()
        self.assertEqual(again.code, 429)
        self.assertIn(b"Too many PodPanels requests", again.wfile.getvalue())
        self.assertNotIn(ROTATED.encode(), again.wfile.getvalue())

    def test_authelia_session_before_proxy_and_rotate(self):
        cookie = "authelia_session=do-not-log-this-cookie"
        headers = self._headers(**{"Cookie": cookie})
        real = self.saved["_authelia_opener"]()
        self.assertTrue(any(isinstance(h, eo_account._NoRedirect) for h in real.handlers))
        self.assertFalse(any(isinstance(h, urllib.request.ProxyHandler) for h in real.handlers))

        self.opener.error = None
        self.opener.status = 200
        self.opener.body = b"panel"
        got = Dummy("/admin/pods/app.js", headers)
        got.do_GET()
        self.assertEqual(got.code, 200)
        self.assertEqual(len(self.auth.calls), 1)
        req, timeout = self.auth.calls[0]
        self.assertEqual(timeout, 3)
        self.assertEqual(req.get_method(), "GET")
        self.assertEqual(req.full_url, eo_account.AUTHELIA_AUTHZ_URL)
        names = {k.lower(): v for k, v in req.header_items()}
        self.assertEqual(names.get("cookie"), cookie)
        self.assertEqual(names.get("x-original-method"), "GET")
        self.assertEqual(names.get("x-original-url"), eo_account.ORIGIN + "/admin/pods/app.js")
        self.assertEqual(names.get("x-forwarded-proto"), "https")
        self.assertEqual(names.get("x-forwarded-host"), "account.songofeo.com")
        for banned in ("remote-user", "authorization", "remote-groups", "x-podpanels-key", "x-podpanels-user", "x-forwarded-for"):
            self.assertNotIn(banned, names)
        self.assertNotIn(cookie, "\n".join(self.logs))
        self.assertNotIn(cookie, got.wfile.getvalue().decode("utf-8", "replace"))
        self.assertTrue(self.opener.calls)

        self.auth.calls.clear()
        self.opener.calls.clear()
        posted = Dummy("/admin/pods/status", self._headers(length=2, **{"Cookie": cookie}), b"{}")
        posted.do_POST()
        self.assertEqual(posted.code, 200)
        post_names = {k.lower(): v for k, v in self.auth.calls[0][0].header_items()}
        self.assertEqual(post_names.get("x-original-method"), "POST")
        self.assertEqual(post_names.get("x-original-url"), eo_account.ORIGIN + "/admin/pods/status")
        self.assertEqual(self.auth.calls[0][1], 3)
        self.assertEqual(len(self.auth.calls), 1)
        self.assertTrue(self.opener.calls)

        self.auth.calls.clear()
        self.opener.calls.clear()
        self.auth.user = "ada"
        mismatch = Dummy("/admin/pods/app.js", headers)
        mismatch.do_GET()
        self.assertEqual(mismatch.code, 403)
        self.assertIn(b"Only an admin", mismatch.wfile.getvalue())
        self.assertEqual(self.opener.calls, [])
        self.assertEqual(len(self.auth.calls), 1)
        self.assertNotIn(cookie, "\n".join(self.logs))

        self.auth.calls.clear()
        self.opener.calls.clear()
        stranger = Dummy("/admin/pods/app.js", self._headers(user="ada", **{"Cookie": cookie}))
        stranger.do_GET()
        self.assertEqual(stranger.code, 403)
        self.assertEqual(self.opener.calls, [])

        self.auth.status = 401
        self.auth.user = ""
        self.auth.calls.clear()
        self.opener.calls.clear()
        anon = Dummy("/admin/pods/app.js", headers)
        anon.do_GET()
        self.assertEqual(anon.code, 401)
        page = anon.wfile.getvalue().decode()
        self.assertIn(eo_account.SIGN_IN, page)
        self.assertIn("gate.songofeo.com", page)
        self.assertIn("Sign in", page)
        self.assertNotIn("<!--", page)
        self.assertNotIn(cookie, page)
        self.assertEqual(self.opener.calls, [])
        self.assertNotIn(cookie, "\n".join(self.logs))

        self.auth.error = urllib.error.URLError("down")
        self.auth.calls.clear()
        self.opener.calls.clear()
        down = Dummy("/admin/pods/app.js", headers)
        down.do_GET()
        self.assertEqual(down.code, 503)
        self.assertIn(b"sign-in check is offline", down.wfile.getvalue())
        self.assertNotIn(cookie.encode(), down.wfile.getvalue())
        self.assertEqual(self.opener.calls, [])
        self.assertTrue(any("unreachable" in line for line in self.logs))
        self.assertNotIn(cookie, "\n".join(self.logs))

        self.auth.error = TimeoutError("slow")
        self.opener.calls.clear()
        slow = Dummy("/admin/pods/app.js", headers)
        slow.do_GET()
        self.assertEqual(slow.code, 503)
        self.assertEqual(self.opener.calls, [])

        ts = int(time.time())
        body = urllib.parse.urlencode({"ts": str(ts), "token": eo_account.form_token("eels", ts)}).encode()
        self.opener.calls.clear()
        rot = Dummy(
            "/admin/pods/rotate",
            self._headers(length=len(body), **{"Cookie": cookie, "Content-Type": "application/x-www-form-urlencoded"}),
            body,
        )
        rot.do_POST()
        self.assertEqual(rot.code, 503)
        self.assertEqual(self.opener.calls, [])
        self.assertNotIn(cookie, "\n".join(self.logs))
        self.assertNotIn(ROTATED.encode(), rot.wfile.getvalue())

        self.auth.error = None
        self.auth.status = 302
        self.auth.user = "eels"
        self.auth.calls.clear()
        self.opener.calls.clear()
        bounced = Dummy("/admin/pods/app.js", headers)
        bounced.do_GET()
        self.assertEqual(bounced.code, 403)
        self.assertEqual(len(self.auth.calls), 1)
        self.assertEqual(self.opener.calls, [])

        self.auth.calls.clear()
        self.assertEqual(eo_account.authelia_session("GET", "/admin/pods/\r\nX-Injected: 1", cookie), ("no", ""))
        self.assertEqual(eo_account.authelia_session("GET", "/admin/pods/", "a=b\r\nX-Injected: 1"), ("no", ""))
        self.assertEqual(self.auth.calls, [])
        eo_account.AUTHELIA_AUTHZ_URL = "http://user:secret@127.0.0.1:9091/api/authz/auth-request"
        self.assertEqual(eo_account.authelia_session("GET", "/admin/pods/", cookie)[0], "down")
        self.assertEqual(self.auth.calls, [])
        self.assertNotIn(cookie, "\n".join(self.logs))
        self.assertNotIn("secret", "\n".join(self.logs))

    def test_docs_and_scripts_do_not_grow_a_paste_mode(self):
        script16 = (ROOT / "home/cobra-setup/16-gate-podpanels-key.sh").read_text()
        script15 = (ROOT / "home/cobra-setup/15-gate-accounts.sh").read_text()
        doc = (ROOT / "docs/podpanels-key.md").read_text()
        self.assertNotIn("read -r", script16)
        self.assertNotIn("read -s", script16)
        self.assertIn('--set) die "this script only generates a random key', script16)
        self.assertIn('Environment=PODPANELS_URL=http://127.0.0.1:8100', script15)
        self.assertIn("must bind 127.0.0.1:8100", script15)
        self.assertNotIn("PODPANELS_API_KEY", script15)
        self.assertIn("Secret=podpanels-key,type=env,target=PODPANELS_KEY", script15)
        self.assertIn("flowchart TD", doc)
        self.assertIn("not built", doc.lower())
        self.assertIn("hmac.compare_digest", doc)
        self.assertIn("Free-software path", doc)
        self.assertIn("SKETCH ONLY", doc)
        self.assertIn("two_factor", doc)
        self.assertIn("one_factor", doc)
        self.assertIn("manual step", doc)
        self.assertIn("not installed", doc)
        self.assertIn("^/admin/pods([/?]|$)", doc)
        self.assertIn("user:eels", doc)
        self.assertIn("policy: deny", doc)
        self.assertIn("above every", doc)
        self.assertIn("TOTP enrolled first", doc)
        self.assertIn("auth-request", doc)
        self.assertIn("must bind", doc)
        self.assertIn("http://127.0.0.1:8100", doc)
        self.assertNotIn("PODPANELS_URL=http://127.0.0.1:8099", doc)
        self.assertNotIn("<!--", doc)
        self.assertNotRegex(doc, r"[0-9a-f]{32}")
        nginx = (ROOT / "home/cobra-setup/templates/songofeo.conf").read_text()
        self.assertIn("listen 127.0.0.1:8099;", nginx)
        readme = (ROOT / "home/cobra-setup/README-v2.md").read_text()
        self.assertIn("No remote API door", readme)
        self.assertIn("flowchart TD", readme)
        self.assertIn("127.0.0.1:8100", readme)
        self.assertNotIn("127.0.0.1:8099", readme)
        account = (ROOT / "home/cobra-setup/account-gate/eo_account.py").read_text()
        self.assertIn('PODPANELS_URL", "http://127.0.0.1:8100"', account)
        self.assertIn("AUTHELIA_AUTHZ_URL", account)


if __name__ == "__main__":
    unittest.main()
