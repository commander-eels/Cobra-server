"""Smart home window (v3.8 draft): Home Assistant connector, admin-only page block and the change checks.

A fake Home Assistant runs on 127.0.0.1:8123 inside the test. Nothing reaches a real house. The token is made up.
"""

from __future__ import annotations

import json
import sys
import tempfile
import threading
import unittest
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import eo_account  # noqa: E402

TOKEN = "made-up-long-lived-token-abc123"
STATES = [
    {"entity_id": "light.den_lamp", "state": "off", "attributes": {"friendly_name": "Den lamp"}},
    {"entity_id": "switch.porch", "state": "on", "attributes": {"friendly_name": "Porch"}},
    {"entity_id": "climate.hall", "state": "heat", "attributes": {
        "friendly_name": "Hall thermostat", "current_temperature": 68, "temperature": 70,
        "min_temp": 50, "max_temp": 85, "hvac_modes": ["off", "heat", "cool"]}},
    {"entity_id": "lock.front_door", "state": "locked", "attributes": {"friendly_name": "Front door"}},
    {"entity_id": "sensor.x", "state": "1", "attributes": {}},
]


class FakeHA(BaseHTTPRequestHandler):
    calls: list = []
    refused = 0
    gets = 0

    def log_message(self, *a):
        pass

    def _ok(self) -> bool:
        if self.headers.get("Authorization") != f"Bearer {TOKEN}":
            FakeHA.refused += 1
            self.send_response(401); self.end_headers(); return False
        return True

    def do_GET(self):
        if not self._ok():
            return
        FakeHA.gets += 1
        body = json.dumps(STATES).encode()
        self.send_response(200); self.send_header("Content-Type", "application/json"); self.end_headers()
        self.wfile.write(body)

    def do_POST(self):
        if not self._ok():
            return
        n = int(self.headers.get("Content-Length") or 0)
        FakeHA.calls.append((self.path, json.loads(self.rfile.read(n) or b"{}")))
        self.send_response(200); self.send_header("Content-Type", "application/json"); self.end_headers()
        self.wfile.write(b"[]")


class HomeTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        try:
            cls.srv = ThreadingHTTPServer(("127.0.0.1", 8123), FakeHA)
        except OSError:
            raise unittest.SkipTest("127.0.0.1:8123 is busy")
        threading.Thread(target=cls.srv.serve_forever, daemon=True).start()

    @classmethod
    def tearDownClass(cls):
        cls.srv.shutdown()

    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.apps = Path(self.tmp.name) / "apps.json"
        self.old = eo_account.APPS_FILE
        eo_account.APPS_FILE = self.apps
        eo_account.HOME_HITS.clear()
        eo_account.HOME_REFUSED["token"] = ""
        eo_account.home_forget()
        FakeHA.calls.clear()
        self.write({"url": "http://127.0.0.1:8123", "token": TOKEN, "enabled": True})

    def tearDown(self):
        eo_account.APPS_FILE = self.old
        self.tmp.cleanup()

    def write(self, home):
        self.apps.write_text(json.dumps({"apps": {}, "home": home}))

    # --- config
    def test_url_must_be_vm120_or_loopback(self):
        for bad in ("http://evil.example:8123", "http://10.6.9.10:8123", "https://127.0.0.1:8123",
                    "http://127.0.0.1:8123/../x", "http://10.6.9.11:9999", "http://10.6.9.20:8123",
                    "http://10.6.9.110:8123", "file:///etc/passwd"):
            self.write({"url": bad, "token": TOKEN, "enabled": True})
            self.assertIsNone(eo_account.home_config(), bad)
        self.write({"url": "http://10.6.9.11:8123/", "token": TOKEN, "enabled": True})
        self.assertEqual(eo_account.home_config(), ("http://10.6.9.11:8123", TOKEN))

    def test_off_or_no_token_means_not_connected(self):
        self.write({"url": "http://127.0.0.1:8123", "token": TOKEN, "enabled": False})
        self.assertIsNone(eo_account.home_config())
        self.write({"url": "http://127.0.0.1:8123", "token": "", "enabled": True})
        self.assertIn("Not connected yet", eo_account.home_block("eels", set(), 1))

    # --- the list
    def test_only_lights_switches_thermostats(self):
        ids = [e["entity_id"] for e in eo_account.home_entities()]
        self.assertEqual(ids, ["light.den_lamp", "climate.hall", "switch.porch"])   # sorted by friendly name

    def test_block_is_admin_only_and_never_shows_the_token(self):
        self.assertEqual(eo_account.home_block("friend", set(), 1), "")
        page = eo_account.home_block("eels", set(), 1)
        self.assertIn("Den lamp", page)
        self.assertIn("Hall thermostat", page)
        self.assertNotIn("Front door", page)
        self.assertNotIn(TOKEN, page)
        self.assertIn('action="/admin/home"', page)

    def test_wrong_token_is_asked_once_then_never_again(self):
        # Home Assistant bans an address after 5 refused logins; the gate must not walk into that.
        self.write({"url": "http://127.0.0.1:8123", "token": "wrong", "enabled": True})
        FakeHA.refused = 0
        for _ in range(8):
            self.assertIn("Token refused", eo_account.home_block("eels", set(), 1))
        self.assertEqual(FakeHA.refused, 1)
        ok, _ = eo_account.home_change("light.den_lamp", "toggle", "", [STATES[0]])
        self.assertFalse(ok)
        self.assertEqual(FakeHA.refused, 1)
        # a new token in apps.json is tried again
        self.write({"url": "http://127.0.0.1:8123", "token": TOKEN, "enabled": True})
        self.assertIn("Den lamp", eo_account.home_block("eels", set(), 1))

    def test_ha_down_shows_not_answering(self):
        self.write({"url": "http://127.0.0.1:8123", "token": TOKEN, "enabled": True})
        self.srv.shutdown(); self.srv.server_close()
        try:
            self.assertIn("isn't answering", eo_account.home_block("eels", set(), 1))
        finally:
            type(self).srv = ThreadingHTTPServer(("127.0.0.1", 8123), FakeHA)
            threading.Thread(target=self.srv.serve_forever, daemon=True).start()

    def test_list_is_cached_and_a_change_clears_it(self):
        FakeHA.gets = 0
        eo_account.home_entities(); eo_account.home_entities(); eo_account.home_block("eels", set(), 1)
        self.assertEqual(FakeHA.gets, 1)
        eo_account.home_change("light.den_lamp", "toggle", "", eo_account.home_entities())
        eo_account.home_entities()
        self.assertEqual(FakeHA.gets, 2)

    def test_thermostat_with_null_limits_doesnt_crash(self):
        ent = {"entity_id": "climate.odd", "state": "heat",
               "attributes": {"min_temp": None, "max_temp": "n/a", "hvac_modes": ["heat"], "temperature": 70}}
        self.assertFalse(eo_account.home_change("climate.odd", "settemp", "99", [ent])[0])   # outside 45..90
        self.assertEqual(eo_account.home_num(None, 45), 45)
        self.assertEqual(eo_account.home_num("71.5", 45), 71.5)

    # --- changes
    def ents(self):
        return eo_account.home_entities()

    def test_toggle_light(self):
        ok, _ = eo_account.home_change("light.den_lamp", "toggle", "", self.ents())
        self.assertTrue(ok)
        self.assertEqual(FakeHA.calls, [("/api/services/light/toggle", {"entity_id": "light.den_lamp"})])

    def test_refuses_devices_not_listed_and_other_domains(self):
        for eid in ("lock.front_door", "light.not_there", "light.den_lamp/../x", "switch.porch;rm"):
            ok, _ = eo_account.home_change(eid, "toggle", "", self.ents())
            self.assertFalse(ok, eid)
        self.assertEqual(FakeHA.calls, [])

    def test_thermostat_range_and_modes(self):
        self.assertFalse(eo_account.home_change("climate.hall", "settemp", "120", self.ents())[0])
        self.assertFalse(eo_account.home_change("climate.hall", "settemp", "warm", self.ents())[0])
        self.assertFalse(eo_account.home_change("climate.hall", "mode", "turbo", self.ents())[0])
        self.assertFalse(eo_account.home_change("climate.hall", "toggle", "", self.ents())[0])
        self.assertEqual(FakeHA.calls, [])
        self.assertTrue(eo_account.home_change("climate.hall", "settemp", "72", self.ents())[0])
        self.assertTrue(eo_account.home_change("climate.hall", "mode", "cool", self.ents())[0])
        self.assertEqual([c[0] for c in FakeHA.calls],
                         ["/api/services/climate/set_temperature", "/api/services/climate/set_hvac_mode"])
        self.assertEqual(FakeHA.calls[0][1]["temperature"], 72.0)

    def test_rate_limit(self):
        for _ in range(eo_account.HOME_PER):
            self.assertFalse(eo_account.home_limited("eels"))
        self.assertTrue(eo_account.home_limited("eels"))
        self.assertFalse(eo_account.home_limited("other-admin"))

    def test_route_is_registered(self):
        src = Path(eo_account.__file__).read_text()
        self.assertIn('"/admin/home")', src)
        self.assertIn('return self._home(user, f)', src)


if __name__ == "__main__":
    unittest.main()
