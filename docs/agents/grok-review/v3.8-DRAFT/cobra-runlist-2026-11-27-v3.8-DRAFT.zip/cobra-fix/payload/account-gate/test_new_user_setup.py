"""New-user setup: Approve -> first sign-in makes the Bay accounts. And the session check on approvals.

Every app here is a fake that records calls. Nothing is sent to a real server. The passwords are made up.
"""

from __future__ import annotations

import io
import json
import sys
import tempfile
import time
import unittest
import urllib.parse
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import eo_account  # noqa: E402
from test_podpanels import AuthFake, Dummy  # noqa: E402

PW = "Made-up-pass-123"


class FakeHttp:
    """Answers by (METHOD, path start). Records (method, path, body) for every call."""

    def __init__(self, answers: dict):
        self.answers = answers
        self.calls: list[tuple[str, str, object]] = []

    def call(self, method, path, *, json_body=None, form=None, headers=None, raw=False):
        self.calls.append((method, path, json_body if json_body is not None else form))
        for (m, start), val in self.answers.items():
            if m == method and path.startswith(start):
                if isinstance(val, Exception):
                    raise val
                return val(path, json_body, form) if callable(val) else val
        return None

    def writes(self):
        return [c for c in self.calls if c[0] != "GET"]


def make(kind, answers, cfg=None):
    app = eo_account.KINDS[kind]({"url": "http://fake", "api_key": "k", "api_token": "t",
                                  "admin_user": "eels", "admin_password": "x", **(cfg or {})})
    app.http = FakeHttp(answers)
    app._token = "tok"          # Navidrome and Kavita skip their admin login
    app._in = True              # Calibre-Web too
    return app


ABS_LIBS = {"libraries": [{"id": "lib-audio", "name": "Audiobooks"},
                          {"id": "lib-talk", "name": "Talk Radio & Comedy Club"},
                          {"id": "lib-arch", "name": "The Archives"}]}
CW_FORM = ('<form><input type="hidden" name="csrf_token" value="c1"><input name="name" value="">'
           '<input type="email" name="email" value=""><input type="password" name="password">'
           '<input type="checkbox" name="download_role" checked><input type="checkbox" name="admin_role" checked>'
           '<select name="locale"><option value="en" selected>en</option></select></form>')


def fresh_apps(created: dict):
    """One of every app with nobody in it yet. created[kind] is set when that app makes the account."""
    def add(kind):
        def f(path, body, form):
            created[kind] = body if body is not None else (form or path)
            return {}
        return f
    cw_users = {"rows": []}

    def cw_new(path, body, form):
        created["calibre-web"] = form
        cw_users["rows"].append({"name": dict(form)["name"], "id": 7})
        return ""
    return [
        make("jellyfin", {("GET", "/Users"): [], ("POST", "/Users/New"): add("jellyfin")}),
        make("navidrome", {("GET", "/api/user"): [], ("POST", "/api/user"): add("navidrome")}),
        make("audiobookshelf", {("GET", "/api/users"): {"users": []}, ("GET", "/api/libraries"): ABS_LIBS,
                                ("POST", "/api/users"): add("audiobookshelf")}),
        make("kavita", {("GET", "/api/Users?includePending"): [], ("GET", "/api/Users"): [], ("GET", "/api/Account/roles"): ["Admin", "Pleb", "Login", "Download"],
                        ("GET", "/api/Library/libraries"): [{"id": 3, "name": "RPG Vault"}],
                        ("POST", "/api/Account/invite"): {"emailLink": "https://comics.songofeo.com/registration/confirm-email?token=ab%2Bcd&email=newbie%40users.songofeo.com"},
                        ("POST", "/api/Account/confirm-email"): add("kavita")}),
        make("romm", {("GET", "/api/users"): [], ("POST", "/api/users"): add("romm")}),
        make("calibre-web", {("GET", "/ajax/listusers"): lambda *a: cw_users, ("GET", "/admin/user/new"): CW_FORM,
                             ("POST", "/admin/user/new"): cw_new}),
    ]


class SetupAppsTests(unittest.TestCase):
    def setUp(self):
        self.saved = (eo_account.load_apps, eo_account.SERVING)
        eo_account.SERVING = False

    def tearDown(self):
        eo_account.load_apps, eo_account.SERVING = self.saved

    def run_setup(self, apps, user="newbie", groups=()):
        eo_account.load_apps = lambda: apps
        who = {"display": "New Bie", "email": "", "groups": set(groups)}
        return {r[0]: r for r in eo_account.setup_apps(user, PW, who)}

    def test_new_person_gets_every_bay_their_pass_allows(self):
        created: dict = {}
        apps = fresh_apps(created)
        res = self.run_setup(apps)
        status = {k: v[1] for k, v in res.items()}
        self.assertEqual(set(created), {"jellyfin", "audiobookshelf", "kavita", "romm", "calibre-web"}, status)
        self.assertEqual(status[eo_account.Navidrome.title], "skip")          # no music group: Music isn't on the pass
        self.assertEqual(res[eo_account.Navidrome.title][2], "not on your pass")
        self.assertEqual(apps[1].http.writes(), [])
        self.assertEqual(created["jellyfin"], {"Name": "newbie", "Password": PW})
        abs_body = created["audiobookshelf"]
        self.assertFalse(abs_body["permissions"]["accessAllLibraries"])
        self.assertEqual(abs_body["librariesAccessible"], ["lib-audio"])     # Talk and Archives walls held
        self.assertEqual(created["kavita"], {"email": "newbie@users.songofeo.com", "token": "ab+cd", "username": "newbie", "password": PW})
        invite = next(c for c in apps[3].http.calls if c[1] == "/api/Account/invite")[2]
        self.assertNotIn("Admin", invite["roles"])
        self.assertEqual(invite["libraries"], [3])
        self.assertEqual((created["romm"]["username"], created["romm"]["role"]), ("newbie", "viewer"))
        self.assertTrue(all("?" not in c[1] for c in apps[4].http.calls))       # nothing in a URL
        form = dict(created["calibre-web"])
        self.assertEqual((form["name"], form["password"], form["csrf_token"]), ("newbie", PW, "c1"))
        self.assertNotIn("admin_role", form)
        self.assertIn("download_role", form)

    def test_groups_open_music_talk_and_archives(self):
        created: dict = {}
        res = self.run_setup(fresh_apps(created), groups=("music", "talk", "archives"))
        self.assertEqual(res[eo_account.Navidrome.title][1], "ok")
        self.assertEqual(created["navidrome"]["userName"], "newbie")
        self.assertFalse(created["navidrome"]["isAdmin"])
        self.assertEqual(created["audiobookshelf"]["librariesAccessible"], ["lib-audio", "lib-talk", "lib-arch"])

    def test_accounts_already_there_are_never_touched(self):
        apps = [
            make("jellyfin", {("GET", "/Users"): [{"Name": "Newbie", "Id": "1"}]}),
            make("navidrome", {("GET", "/api/user"): [{"userName": "newbie", "id": "2"}]}),
            make("audiobookshelf", {("GET", "/api/users"): {"users": [{"username": "newbie", "id": "3"}]}}),
            make("kavita", {("GET", "/api/Users"): [{"username": "newbie", "id": 4}]}),
            make("romm", {("GET", "/api/users"): [{"username": "newbie", "id": 5}]}),
            make("calibre-web", {("GET", "/ajax/listusers"): {"rows": [{"name": "newbie", "id": 6}]}}),
        ]
        res = self.run_setup(apps, groups=("music",))
        for app in apps:
            self.assertEqual(app.http.writes(), [], app.title)                    # not even a password change
            self.assertEqual(res[app.title][1:], ("skip", "already there, left as it is"))

    def test_one_app_failing_never_stops_the_others(self):
        created: dict = {}
        apps = fresh_apps(created)
        apps[0].http.answers[("POST", "/Users/New")] = RuntimeError("POST /Users/New -> HTTP 500 boom")
        res = self.run_setup(apps)
        self.assertEqual(res[eo_account.Jellyfin.title][1], "fail")
        self.assertIn("calibre-web", created)

    def test_romm_422_never_puts_the_password_in_a_url_or_message(self):
        app = make("romm", {("GET", "/api/users"): [], ("POST", "/api/users"): RuntimeError("POST /api/users -> HTTP 422 x")})
        res = self.run_setup([app])
        self.assertEqual(res[app.title][1], "fail")
        self.assertNotIn(PW, res[app.title][2])
        self.assertEqual([c[1] for c in app.http.writes()], ["/api/users"])

    def test_http_error_text_drops_the_query_string(self):
        import urllib.error
        h = eo_account.Http("http://fake")

        class Opener:
            def open(self, req, timeout=None):
                raise urllib.error.HTTPError(req.full_url, 500, "x", {}, io.BytesIO(b"boom"))
        h.opener = Opener()
        with self.assertRaises(RuntimeError) as cm:
            h.call("POST", "/api/users?password=" + PW)
        self.assertNotIn(PW, str(cm.exception))
        self.assertIn("/api/users -> HTTP 500", str(cm.exception))

    def test_lookalike_library_is_not_given_away(self):
        libs = [{"id": "a", "name": "Audiobooks"}, {"id": "t", "name": "Talk Radio & Comedy Club"},
                {"id": "x", "name": "Talk Shows Extra"}, {"id": "r", "name": "The Archives"}]
        self.assertEqual(eo_account.new_user_libraries("newbie", set(), libs), ["a"])
        self.assertEqual(eo_account.new_user_libraries("newbie", {"talk", "archives"}, libs), ["a", "t", "r"])

    def test_kavita_uses_the_station_address_and_clears_its_own_half_invite(self):
        app = make("kavita", {("GET", "/api/Users?includePending"): [
                                  {"username": "newbie@users.songofeo.com", "isPending": True},
                                  {"username": "someone@example.invalid", "isPending": True}],
                              ("GET", "/api/Users"): [], ("GET", "/api/Account/roles"): ["Pleb"],
                              ("GET", "/api/Library/libraries"): [],
                              ("POST", "/api/Account/invite"): {"emailLink": "https://k/confirm-email?token=t1&email=newbie%40users.songofeo.com"},
                              ("POST", "/api/Account/confirm-email"): {}})
        eo_account.load_apps = lambda: [app]
        res = {r[0]: r for r in eo_account.setup_apps("newbie", PW, {"display": "N", "email": "real@example.invalid", "groups": set()})}
        self.assertEqual(res[app.title][1], "ok")
        deletes = [c[1] for c in app.http.calls if c[0] == "DELETE"]
        self.assertEqual(deletes, ["/api/Users/delete-user?username=newbie%40users.songofeo.com"])   # never someone else's
        invite = next(c for c in app.http.calls if c[1] == "/api/Account/invite")[2]
        self.assertEqual(invite["email"], "newbie@users.songofeo.com")                            # not their real inbox

    def test_calibre_web_that_drops_the_account_is_a_fail(self):
        app = make("calibre-web", {("GET", "/ajax/listusers"): {"rows": []}, ("GET", "/admin/user/new"): CW_FORM,
                                   ("POST", "/admin/user/new"): ""})
        res = self.run_setup([app])
        self.assertEqual(res[app.title][1], "fail")
        self.assertIn("didn't keep", res[app.title][2])


class ApprovalTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        root = Path(self.tmp.name)
        self.saved = {k: getattr(eo_account, k) for k in
                      ("USERS_FILE", "REQUESTS_FILE", "SETUP_FILE", "RESYNC_FILE", "APPS_FILE", "ADMINS",
                       "_authelia_opener", "AUTHELIA_AUTHZ_URL", "log", "load_apps")}
        eo_account.USERS_FILE = root / "users.yml"
        eo_account.USERS_FILE.write_text("users:\n  eels:\n    displayname: Eels\n    password: x\n    email: e@example.invalid\n    groups:\n      - admins\n")
        eo_account.REQUESTS_FILE = root / "requests.json"
        eo_account.SETUP_FILE = root / "setup.json"
        eo_account.RESYNC_FILE = root / "resync.json"
        eo_account.APPS_FILE = root / "apps.json"
        eo_account.ADMINS = {"eels"}
        eo_account.AUTHELIA_AUTHZ_URL = "http://127.0.0.1:9091/api/authz/auth-request"
        eo_account.log = lambda *a: None
        eo_account.load_apps = lambda: []
        req = {"id": "r1", "kind": "access", "username": "newbie", "name": "New Bie", "contact": "newbie@example.invalid",
               "hash": eo_account.authelia_hash(PW), "at": int(time.time())}
        eo_account.save_requests([req])

    def tearDown(self):
        for k, v in self.saved.items():
            setattr(eo_account, k, v)
        self.tmp.cleanup()

    def post(self, auth, remote="eels"):
        eo_account._authelia_opener = lambda: auth
        ts = int(time.time())
        body = urllib.parse.urlencode({"id": "r1", "do": "approve", "ts": ts, "token": eo_account.form_token(remote, ts)}).encode()
        h = Dummy("/admin/access", {"Remote-User": remote, "Cookie": "authelia_session=s", "Origin": eo_account.ORIGIN,
                                    "Content-Type": "application/x-www-form-urlencoded", "Content-Length": str(len(body))}, body)
        h.do_POST()
        return h

    def test_forged_header_without_a_session_approves_nothing(self):
        h = self.post(AuthFake(status=401))
        self.assertEqual(h.code, 401)
        self.assertNotIn("newbie", eo_account.users_in_file())
        self.assertEqual(len(eo_account.load_requests()), 1)
        self.assertEqual(eo_account.load_setup(), set())

    def test_session_for_someone_else_is_refused(self):
        h = self.post(AuthFake(status=200, user="rachel"))
        self.assertEqual(h.code, 403)
        self.assertNotIn("newbie", eo_account.users_in_file())

    def test_authelia_down_fails_closed(self):
        import urllib.error
        h = self.post(AuthFake(error=urllib.error.URLError("down")))
        self.assertEqual(h.code, 503)
        self.assertNotIn("newbie", eo_account.users_in_file())

    def test_setup_says_locked_or_offline_instead_of_wrong_password(self):
        eo_account.set_setup("newbie", True)
        for verdict, code, words in (("locked", 200, b"locked"), ("down", 503, b"offline")):
            saved = eo_account.authelia_password_verdict
            eo_account.authelia_password_verdict = lambda *a, v=verdict: v
            try:
                ts = int(time.time())
                body = urllib.parse.urlencode({"current": PW, "ts": ts, "token": eo_account.form_token("newbie", ts)}).encode()
                h = Dummy("/f/setup", {"Remote-User": "newbie", "Origin": eo_account.ORIGIN, "X-Real-IP": f"10.0.0.{code % 7}",
                                       "Content-Type": "application/x-www-form-urlencoded", "Content-Length": str(len(body))}, body)
                h.do_POST()
            finally:
                eo_account.authelia_password_verdict = saved
            self.assertEqual(h.code, code)
            self.assertIn(words, h.wfile.getvalue())
            self.assertEqual(eo_account.load_setup(), {"newbie"})

    def test_real_session_approves_and_queues_the_bay_setup(self):
        h = self.post(AuthFake(status=200, user="eels"))
        self.assertEqual(h.code, 200, h.wfile.getvalue()[:300])
        self.assertIn("newbie", eo_account.users_in_file())
        self.assertEqual(eo_account.load_setup(), {"newbie"})
        self.assertIn(b"open their Bays", h.wfile.getvalue())
        rec = eo_account.user_record("newbie")
        self.assertEqual(rec["display"], "New Bie")
        self.assertNotIn("password", json.dumps(sorted(rec["groups"])))
        page = eo_account.form_page("newbie")
        self.assertIn("Open my Bays", page)


if __name__ == "__main__":
    unittest.main()
