# Lets the station's own pages (songofeo.com) talk to the floors' apps in the browser,
# so the website's players (web/*/play/) work without the Android app.
#
# Copy it to /srv/gate/nginx/conf.d/station-cors.inc on the gate (an .inc name, so nginx doesn't
# load it on its own as a *.conf), then include it at the top of `location / { ... }` in the floors'
# server block (cobra-server manual, part 5.4), above auth_request. See README.md beside this file.

# Only the station's own pages are let in, never any other site: the station itself (station.songofeo.com,
# behind the gate, where the players now run) and the public homepage (songofeo.com, www).
set $station_origin "";
if ($http_origin ~ "^https://(www\.|station\.)?songofeo\.com$") { set $station_origin $http_origin; }

# The apps send their own CORS answers (Jellyfin answers "*"); drop them so only ours goes out.
proxy_hide_header Access-Control-Allow-Origin;
proxy_hide_header Access-Control-Allow-Credentials;
proxy_hide_header Access-Control-Allow-Headers;
proxy_hide_header Access-Control-Allow-Methods;
proxy_hide_header Access-Control-Expose-Headers;

# `always`, so the gate's own redirect to its sign-in carries them too and the page can tell
# "sign in first" from "home is away". An empty origin sends no header at all.
add_header Access-Control-Allow-Origin $station_origin always;
add_header Access-Control-Allow-Credentials "true" always;
add_header Access-Control-Allow-Headers "Authorization, Content-Type, Accept, Range, X-Emby-Authorization, x-refresh-token, x-return-tokens" always;
add_header Access-Control-Allow-Methods "GET, POST, PUT, PATCH, DELETE, OPTIONS" always;
add_header Access-Control-Expose-Headers "Content-Length, Content-Range, Accept-Ranges" always;
add_header Access-Control-Max-Age "600" always;
add_header Vary "Origin" always;
# A location with its own add_header drops the server's, so HSTS is said again here.
add_header Strict-Transport-Security "max-age=31536000" always;

# The browser's preflight carries no cookies, so answer it here, before the sign-in check.
if ($request_method = OPTIONS) { return 204; }
