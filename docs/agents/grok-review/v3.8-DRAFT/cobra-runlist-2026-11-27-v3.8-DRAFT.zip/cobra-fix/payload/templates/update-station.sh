#!/usr/bin/env bash
# Pulls the station's website (the repository's `station` branch, filled by the Publish site Action)
# into /srv/station/web, where nginx serves it at station.songofeo.com behind Authelia.
#
# Run by station-update.timer every 5 minutes; safe to run by hand any time:
#   sudo /srv/station/update-station.sh
#
# The git data lives in /srv/station/station.git, outside the web root, so no .git folder is ever served.
# The web root is made to match the branch exactly: files removed from the branch are removed here too.
# Nothing else under /srv/station is touched.
set -euo pipefail

REPO="${STATION_REPO:-git@github.com:agent61636/project-eo.git}"   # SSH, read with the deploy key (README step 2)
BRANCH="${STATION_BRANCH:-station}"
GIT_DIR="${STATION_GIT_DIR:-/srv/station/station.git}"
WEB="${STATION_WEB:-/srv/station/web}"
export GIT_SSH_COMMAND="${GIT_SSH_COMMAND:-ssh -i /srv/station/deploy_key -o IdentitiesOnly=yes -o StrictHostKeyChecking=accept-new}"

mkdir -p "$WEB"
# First run: an empty, bare-style repository that only ever holds the one branch.
if [ ! -d "$GIT_DIR" ]; then
  git init -q --bare "$GIT_DIR"
  git --git-dir="$GIT_DIR" remote add origin "$REPO"
fi

# Fetch only the station branch, one commit deep (the Action force-pushes it, so history is one commit).
git --git-dir="$GIT_DIR" fetch -q --depth 1 origin "+refs/heads/$BRANCH:refs/remotes/origin/$BRANCH"
new="$(git --git-dir="$GIT_DIR" rev-parse "refs/remotes/origin/$BRANCH")"
old="$(cat "$GIT_DIR/deployed" 2>/dev/null || true)"
if [ "$new" = "$old" ]; then exit 0; fi   # already serving this version

# Make the web root match the branch: overwrite changed files, then remove anything the branch no longer has.
git --git-dir="$GIT_DIR" --work-tree="$WEB" reset -q --hard "$new"
git --git-dir="$GIT_DIR" --work-tree="$WEB" clean -q -fdx
# nginx (in its container) only needs to read the files.
chmod -R a+rX "$WEB"
echo "$new" > "$GIT_DIR/deployed"
echo "station.songofeo.com now serves $(git --git-dir="$GIT_DIR" log -1 --format='%h %s' "$new")"
