# Art slots

The board works with no pictures at all. Each slot below shows a dashed "ART SLOT" box until a PNG is saved here under that exact name; then the picture takes its place. No code changes needed.

| File | Where it shows | Suggested size |
|---|---|---|
| `marquee.png` | The lit sign at the top of the board | 1600 x 400 |
| `column-most-played.png` | Over the "Most played" column | 800 x 240 |
| `column-last-played.png` | Over the "Last played" column | 800 x 240 |
| `column-longest-standing.png` | Over the "Longest standing" column | 800 x 240 |
| `games/<game>.png` | The square tile beside a game, everywhere it appears. `<game>` is the score file's name without `.hi`, `.txt` or `.json`, in lower case (for `comet.hi`, save `games/comet.png`) | 256 x 256 |

Until a game has its own tile, the tile shows the game's first letter.

To hide empty slots instead of showing the dashed boxes, remove `sb-slots` from the `<body class="...">` line in `forms/index.html`.

Pictures are decoration: the board never relies on them to say anything, so they carry empty alt text. Use only art you made or have the rights to. Don't use game screenshots, cabinet marquee scans or logos you don't own.
