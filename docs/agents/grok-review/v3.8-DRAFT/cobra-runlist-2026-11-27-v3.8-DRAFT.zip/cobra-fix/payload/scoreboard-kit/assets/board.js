/* The Scoreboard kit: draws the board from the collector's data.
 *
 * Add to the board page, after the data file:
 *   <script src="../data/scoreboard.js" defer></script>
 *   <script src="../assets/board.js" defer></script>
 *
 * The collector writes data/scoreboard.js (window.SCOREBOARD = {...}) once a day. Loading the data
 * as a script, not with a network request, means the board also works opened straight from disk.
 *
 * Every name and score comes from a cabinet or a player, so it is only ever put on the page as
 * text (textContent), never as HTML.
 *
 * Art slots: any element with data-art="../art/name.png" shows that picture once the file
 * exists, and a marked "ART SLOT" box until then. Game tiles look for ../art/games/<game>.png.
 *
 * It collects nothing about the visitor: no cookies, no storage, no tracking, no third parties.
 */
(function () {
  "use strict";

  var DAY = 86400000;

  function el(tag, cls, text) {
    var n = document.createElement(tag);
    if (cls) n.className = cls;
    if (text !== undefined && text !== null) n.textContent = String(text);
    return n;
  }

  function art(slot) {
    var src = slot.getAttribute("data-art");
    var img = new Image();
    img.alt = slot.getAttribute("data-art-alt") || "";
    img.decoding = "async";
    img.onload = function () {
      slot.textContent = "";
      slot.appendChild(img);
      slot.setAttribute("data-state", "art");
    };
    slot.setAttribute("data-state", "empty");
    if (!slot.textContent.trim()) slot.textContent = src.replace(/^\.\.\//, "") + " " + (slot.getAttribute("data-art-size") || "");
    img.src = src;
  }

  function tile(game, title, big) {
    var t = el("span", "sb-tile" + (big ? " sb-tile--big" : ""), (title || "?").charAt(0).toUpperCase());
    t.setAttribute("aria-hidden", "true");
    if (/^[a-z0-9._-]+$/.test(game)) {
      var img = new Image();
      img.alt = "";
      img.onload = function () { t.textContent = ""; t.appendChild(img); };
      img.src = "../art/games/" + game + ".png";
    }
    return t;
  }

  function when(iso, now) {
    var t = el("time", "sb-when");
    t.dateTime = iso;
    var days = Math.floor((now - Date.parse(iso)) / DAY);
    var date = new Date(iso).toLocaleDateString(undefined, { year: "numeric", month: "short", day: "numeric" });
    t.textContent = days <= 0 ? "today" : days === 1 ? "yesterday" : days < 30 ? days + " days ago" : date;
    t.title = date;
    return t;
  }

  function who(row) {
    return row.player ? row.player + " (" + row.initials + ")" : (row.initials || "no initials");
  }

  function empty(list, words) {
    var li = el("li", "sb-empty", words);
    li.style.display = "block";
    list.appendChild(li);
  }

  function recent(data, now) {
    var box = document.getElementById("sb-recent-list");
    var feature = document.getElementById("sb-feature");
    var rows = data.recent || [];
    if (!rows.length) {
      feature.hidden = true;
      empty(box, "No new high scores in the last " + data.recent_days + " days. Go set one!");
      return;
    }
    var top = rows[0];
    feature.appendChild(tile(top.game, top.title, true));
    var text = el("div");
    text.appendChild(el("p", "sb-kicker", "Newest high score"));
    text.appendChild(el("p", "sb-score", top.score));
    text.appendChild(el("p", "sb-game", top.title));
    var line = el("p", "sb-who", who(top) + " on the " + top.cabinet + ", spotted ");
    line.appendChild(when(top.spotted, now));
    text.appendChild(line);
    feature.appendChild(text);
    rows.slice(1, 9).forEach(function (r) {
      var li = el("li");
      li.appendChild(tile(r.game, r.title));
      var mid = el("div");
      mid.appendChild(el("span", "sb-game", r.title));
      mid.appendChild(el("span", "sb-who", who(r)));
      mid.appendChild(when(r.spotted, now));
      li.appendChild(mid);
      li.appendChild(el("span", "sb-score", r.score));
      box.appendChild(li);
    });
  }

  function mostPlayed(data) {
    var box = document.getElementById("sb-most");
    var m = data.most_played || { games: [] };
    document.getElementById("sb-most-basis").textContent = m.basis === "plays" ?
      "Counted from every game started." : "Counted from new high scores, until a plays log is set up.";
    if (!m.games.length) return empty(box, "Nothing played yet.");
    m.games.forEach(function (g) {
      var li = el("li");
      li.appendChild(tile(g.game, g.title));
      li.appendChild(el("span", "sb-game", g.title));
      var right = el("span");
      right.appendChild(el("span", "sb-score", g.count));
      var unit = m.basis === "plays" ? (g.count === 1 ? "play" : "plays") : (g.count === 1 ? "new score" : "new scores");
      if (g.minutes) unit += ", " + g.minutes + " min";
      right.appendChild(el("span", "sb-unit", unit));
      li.appendChild(right);
      box.appendChild(li);
    });
  }

  function lastPlayed(data, now) {
    var box = document.getElementById("sb-last");
    var rows = data.last_played || [];
    if (!rows.length) return empty(box, "No players yet. Claim a score to put your name here.");
    rows.forEach(function (r) {
      var li = el("li");
      li.appendChild(tile(r.game, r.title));
      var mid = el("div");
      mid.appendChild(el("span", "sb-game", r.player));
      mid.appendChild(el("span", "sb-who", (r.how === "scored" ? "Set a score on " : "Played ") + r.title));
      li.appendChild(mid);
      li.appendChild(when(r.time, now));
      box.appendChild(li);
    });
  }

  function longest(data) {
    var box = document.getElementById("sb-longest");
    var rows = data.longest_standing || [];
    if (!rows.length) return empty(box, "No champions yet.");
    rows.forEach(function (r) {
      var li = el("li");
      li.appendChild(tile(r.game, r.title));
      var mid = el("div");
      mid.appendChild(el("span", "sb-game", r.title));
      mid.appendChild(el("span", "sb-who", r.score + " by " + who(r)));
      li.appendChild(mid);
      var right = el("span");
      right.appendChild(el("span", "sb-score", r.days));
      right.appendChild(el("span", "sb-unit", r.days === 1 ? "day held" : "days held"));
      li.appendChild(right);
      box.appendChild(li);
    });
  }

  function allGames(data, now) {
    var box = document.getElementById("sb-games-list");
    var games = data.games || {};
    var keys = Object.keys(games);
    if (!keys.length) return box.appendChild(el("p", "sb-empty", "No score tables yet."));
    keys.forEach(function (key) {
      var g = games[key];
      var d = el("details");
      d.appendChild(el("summary", "", g.title + " (" + g.top.length + (g.top.length === 1 ? " score)" : " scores)")));
      var wrap = el("div", "sb-table-wrap");
      var table = el("table");
      table.appendChild(el("caption", "", "Best " + g.title + " scores ever seen" +
        (g.lower_is_better ? " (lowest time wins)" : "")));
      var head = el("tr");
      ["Place", "Score", "Player", "Cabinet", "Spotted"].forEach(function (h, i) {
        var th = el("th", i < 2 ? "sb-num" : "", h);
        th.scope = "col";
        head.appendChild(th);
      });
      var thead = el("thead");
      thead.appendChild(head);
      table.appendChild(thead);
      var tbody = el("tbody");
      g.top.forEach(function (r, i) {
        var tr = el("tr");
        tr.appendChild(el("td", "sb-num", i + 1));
        tr.appendChild(el("td", "sb-num", r.score));
        tr.appendChild(el("td", "", who(r)));
        tr.appendChild(el("td", "", r.cabinet));
        var td = el("td");
        td.appendChild(when(r.spotted, now));
        tr.appendChild(td);
        tbody.appendChild(tr);
      });
      table.appendChild(tbody);
      wrap.appendChild(table);
      d.appendChild(wrap);
      box.appendChild(d);
    });
  }

  function start() {
    document.querySelectorAll("[data-art]").forEach(art);
    var data = window.SCOREBOARD;
    var status = document.getElementById("sb-status");
    if (!data || typeof data !== "object") {
      status.textContent = "The scores haven't been collected yet. They appear here after the first daily run.";
      return;
    }
    var now = Date.now();
    if (data.title) document.getElementById("sb-title").textContent = data.title;
    var c = data.counts || {};
    status.textContent = (c.scores || 0) + " scores from " + (c.games || 0) + " games on " + (c.cabinets || 0) +
      (c.cabinets === 1 ? " cabinet" : " cabinets") + ". Updated ";
    status.appendChild(when(data.generated, now));
    status.appendChild(document.createTextNode("."));
    recent(data, now);
    mostPlayed(data);
    lastPlayed(data, now);
    longest(data);
    allGames(data, now);
  }

  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", start);
  else start();
})();
