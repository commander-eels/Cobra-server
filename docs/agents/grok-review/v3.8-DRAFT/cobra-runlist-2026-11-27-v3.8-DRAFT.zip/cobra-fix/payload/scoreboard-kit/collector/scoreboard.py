#!/usr/bin/env python3
"""The Scoreboard collector: keeps every arcade high score, even after a cabinet is reset.

Standard library only. Python 3.11 or newer for a .toml settings file (3.9+ with a .json one).

    python3 scoreboard.py --config scoreboard.toml check     # read-only: what would be collected
    python3 scoreboard.py --config scoreboard.toml run       # collect, then build the page data
    python3 scoreboard.py --config scoreboard.toml collect   # only copy new score files into the archive
    python3 scoreboard.py --config scoreboard.toml build     # only rebuild scoreboard.json / scoreboard.js
    python3 scoreboard.py --config scoreboard.toml claim --initials ACE --player "Ace Pilot" [--game cometclash]
    python3 scoreboard.py --config scoreboard.toml hide --game cometclash --initials BOT --score 999999 --reason "glitch"

How the archive works (it is never rewritten):
  archive/raw/<cabinet>/<file>/<time>-<hash><ext>   every version of every score file, byte for byte.
                                                    Written once with "create, fail if it exists".
  archive/ledger.jsonl                              one line per event, only ever appended:
      file   a new version of a score file arrived from a cabinet
      table  the scores read out of that version
      play   someone played a game (from a plays source)
      claim  the owner approved "these initials belong to this player"
      hide   the owner hid one score from the board (it stays in the ledger)
  Everything on the page is worked out again from the ledger on every build, so a cabinet that
  is reset to factory scores can't erase anything: old entries are still in older table events.

What it reads from a cabinet folder:
  *.hi            raw high score memory saved by MAME's hiscore plugin. Archived as is. Turned into
                  a table by the cabinet's "decoder" (such as hi2txt), or by a <game>.txt next to it.
  *.txt           a table already decoded on the cabinet (hi2txt output: "RANK|SCORE|NAME" lines).
  *.json          a table from any other source: {"game": "x", "scores": [{"rank","score","name"}]}.
  hiscore.dat     the plugin's list of where each game keeps its scores. Archived for reference;
                  it holds no scores itself.

Nothing about visitors is read or written. Names on the board are the initials the cabinet saved,
or a player name the owner approved with "claim".
"""

from __future__ import annotations

import argparse
import csv
import fnmatch
import hashlib
import json
import os
import re
import subprocess
import sys
from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone
from pathlib import Path

VERSION = "0.1"
DEFAULT_PATTERNS = ["*.hi", "*.txt", "*.json", "hiscore.dat"]
SAFE = re.compile(r"[^a-z0-9._-]+")
MAX_ROWS = 50          # entries read from one table
MAX_FIELD = 32         # characters kept from one cell
MAX_FILE = 4 * 1024 * 1024

RANK = {"RANK", "POS", "POSITION", "PLACE", "#", "NO", "NO."}
SCORE = {"SCORE", "HISCORE", "HI-SCORE", "HI SCORE", "POINTS", "PTS", "TOP SCORE", "BEST", "TIME"}
NAME = {"NAME", "INITIALS", "PLAYER", "INITIAL"}


class SetupError(Exception):
    """A problem with the settings file. Shown to the owner in plain words."""


# ------------------------------------------------------------------ small helpers

def utc(text: str | None = None) -> datetime:
    if text:
        t = datetime.fromisoformat(text.replace("Z", "+00:00"))
        return t if t.tzinfo else t.replace(tzinfo=timezone.utc)
    return datetime.now(timezone.utc)


def iso(t: datetime) -> str:
    return t.astimezone(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def slug(text: str) -> str:
    s = SAFE.sub("-", str(text).strip().lower()).strip("-.")
    return s[:64] or "unnamed"


def clean_cell(text: object) -> str:
    """One short line of plain text: no control characters, no markup characters."""
    s = "".join(ch for ch in str(text) if ch.isprintable())
    s = s.replace("<", "").replace(">", "").strip()
    return s[:MAX_FIELD]


def score_value(text: str) -> int:
    """The digits of a score, as a number. '1,234,560' -> 1234560. Times like 1'23"45 -> 12345."""
    digits = re.sub(r"\D", "", text)
    return int(digits[:18]) if digits else 0


def warn(msg: str) -> None:
    print("  warning: " + msg, file=sys.stderr)


# ------------------------------------------------------------------ settings

@dataclass
class Cabinet:
    name: str
    path: Path
    patterns: list[str]
    pull: list[str] = field(default_factory=list)
    decoder: list[str] = field(default_factory=list)

    @property
    def key(self) -> str:
        return slug(self.name)


@dataclass
class PlaySource:
    type: str
    path: Path
    player: str = ""
    cabinet: str = ""


@dataclass
class Settings:
    title: str
    archive: Path
    output: Path
    recent_days: int
    top: int
    ignore_initials: set[str]
    lower_is_better: set[str]
    titles: dict[str, str]
    cabinets: list[Cabinet]
    plays: list[PlaySource]


def load_settings(path: Path) -> Settings:
    path = Path(path)
    if not path.is_file():
        raise SetupError(f"settings file not found: {path}")
    raw = path.read_bytes()
    if path.suffix.lower() == ".toml":
        try:
            import tomllib
        except ImportError as e:
            raise SetupError("a .toml settings file needs Python 3.11 or newer; use a .json file instead") from e
        data = tomllib.loads(raw.decode("utf-8"))
    else:
        data = json.loads(raw.decode("utf-8"))
    base = path.parent

    def where(value: str, what: str) -> Path:
        if not value:
            raise SetupError(f"{what} is missing")
        p = Path(os.path.expanduser(str(value)))
        return p if p.is_absolute() else (base / p)

    board = data.get("board", {})
    cabinets = []
    for i, c in enumerate(data.get("cabinets", [])):
        name = str(c.get("name", "")).strip()
        if not name:
            raise SetupError(f"cabinet number {i + 1} has no name")
        for key in ("pull", "decoder"):
            if c.get(key) and not (isinstance(c[key], list) and all(isinstance(x, str) for x in c[key])):
                raise SetupError(f'cabinet "{name}": {key} must be a list of words, like ["hi2txt", "-r", "{{file}}"]')
        cabinets.append(Cabinet(name=name, path=where(c.get("path", ""), f'cabinet "{name}" path'),
                                patterns=list(c.get("patterns", DEFAULT_PATTERNS)),
                                pull=list(c.get("pull", [])), decoder=list(c.get("decoder", []))))
    if len({c.key for c in cabinets}) != len(cabinets):
        raise SetupError("two cabinets have the same name")
    plays = []
    for p in data.get("plays", []):
        kind = str(p.get("type", ""))
        if kind not in ("csv", "retroarch"):
            raise SetupError(f'plays type "{kind}" is not known: use "csv" or "retroarch"')
        if kind == "retroarch" and not p.get("player"):
            raise SetupError("a retroarch plays source needs the player's name")
        plays.append(PlaySource(type=kind, path=where(p.get("path", ""), "plays path"),
                                player=str(p.get("player", "")), cabinet=str(p.get("cabinet", ""))))
    return Settings(
        title=str(board.get("title", "The Scoreboard")),
        archive=where(board.get("archive", ""), "board.archive (where history is kept)"),
        output=where(board.get("output", ""), "board.output (where the page data goes)"),
        recent_days=int(board.get("recent_days", 14)),
        top=int(board.get("top", 10)),
        ignore_initials={str(x).upper() for x in board.get("ignore_initials", [])},
        lower_is_better={slug(x) for x in board.get("lower_is_better", [])},
        titles={slug(k): str(v) for k, v in data.get("titles", {}).items()},
        cabinets=cabinets, plays=plays)


# ------------------------------------------------------------------ reading score tables

def _split(line: str) -> list[str]:
    if "|" in line:
        return [c.strip() for c in line.split("|")]
    if "\t" in line:
        return [c.strip() for c in line.split("\t")]
    return [c for c in re.split(r"\s{2,}", line.strip())]


def _column(header: list[str], names: set[str]) -> int | None:
    for i, h in enumerate(header):
        if h.upper() in names:
            return i
    return None


def parse_text_table(text: str) -> list[dict]:
    """hi2txt-style text: blocks of a header line and rows. Takes the first block with a score column."""
    blocks, block = [], []
    for raw in text.splitlines():
        line = raw.strip()
        if line:
            block.append(line)
        elif block:
            blocks.append(block)
            block = []
    if block:
        blocks.append(block)
    for block in blocks:
        header = _split(block[0])
        si = _column(header, SCORE)
        if si is None:
            continue
        ri, ni = _column(header, RANK), _column(header, NAME)
        rows = []
        for line in block[1:]:
            cells = _split(line)
            if len(cells) <= si or not cells[si].strip():
                continue
            get = lambda i: cells[i] if i is not None and i < len(cells) else ""
            rows.append({"rank": clean_cell(get(ri) or len(rows) + 1), "score": clean_cell(cells[si]),
                         "name": clean_cell(get(ni))})
            if len(rows) == MAX_ROWS:
                break
        if rows:
            return rows
    return []


def parse_json_table(data: object) -> tuple[str, list[dict]]:
    """{"game": "x", "scores": [...]} or a bare list of rows. Returns (game or "", rows)."""
    game, rows = "", data
    if isinstance(data, dict):
        game, rows = str(data.get("game", "")), data.get("scores", [])
    out = []
    if isinstance(rows, list):
        for r in rows[:MAX_ROWS]:
            if isinstance(r, dict) and str(r.get("score", "")).strip():
                out.append({"rank": clean_cell(r.get("rank", len(out) + 1)), "score": clean_cell(r["score"]),
                            "name": clean_cell(r.get("name", r.get("initials", "")))})
    return game, out


# ------------------------------------------------------------------ the archive

class Archive:
    def __init__(self, root: Path):
        self.root = Path(root)
        self.raw = self.root / "raw"
        self.ledger_path = self.root / "ledger.jsonl"

    def events(self) -> list[dict]:
        if not self.ledger_path.exists():
            return []
        out = []
        with self.ledger_path.open(encoding="utf-8") as f:
            for n, line in enumerate(f, 1):
                line = line.strip()
                if not line:
                    continue
                try:
                    out.append(json.loads(line))
                except json.JSONDecodeError:
                    warn(f"ledger line {n} can't be read and was skipped (it is left in the file)")
        return out

    def append(self, events: list[dict]) -> None:
        if not events:
            return
        self.root.mkdir(parents=True, exist_ok=True)
        with self.ledger_path.open("a", encoding="utf-8") as f:
            for e in events:
                f.write(json.dumps(e, ensure_ascii=False, sort_keys=True) + "\n")
            f.flush()
            os.fsync(f.fileno())

    def store(self, cabinet: str, name: str, body: bytes, sha: str, when: datetime) -> Path:
        """Write one version once. Never replaces a file that is already there."""
        folder = self.raw / cabinet / slug(name)
        folder.mkdir(parents=True, exist_ok=True)
        dest = folder / f"{when.strftime('%Y%m%dT%H%M%SZ')}-{sha[:12]}{Path(name).suffix.lower()}"
        if dest.exists():
            if hashlib.sha256(dest.read_bytes()).hexdigest() == sha:
                return dest
            raise SetupError(f"refusing to replace {dest}: a different file already has that name")
        with open(dest, "xb") as f:
            f.write(body)
            f.flush()
            os.fsync(f.fileno())
        return dest

    def lock(self) -> Path:
        self.root.mkdir(parents=True, exist_ok=True)
        lock = self.root / ".lock"
        try:
            fd = os.open(lock, os.O_CREAT | os.O_EXCL | os.O_WRONLY)
        except FileExistsError:
            raise SetupError(f"another run is going, or a past run stopped early. If no run is going, "
                             f"remove {lock} and try again") from None
        os.write(fd, iso(utc()).encode())
        os.close(fd)
        return lock


# ------------------------------------------------------------------ collecting

def run_pull(cab: Cabinet) -> bool:
    if not cab.pull:
        return True
    try:
        r = subprocess.run(cab.pull, capture_output=True, text=True, timeout=600)
    except (OSError, subprocess.TimeoutExpired) as e:
        warn(f'{cab.name}: the pull command did not run ({e}); this cabinet is skipped today')
        return False
    if r.returncode != 0:
        warn(f'{cab.name}: the pull command failed ({r.stderr.strip()[:200]}); this cabinet is skipped today')
        return False
    return True


def decode(cab: Cabinet, stored: Path) -> list[dict]:
    if not cab.decoder:
        return []
    argv = [a.replace("{file}", str(stored)) for a in cab.decoder]
    try:
        r = subprocess.run(argv, capture_output=True, text=True, timeout=60)
    except (OSError, subprocess.TimeoutExpired) as e:
        warn(f"{cab.name}: the decoder did not run on {stored.name} ({e})")
        return []
    return parse_text_table(r.stdout) if r.returncode == 0 else []


def score_files(cab: Cabinet) -> list[Path]:
    if not cab.path.is_dir():
        warn(f'{cab.name}: folder not found: {cab.path}')
        return []
    found = []
    for p in sorted(cab.path.rglob("*")):
        if p.is_file() and not p.is_symlink() and any(fnmatch.fnmatch(p.name.lower(), pat.lower()) for pat in cab.patterns):
            found.append(p)
    return found


def latest_hashes(events: list[dict]) -> dict[tuple[str, str], str]:
    seen = {}
    for e in events:
        if e.get("kind") == "file":
            seen[(e["cabinet"], e["file"])] = e["sha256"]
    return seen


def collect(s: Settings, now: datetime, dry_run: bool = False) -> list[dict]:
    """Copy every new or changed score file into the archive and record what it says."""
    arc = Archive(s.archive)
    lock = None if dry_run else arc.lock()
    try:
        events = arc.events()
        seen = latest_hashes(events)
        new: list[dict] = []
        for cab in s.cabinets:
            if not dry_run and not run_pull(cab):
                continue
            files = score_files(cab)
            for path in files:
                rel = path.relative_to(cab.path).as_posix()
                try:
                    if path.stat().st_size > MAX_FILE:
                        warn(f"{cab.name}: {rel} is larger than 4 MB and was skipped")
                        continue
                    body = path.read_bytes()
                except OSError as e:
                    warn(f"{cab.name}: can't read {rel} ({e})")
                    continue
                sha = hashlib.sha256(body).hexdigest()
                if not body or seen.get((cab.key, rel)) == sha:
                    continue
                seen[(cab.key, rel)] = sha
                ext = path.suffix.lower()
                game = slug(path.stem if path.name.lower() != "hiscore.dat" else "hiscore.dat")
                if dry_run:
                    print(f"  would archive {cab.name}: {rel}")
                    continue
                stored = arc.store(cab.key, rel, body, sha, now)
                new.append({"kind": "file", "time": iso(now), "cabinet": cab.key, "cabinet_name": cab.name,
                            "file": rel, "game": game, "sha256": sha, "size": len(body),
                            "stored": stored.relative_to(arc.root).as_posix()})
                rows: list[dict] = []
                if ext == ".hi":
                    rows = decode(cab, stored)
                    sidecar = next((x for x in (path.with_suffix(".txt"), path.with_name(path.name + ".txt"))
                                    if x.is_file()), None)
                    if not rows and sidecar is not None:
                        continue        # the .txt next to it is read as its own file
                elif ext == ".txt":
                    rows = parse_text_table(body.decode("utf-8", "replace"))
                elif ext == ".json":
                    try:
                        jgame, rows = parse_json_table(json.loads(body.decode("utf-8")))
                        game = slug(jgame) if jgame else game
                    except (ValueError, UnicodeDecodeError):
                        warn(f"{cab.name}: {rel} is not readable JSON")
                if rows and game != "hiscore.dat":
                    new.append({"kind": "table", "time": iso(now), "cabinet": cab.key, "cabinet_name": cab.name,
                                "game": game, "sha256": sha, "rows": rows})
        new += collect_plays(s, events, now, dry_run)
        if not dry_run:
            arc.append(new)
        return new
    finally:
        if lock is not None:
            lock.unlink()


def collect_plays(s: Settings, events: list[dict], now: datetime, dry_run: bool) -> list[dict]:
    known = {e.get("key") for e in events if e.get("kind") == "play"}
    new = []

    def add(key: str, when: str, player: str, game: str, cabinet: str, source: str, minutes: float = 0) -> None:
        if key in known or not player or not game:
            return
        known.add(key)
        new.append({"kind": "play", "time": when, "player": clean_cell(player), "game": slug(game),
                    "cabinet": clean_cell(cabinet), "source": source, "minutes": round(minutes, 1), "key": key})

    for src in s.plays:
        if src.type == "csv":
            if not src.path.is_file():
                warn(f"plays file not found: {src.path}")
                continue
            with src.path.open(encoding="utf-8", newline="") as f:
                for row in csv.DictReader(f):
                    when, player, game = (row.get("time") or "").strip(), row.get("player") or "", row.get("game") or ""
                    try:
                        when = iso(utc(when))
                    except ValueError:
                        continue
                    key = "csv:" + hashlib.sha256(f"{when}|{player}|{game}".encode()).hexdigest()[:20]
                    add(key, when, player, game, row.get("cabinet") or src.cabinet, "csv")
        elif src.type == "retroarch":
            # RetroArch runtime logs: <logs>/<core>/<game>.lrtl = {"runtime": "H:MM:SS", "last_played": "..."}
            if not src.path.is_dir():
                warn(f"RetroArch log folder not found: {src.path}")
                continue
            for p in sorted(src.path.rglob("*.lrtl")):
                try:
                    d = json.loads(p.read_text(encoding="utf-8"))
                    when = iso(utc(str(d["last_played"]).replace(" ", "T")))
                    h, m, sec = (int(x) for x in str(d.get("runtime", "0:0:0")).split(":"))
                except (OSError, ValueError, KeyError):
                    continue
                key = f"ra:{slug(src.player)}:{slug(p.stem)}:{when}"
                add(key, when, src.player, p.stem, src.cabinet, "retroarch", h * 60 + m + sec / 60)
    if dry_run:
        for e in new:
            print(f"  would add a play: {e['player']} played {e['game']} at {e['time']}")
        return []
    return new


# ------------------------------------------------------------------ owner actions

def add_owner_event(s: Settings, event: dict) -> None:
    arc = Archive(s.archive)
    lock = arc.lock()
    try:
        arc.append([event])
    finally:
        lock.unlink()


# ------------------------------------------------------------------ building the page data

def who(claims: list[dict], initials: str, game: str, cabinet: str) -> str:
    """The approved player name for these initials. The most specific claim wins, then the newest."""
    best, best_rank = "", -1
    for c in claims:
        if c["initials"] != initials.upper():
            continue
        if c.get("game") and c["game"] != game:
            continue
        if c.get("cabinet") and c["cabinet"] != cabinet:
            continue
        rank = (2 if c.get("game") else 0) + (1 if c.get("cabinet") else 0)
        if rank >= best_rank:
            best, best_rank = c["player"], rank
    return best


def build(s: Settings, now: datetime) -> dict:
    events = Archive(s.archive).events()
    claims = [e for e in events if e.get("kind") == "claim"]
    hidden = {(e["game"], e["initials"].upper(), e["score"]) for e in events if e.get("kind") == "hide"}
    title = lambda g: s.titles.get(g) or g.replace("-", " ").replace("_", " ").title()

    # The first table read from each cabinet for each game is the starting point (often factory
    # scores), so its entries are kept and ranked but don't count as someone's new high score.
    first_table: dict[tuple, str] = {}
    for e in events:
        if e.get("kind") == "table":
            first_table.setdefault((e["game"], e["cabinet"]), e["time"])

    def is_new(x: dict) -> bool:
        return x["first_seen"] > first_table.get((x["game"], x["cabinet"]), "")

    # Every entry ever seen: (game, cabinet, initials, score) -> first and last time it was on a table.
    entries: dict[tuple, dict] = {}
    for e in events:
        if e.get("kind") != "table":
            continue
        for r in e["rows"]:
            initials = r.get("name", "").strip()
            if initials.upper() in s.ignore_initials:
                continue
            key = (e["game"], e["cabinet"], initials.upper(), r["score"])
            if (e["game"], initials.upper(), r["score"]) in hidden:
                continue
            item = entries.get(key)
            if item is None:
                entries[key] = {"game": e["game"], "cabinet": e["cabinet"], "cabinet_name": e.get("cabinet_name", e["cabinet"]),
                                "initials": initials, "score": r["score"], "value": score_value(r["score"]),
                                "first_seen": e["time"], "last_seen": e["time"]}
            else:
                item["last_seen"] = max(item["last_seen"], e["time"])

    def public(x: dict) -> dict:
        player = who(claims, x["initials"], x["game"], x["cabinet"])
        return {"game": x["game"], "title": title(x["game"]), "score": x["score"], "initials": x["initials"],
                "player": player, "cabinet": x["cabinet_name"], "spotted": x["first_seen"]}

    by_game: dict[str, list[dict]] = {}
    for x in entries.values():
        by_game.setdefault(x["game"], []).append(x)
    games, longest = {}, []
    for g, rows in by_game.items():
        low = g in s.lower_is_better
        # Best first; ties go to whoever got there first.
        rows.sort(key=lambda x: (x["value"] if low else -x["value"], x["first_seen"]))
        games[g] = {"title": title(g), "lower_is_better": low, "top": [public(x) for x in rows[: s.top]]}
        champ = rows[0]
        days = (now - utc(champ["first_seen"])).days
        longest.append(dict(public(champ), days=max(days, 0)))
    longest.sort(key=lambda x: (-x["days"], x["title"]))

    since = iso(now - timedelta(days=s.recent_days))
    recent = sorted((x for x in entries.values() if x["first_seen"] >= since and
                     is_new(x)), key=lambda x: (x["first_seen"], x["value"]), reverse=True)

    # Most played: plays when there is a plays source, otherwise new scores saved per game.
    plays = [e for e in events if e.get("kind") == "play"]
    played: dict[str, dict] = {}
    if plays:
        basis = "plays"
        for p in plays:
            d = played.setdefault(p["game"], {"plays": 0, "minutes": 0.0})
            d["plays"] += 1
            d["minutes"] += float(p.get("minutes") or 0)
    else:
        basis = "new scores"
        for x in entries.values():
            if is_new(x):
                played.setdefault(x["game"], {"plays": 0, "minutes": 0.0})["plays"] += 1
    most = sorted(({"game": g, "title": title(g), "count": d["plays"], "minutes": round(d["minutes"])}
                   for g, d in played.items()), key=lambda x: (-x["count"], -x["minutes"], x["title"]))

    # Each player's last game: their newest play, or their newest claimed score.
    last: dict[str, dict] = {}
    for p in plays:
        cur = last.get(p["player"])
        if cur is None or p["time"] > cur["time"]:
            last[p["player"]] = {"player": p["player"], "game": p["game"], "title": title(p["game"]),
                                 "time": p["time"], "how": "played"}
    for x in entries.values():
        player = who(claims, x["initials"], x["game"], x["cabinet"])
        if not player or not is_new(x):
            continue
        cur = last.get(player)
        if cur is None or x["first_seen"] > cur["time"]:
            last[player] = {"player": player, "game": x["game"], "title": title(x["game"]),
                            "time": x["first_seen"], "how": "scored"}

    return {
        "version": VERSION, "title": s.title, "generated": iso(now), "recent_days": s.recent_days,
        "recent": [public(x) for x in recent[:20]],
        "most_played": {"basis": basis, "games": most[: s.top]},
        "last_played": sorted(last.values(), key=lambda x: x["time"], reverse=True)[:30],
        "longest_standing": longest[: s.top],
        "games": dict(sorted(games.items(), key=lambda kv: kv[1]["title"])),
        "counts": {"games": len(games), "scores": len(entries), "cabinets": len({x["cabinet"] for x in entries.values()})},
    }


def write_output(s: Settings, data: dict) -> list[Path]:
    """scoreboard.json for anyone, scoreboard.js for the page (works from a plain file, no server code)."""
    s.output.mkdir(parents=True, exist_ok=True)
    text = json.dumps(data, ensure_ascii=True, indent=1, sort_keys=False)
    # Safe inside a <script> file: ensure_ascii already escaped U+2028/2029; stop any "</" closing a tag.
    js = "/* Made by the Scoreboard collector. Rebuilt on every run; edit the settings, not this file. */\n" \
         "window.SCOREBOARD = " + text.replace("</", "<\\/") + ";\n"
    written = []
    for name, body in (("scoreboard.json", text + "\n"), ("scoreboard.js", js)):
        dest = s.output / name
        tmp = dest.with_name(name + ".new")
        tmp.write_text(body, encoding="utf-8")
        os.replace(tmp, dest)       # these two files are page data, rebuilt from the archive each time
        written.append(dest)
    return written


# ------------------------------------------------------------------ command line

def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(prog="scoreboard", description="Keep every arcade high score and build The Scoreboard page data.")
    ap.add_argument("--config", required=True, help="the settings file (.toml or .json)")
    ap.add_argument("--now", help=argparse.SUPPRESS)        # tests and the demo set the clock
    sub = ap.add_subparsers(dest="cmd", required=True)
    sub.add_parser("check", help="read-only: show what would be collected")
    sub.add_parser("collect", help="copy new score files into the archive")
    sub.add_parser("build", help="rebuild the page data from the archive")
    sub.add_parser("run", help="collect, then build (the daily job)")
    c = sub.add_parser("claim", help="approve: these initials belong to this player")
    c.add_argument("--initials", required=True)
    c.add_argument("--player", required=True)
    c.add_argument("--game", default="", help="only for this game (its file name, like cometclash)")
    c.add_argument("--cabinet", default="", help="only on this cabinet")
    h = sub.add_parser("hide", help="hide one score from the board (it stays in the history)")
    h.add_argument("--game", required=True)
    h.add_argument("--initials", required=True)
    h.add_argument("--score", required=True)
    h.add_argument("--reason", default="")
    a = ap.parse_args(argv)
    try:
        s = load_settings(Path(a.config))
        now = utc(a.now) if a.now else utc()
        if a.cmd == "check":
            print(f"{s.title}: archive {s.archive}, page data {s.output}")
            for cab in s.cabinets:
                print(f"- {cab.name}: {cab.path}" + (" (pull first)" if cab.pull else "") + (" (decoder set)" if cab.decoder else ""))
            collect(s, now, dry_run=True)
            return 0
        if a.cmd in ("collect", "run"):
            new = collect(s, now)
            tables = sum(1 for e in new if e["kind"] == "table")
            print(f"collected {sum(1 for e in new if e['kind'] == 'file')} new files, {tables} score tables, "
                  f"{sum(1 for e in new if e['kind'] == 'play')} plays")
        if a.cmd in ("build", "run"):
            for p in write_output(s, build(s, now)):
                print(f"wrote {p}")
        if a.cmd == "claim":
            initials = clean_cell(a.initials).upper()
            player = clean_cell(a.player)
            if not initials or not player:
                raise SetupError("initials and player name can't be empty")
            add_owner_event(s, {"kind": "claim", "time": iso(now), "initials": initials, "player": player,
                                "game": slug(a.game) if a.game else "", "cabinet": slug(a.cabinet) if a.cabinet else ""})
            print(f"{initials} now shows as {player}" + (f" on {a.game}" if a.game else "") + ". Run build to update the page.")
        if a.cmd == "hide":
            add_owner_event(s, {"kind": "hide", "time": iso(now), "game": slug(a.game),
                                "initials": clean_cell(a.initials).upper(), "score": clean_cell(a.score),
                                "reason": clean_cell(a.reason)})
            print("hidden from the board (still kept in the history). Run build to update the page.")
        return 0
    except SetupError as e:
        print("scoreboard: " + str(e), file=sys.stderr)
        return 2


if __name__ == "__main__":
    sys.exit(main())
