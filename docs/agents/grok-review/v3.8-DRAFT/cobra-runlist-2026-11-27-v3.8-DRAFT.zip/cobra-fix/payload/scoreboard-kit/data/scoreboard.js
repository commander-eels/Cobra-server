/* Made by the Scoreboard collector. Rebuilt on every run; edit the settings, not this file. */
window.SCOREBOARD = {
 "version": "0.1",
 "title": "The Scoreboard",
 "generated": "2026-11-20T06:00:00Z",
 "recent_days": 21,
 "recent": [
  {
   "game": "rocketrally",
   "title": "Rocket Rally",
   "score": "53050",
   "initials": "ACE",
   "player": "Ace Pilot",
   "cabinet": "Garage cabinet",
   "spotted": "2026-11-19T06:00:00Z"
  },
  {
   "game": "cometclash",
   "title": "Comet Clash",
   "score": "90120",
   "initials": "ZED",
   "player": "Zed",
   "cabinet": "Den cabinet",
   "spotted": "2026-11-17T06:00:00Z"
  },
  {
   "game": "neondrift",
   "title": "Neon Drift",
   "score": "1'55\"10",
   "initials": "MAX",
   "player": "Max Power",
   "cabinet": "Garage cabinet",
   "spotted": "2026-11-15T06:00:00Z"
  },
  {
   "game": "gemquarry",
   "title": "Gem Quarry",
   "score": "24410",
   "initials": "JOY",
   "player": "Joy Stick",
   "cabinet": "Den cabinet",
   "spotted": "2026-11-13T06:00:00Z"
  },
  {
   "game": "rocketrally",
   "title": "Rocket Rally",
   "score": "51800",
   "initials": "RIO",
   "player": "Rio",
   "cabinet": "Garage cabinet",
   "spotted": "2026-10-30T06:00:00Z"
  }
 ],
 "most_played": {
  "basis": "plays",
  "games": [
   {
    "game": "cometclash",
    "title": "Comet Clash",
    "count": 35,
    "minutes": 0
   },
   {
    "game": "gemquarry",
    "title": "Gem Quarry",
    "count": 6,
    "minutes": 0
   },
   {
    "game": "rocketrally",
    "title": "Rocket Rally",
    "count": 6,
    "minutes": 0
   },
   {
    "game": "laserlanes",
    "title": "Laser Lanes",
    "count": 4,
    "minutes": 0
   },
   {
    "game": "neondrift",
    "title": "Neon Drift",
    "count": 4,
    "minutes": 0
   },
   {
    "game": "pixelpirates",
    "title": "Pixel Pirates",
    "count": 1,
    "minutes": 0
   }
  ]
 },
 "last_played": [
  {
   "player": "Ace Pilot",
   "game": "rocketrally",
   "title": "Rocket Rally",
   "time": "2026-11-19T06:00:00Z",
   "how": "scored"
  },
  {
   "player": "Zed",
   "game": "cometclash",
   "title": "Comet Clash",
   "time": "2026-11-17T06:00:00Z",
   "how": "scored"
  },
  {
   "player": "Joy Stick",
   "game": "cometclash",
   "title": "Comet Clash",
   "time": "2026-11-17T01:00:00Z",
   "how": "played"
  },
  {
   "player": "Max Power",
   "game": "neondrift",
   "title": "Neon Drift",
   "time": "2026-11-15T06:00:00Z",
   "how": "scored"
  },
  {
   "player": "Rio",
   "game": "rocketrally",
   "title": "Rocket Rally",
   "time": "2026-10-30T06:00:00Z",
   "how": "scored"
  }
 ],
 "longest_standing": [
  {
   "game": "laserlanes",
   "title": "Laser Lanes",
   "score": "412300",
   "initials": "ACE",
   "player": "Ace Pilot",
   "cabinet": "Den cabinet",
   "spotted": "2026-08-04T06:00:00Z",
   "days": 108
  },
  {
   "game": "pixelpirates",
   "title": "Pixel Pirates",
   "score": "131000",
   "initials": "JOY",
   "player": "Joy Stick",
   "cabinet": "Den cabinet",
   "spotted": "2026-08-16T06:00:00Z",
   "days": 96
  },
  {
   "game": "gemquarry",
   "title": "Gem Quarry",
   "score": "24410",
   "initials": "JOY",
   "player": "Joy Stick",
   "cabinet": "Den cabinet",
   "spotted": "2026-11-13T06:00:00Z",
   "days": 7
  },
  {
   "game": "neondrift",
   "title": "Neon Drift",
   "score": "1'55\"10",
   "initials": "MAX",
   "player": "Max Power",
   "cabinet": "Garage cabinet",
   "spotted": "2026-11-15T06:00:00Z",
   "days": 5
  },
  {
   "game": "cometclash",
   "title": "Comet Clash",
   "score": "90120",
   "initials": "ZED",
   "player": "Zed",
   "cabinet": "Den cabinet",
   "spotted": "2026-11-17T06:00:00Z",
   "days": 3
  },
  {
   "game": "rocketrally",
   "title": "Rocket Rally",
   "score": "53050",
   "initials": "ACE",
   "player": "Ace Pilot",
   "cabinet": "Garage cabinet",
   "spotted": "2026-11-19T06:00:00Z",
   "days": 1
  }
 ],
 "games": {
  "cometclash": {
   "title": "Comet Clash",
   "lower_is_better": false,
   "top": [
    {
     "game": "cometclash",
     "title": "Comet Clash",
     "score": "90120",
     "initials": "ZED",
     "player": "Zed",
     "cabinet": "Den cabinet",
     "spotted": "2026-11-17T06:00:00Z"
    },
    {
     "game": "cometclash",
     "title": "Comet Clash",
     "score": "88450",
     "initials": "ACE",
     "player": "Ace Pilot",
     "cabinet": "Den cabinet",
     "spotted": "2026-08-07T06:00:00Z"
    },
    {
     "game": "cometclash",
     "title": "Comet Clash",
     "score": "74300",
     "initials": "JOY",
     "player": "Joy Stick",
     "cabinet": "Den cabinet",
     "spotted": "2026-09-28T06:00:00Z"
    },
    {
     "game": "cometclash",
     "title": "Comet Clash",
     "score": "61200",
     "initials": "RIO",
     "player": "Rio",
     "cabinet": "Garage cabinet",
     "spotted": "2026-09-14T06:00:00Z"
    }
   ]
  },
  "gemquarry": {
   "title": "Gem Quarry",
   "lower_is_better": false,
   "top": [
    {
     "game": "gemquarry",
     "title": "Gem Quarry",
     "score": "24410",
     "initials": "JOY",
     "player": "Joy Stick",
     "cabinet": "Den cabinet",
     "spotted": "2026-11-13T06:00:00Z"
    },
    {
     "game": "gemquarry",
     "title": "Gem Quarry",
     "score": "22040",
     "initials": "ZED",
     "player": "Zed",
     "cabinet": "Den cabinet",
     "spotted": "2026-08-31T06:00:00Z"
    }
   ]
  },
  "laserlanes": {
   "title": "Laser Lanes",
   "lower_is_better": false,
   "top": [
    {
     "game": "laserlanes",
     "title": "Laser Lanes",
     "score": "412300",
     "initials": "ACE",
     "player": "Ace Pilot",
     "cabinet": "Den cabinet",
     "spotted": "2026-08-04T06:00:00Z"
    },
    {
     "game": "laserlanes",
     "title": "Laser Lanes",
     "score": "398000",
     "initials": "ZED",
     "player": "Zed",
     "cabinet": "Den cabinet",
     "spotted": "2026-10-15T06:00:00Z"
    }
   ]
  },
  "neondrift": {
   "title": "Neon Drift",
   "lower_is_better": true,
   "top": [
    {
     "game": "neondrift",
     "title": "Neon Drift",
     "score": "1'55\"10",
     "initials": "MAX",
     "player": "Max Power",
     "cabinet": "Garage cabinet",
     "spotted": "2026-11-15T06:00:00Z"
    },
    {
     "game": "neondrift",
     "title": "Neon Drift",
     "score": "1'58\"42",
     "initials": "RIO",
     "player": "Rio",
     "cabinet": "Garage cabinet",
     "spotted": "2026-08-10T06:00:00Z"
    }
   ]
  },
  "pixelpirates": {
   "title": "Pixel Pirates",
   "lower_is_better": false,
   "top": [
    {
     "game": "pixelpirates",
     "title": "Pixel Pirates",
     "score": "131000",
     "initials": "JOY",
     "player": "Joy Stick",
     "cabinet": "Den cabinet",
     "spotted": "2026-08-16T06:00:00Z"
    }
   ]
  },
  "rocketrally": {
   "title": "Rocket Rally",
   "lower_is_better": false,
   "top": [
    {
     "game": "rocketrally",
     "title": "Rocket Rally",
     "score": "53050",
     "initials": "ACE",
     "player": "Ace Pilot",
     "cabinet": "Garage cabinet",
     "spotted": "2026-11-19T06:00:00Z"
    },
    {
     "game": "rocketrally",
     "title": "Rocket Rally",
     "score": "51800",
     "initials": "RIO",
     "player": "Rio",
     "cabinet": "Garage cabinet",
     "spotted": "2026-10-30T06:00:00Z"
    },
    {
     "game": "rocketrally",
     "title": "Rocket Rally",
     "score": "45200",
     "initials": "MAX",
     "player": "Max Power",
     "cabinet": "Garage cabinet",
     "spotted": "2026-08-22T06:00:00Z"
    }
   ]
  }
 },
 "counts": {
  "games": 6,
  "scores": 14,
  "cabinets": 2
 }
};
