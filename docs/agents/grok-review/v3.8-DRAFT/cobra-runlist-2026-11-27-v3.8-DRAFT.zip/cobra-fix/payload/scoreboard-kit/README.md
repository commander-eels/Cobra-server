# The Scoreboard kit

A big arcade-style high score board for a home or club arcade, plus the daily job that feeds it. Every high score from every cabinet is kept forever, even after a cabinet is reset to its factory scores.

Plain HTML, CSS and a small script for the page. One Python file, standard library only, for the collector. Two accessible forms (claim a score, report a wrong score) that post to the Formidable form engine. No framework, no database, no tracking.

## What the board shows

- **Hot off the cabinets:** the newest high score in a big card, then the other recent ones.
- **Most played:** games by how often they were started (or by new high scores, until you set up a plays log).
- **Last played:** each player's newest game.
- **Longest standing:** each game's champion, and how many days nobody has beaten it.
- **Every game:** the best scores ever seen for each game, in a table.

## What's in the box

| File | What it is |
|---|---|
| `forms/index.html` | The board page |
| `forms/claim-score.html` | "Claim a high score": initials on the screen, the score, a player name, an optional photo |
| `forms/report-score.html` | "Report a wrong score": wrong name, fake or glitched score, missing score |
| `forms/thanks.html` | The page people land on after sending a form |
| `assets/kit.css` | The arcade look: contrast, focus, reflow, high contrast, print, reduced motion |
| `assets/kit.js` | Kinder form checks (the same file as the Civic Essentials kit) |
| `assets/board.js` | Draws the board from the data file |
| `data/scoreboard.js`, `data/scoreboard.json` | Demo data from a made-up arcade. The collector replaces them with yours |
| `art/` | Art slots: drop in PNGs with the listed names. See [art/README.md](art/README.md) |
| `collector/scoreboard.py` | The daily collector |
| `collector/examples/` | Settings files, sample score files, a plays log, and a systemd timer |
| `formidable/*.json` | The two forms for the Formidable engine |

The board page sits in `forms/` next to the forms so one set of checks covers every page. Serve the whole kit folder (for example at `/scoreboard/`); people open `/scoreboard/forms/`, or point your web server's index at `forms/index.html`.

## Look at it first

Open `forms/index.html` in a browser. It shows the demo arcade, and the forms work in *demo mode*: Send shows a message and nothing leaves the page.

## How the collector keeps every score

Each day the collector reads each cabinet's high score folder. Any file that changed since yesterday is copied into the archive under a new name (it never replaces an older copy), and the scores in it are written to `ledger.jsonl`, a list that only ever grows. The board is worked out again from that list on every run. A reset cabinet only adds one more table; the old scores are still in the older ones.

It reads:

- **`*.hi`**: what MAME's hiscore plugin saves. These are raw memory, so they need a decoder such as hi2txt to become a score table, or a `<game>.txt` next to them that a cabinet already decoded. Without either, they are still archived, so they can be decoded later.
- **`*.txt`**: a decoded table (`RANK|SCORE|NAME` lines, as hi2txt prints). See `collector/examples/comet.txt`.
- **`*.json`**: a table from any other source. See `collector/examples/drift.json`.
- **`hiscore.dat`**: the plugin's list of where each game keeps its scores. It holds no scores; it is archived so you can always decode old `.hi` files the same way.

The first table seen from a cabinet for a game is treated as its starting point (usually the factory scores): those entries are ranked, but don't count as someone's "new" high score. To hide factory initials completely, list them in `ignore_initials`.

## Set it up (about 30 minutes)

You need Python 3.11 or newer on the machine that runs the collector (3.9 works with a `.json` settings file), read access to each cabinet's high score folder, and a web server for the page.

**1. Copy the collector and an example settings file** to the machine that will run it, for example into `~/scoreboard/`. Then make your own settings file from the example.

```bash
cp collector/examples/scoreboard.example.toml ~/scoreboard/scoreboard.toml
```

**2. Edit `scoreboard.toml`.** Set `archive` (where the history is kept; back this folder up), `output` (the `data/` folder of the board you serve), and one `[[cabinets]]` block per cabinet. Every setting is explained in the file.

**3. Do a read-only check.** It lists every file it would collect and writes nothing.

```bash
python3 ~/scoreboard/scoreboard.py --config ~/scoreboard/scoreboard.toml check
```

**4. Do the first real run.** It copies the score files into the archive and writes `scoreboard.js` and `scoreboard.json` into your board's `data/` folder.

```bash
python3 ~/scoreboard/scoreboard.py --config ~/scoreboard/scoreboard.toml run
```

**5. Run it every day.** On Linux with systemd: copy `collector/examples/scoreboard.service` and `scoreboard.timer` to `~/.config/systemd/user/`, fix the paths in the service, then turn on the timer.

```bash
systemctl --user enable --now scoreboard.timer
```

So the timer also runs while you're logged out, let your user keep services running:

```bash
loginctl enable-linger "$USER"
```

Or with cron, add this line with `crontab -e` (runs at 05:00 every day):

```text
0 5 * * * /usr/bin/python3 /home/you/scoreboard/scoreboard.py --config /home/you/scoreboard/scoreboard.toml run
```

On Windows, Task Scheduler can run `py C:\scoreboard\scoreboard.py --config C:\scoreboard\scoreboard.toml run` daily.

**6. Serve the page.** Put the kit folder on your web server, with `output` pointing at its `data/` folder. Replace `Example Arcade` in each page's `<title>` and every `<!-- CUSTOMIZE -->` comment.

## Player names (the claim form)

Cabinets save three letters. When someone sends "Claim a high score", the Formidable engine checks the answers, strips location data from the photo, and emails the claim to you. Nothing goes on the board until you approve it. If it checks out, add it, then rebuild the page:

```bash
python3 ~/scoreboard/scoreboard.py --config ~/scoreboard/scoreboard.toml claim --initials ACE --player "Ace Pilot" --game comet
```

```bash
python3 ~/scoreboard/scoreboard.py --config ~/scoreboard/scoreboard.toml build
```

Leave out `--game` to use the name for those initials on every game, or add `--cabinet "Cabinet 1"` for one cabinet. The most specific claim wins; a newer one replaces an older one on the board (both stay in the ledger).

## Fixing a wrong score (the report form)

A glitched or fake score is hidden from the board, never deleted. It stays in the ledger with your reason:

```bash
python3 ~/scoreboard/scoreboard.py --config ~/scoreboard/scoreboard.toml hide --game comet --initials BUG --score 999999 --reason "memory glitch"
```

Then run `build` again.

## Plays ("Most played" and "Last played")

The cabinets don't record who played what, so these two columns need a plays source. Without one, "Most played" counts new high scores per game and "Last played" uses approved claims. Two kinds are built in (see the example settings):

- **`csv`**: a file with the columns `time,player,game` (and optionally `cabinet`), one line per game started. Any launcher, script or front end that can append a line can feed it. See `collector/examples/plays.csv`.
- **`retroarch`**: a player's RetroArch runtime logs (Settings, Saving, "Save runtime log"). Each new "last played" time counts as one play and adds the play time.

## Using the Formidable engine

The `formidable/` folder has one form file per form. Field names, choices and required questions match the HTML exactly, and the kit's tests check that they stay matched. Put your site address in `origins` and your thank-you page in `next`, load them into the engine, point each form's `action` at your engine, and remove `data-kit-demo` from each `<form>`. The engine accepts only the declared fields, re-checks every answer, rebuilds the photo with no metadata, and keeps nothing after delivery.

Any other back end that accepts a normal form post works too. Throw away anything you didn't ask for, and reject any post where the hidden `_honey` field isn't empty.

## Privacy

The board shows only what a cabinet saved (initials and scores) and player names you approved. The collector reads nothing about visitors, and the page sets no cookies and loads nothing from other sites. The claim form's email address is optional, goes only to you, and is never on the board.

## Checks

From the repository folder. Static checks for every kit and the collector's tests:

```bash
PYTHONPATH=engine python3 -m unittest discover -s kits/tools
```

Rebuild the demo data with the real collector (plays out three months of a made-up arcade, including a cabinet reset):

```bash
python3 kits/tools/build_scoreboard_demo.py
```

Real-browser checks (axe-core, keyboard, 320px reflow, error flow) are in `kits/tools/browser_check.mjs`; see `kits/README.md`.

## Support and licence

<!-- SELLER TO FILL IN: licence summary, support email, version. -->
Version 0.1 (pre-release). The demo games and players are made up.
