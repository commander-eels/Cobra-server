/* The Scoreboard kit: form behaviour (the same file as the Civic Essentials kit).
 *
 * Add to a page:   <script src="../assets/kit.js" defer></script>
 * and mark the form: <form class="kit-form" data-kit ...>
 *
 * The forms work with no JavaScript at all (the browser's own checks run and the form posts as
 * usual). This file makes them kinder:
 *   - checks an answer when you leave the field, never while you type
 *   - an error list at the top of the form when you press Send, with links that jump to each problem
 *   - each error is written next to its question and linked to it for screen readers
 *   - sections that open only when an earlier answer needs them (data-kit-show-if)
 *   - a characters-left count on long answers, announced calmly, not on every key
 *   - one press of Send, not two
 *
 * It collects nothing about the visitor: no cookies, no storage, no tracking, no third parties.
 *
 * Options, all written in the HTML:
 *   data-kit-demo                    on <form>: show a "sent" message without sending (for previews)
 *   data-kit-show-if="Name=A|B"      on a wrapper: shown only when field "Name" has value A or B
 *   data-kit-required-if="Name=A|B"  on an input: required only when field "Name" has value A or B
 *   data-kit-label="your email"      on an input or fieldset: the words used in its error messages
 *   data-kit-required-msg="..."      on an input or fieldset: replace the "missing answer" message
 *   data-kit-after="other-id"        on a date input: must be the same day as, or after, that date
 *   data-kit-max-mb="6"              on a file input: largest file allowed
 *   data-kit-min="1"                 on a fieldset of tick boxes: tick at least this many
 *
 * Works alongside Formidable Flow's ff.js: if the form also has data-ff, this file checks the
 * answers first and then lets ff.js do the sending.
 */
(function () {
  "use strict";

  var EMAIL = /^[^\s@]+@[^\s@.]+(\.[^\s@.]+)+$/;
  var TEL = /^\+?[0-9 ().\-]{7,25}$/;          // the same rule as the Formidable engine
  var COUNT_PAUSE_MS = 1000;                    // announce the count once typing stops for this long

  function $all(sel, root) { return Array.prototype.slice.call((root || document).querySelectorAll(sel)); }

  function words(node) {
    // Visible label text without the "(required)" tag or the hint, for use in messages.
    if (!node) return "this question";
    var copy = node.cloneNode(true);
    $all(".kit-req, .kit-hint, .kit-error, .kit-sr", copy).forEach(function (n) { n.remove(); });
    return copy.textContent.replace(/\s+/g, " ").trim().replace(/[:?]$/, "") || "this question";
  }

  function addId(el, attr, id) {
    var ids = (el.getAttribute(attr) || "").split(/\s+/).filter(Boolean);
    if (ids.indexOf(id) < 0) ids.push(id);
    el.setAttribute(attr, ids.join(" "));
  }

  function removeId(el, attr, id) {
    var ids = (el.getAttribute(attr) || "").split(/\s+/).filter(function (x) { return x && x !== id; });
    if (ids.length) el.setAttribute(attr, ids.join(" ")); else el.removeAttribute(attr);
  }

  var formCount = 0;

  function Kit(form) {
    this.form = form;
    this.n = ++formCount;
    this.flagged = {};        // questions that have shown an error; re-checked as soon as they change
    this.sending = false;
    this.title = document.title;
    form.setAttribute("novalidate", "");   // our messages replace the browser's pop-ups
    this.questions = this.collect();
    this.buildSummary();
    this.setupReveals();
    this.setupCounters();
    this.bind();
  }

  /* A "question" is one thing the person answers: a single box, or a group of radios or tick boxes. */
  Kit.prototype.collect = function () {
    var list = [], seen = {};
    $all("input, select, textarea", this.form).forEach(function (input) {
      if (!input.name || input.name.charAt(0) === "_" || input.type === "hidden" ||
          input.type === "submit" || input.closest(".kit-trap")) return;
      var group = (input.type === "radio" || input.type === "checkbox") ? input.closest("fieldset") : null;
      if (input.type === "checkbox" && group && $all("input[type=checkbox]", group).length === 1) group = null;
      var key = group ? "g:" + input.name : "i:" + (input.id || input.name);
      if (seen[key]) return;
      seen[key] = true;
      var holder = group || input.closest(".kit-field") || input.parentElement;
      var labelEl = group ? group.querySelector("legend") :
        (input.id && document.querySelector('label[for="' + input.id + '"]')) || input.closest("label");
      list.push({
        key: key,
        input: input,
        group: group,
        inputs: group ? $all('input[name="' + input.name + '"]', group) : [input],
        holder: holder,
        describe: group || input,          // where aria-describedby and aria-invalid go
        label: (group || input).getAttribute("data-kit-label") || words(labelEl),
        error: null
      });
    });
    return list;
  };

  Kit.prototype.buildSummary = function () {
    var s = document.createElement("div");
    s.className = "kit-summary";
    s.id = "kit-summary-" + this.n;
    s.setAttribute("tabindex", "-1");
    s.setAttribute("role", "group");
    s.setAttribute("aria-labelledby", s.id + "-h");
    s.hidden = true;
    s.innerHTML = '<h2 id="' + s.id + '-h"></h2><ul></ul>';
    this.form.insertBefore(s, this.form.firstChild);
    this.summary = s;
  };

  /* ---------- sections that open when needed ---------- */

  Kit.prototype.setupReveals = function () {
    var self = this;
    this.reveals = $all("[data-kit-show-if]", this.form).map(function (box) {
      var rule = box.getAttribute("data-kit-show-if"), cut = rule.indexOf("=");
      return { box: box, name: rule.slice(0, cut), values: rule.slice(cut + 1).split("|") };
    });
    this.applyReveals(true);
    this.form.addEventListener("change", function () { self.applyReveals(false); });
  };

  Kit.prototype.valuesOf = function (name) {
    return $all("input, select, textarea", this.form).filter(function (i) {
      return i.name === name && !i.disabled &&
        (i.type === "radio" || i.type === "checkbox" ? i.checked : true);
    }).map(function (i) { return i.value; });
  };

  Kit.prototype.applyReveals = function (first) {
    var self = this;
    // data-kit-required-if="Name=A|B": this box is required only while that answer is chosen.
    $all("[data-kit-required-if]", this.form).forEach(function (i) {
      var rule = i.getAttribute("data-kit-required-if"), cut = rule.indexOf("=");
      var have = self.valuesOf(rule.slice(0, cut));
      i.required = rule.slice(cut + 1).split("|").some(function (v) { return have.indexOf(v) >= 0; });
      if (!i.required && !first) self.questions.forEach(function (q) { if (q.input === i && !self.problem(q)) self.clear(q); });
    });
    this.reveals.forEach(function (r) {
      var have = self.valuesOf(r.name);
      var show = r.values.some(function (v) { return have.indexOf(v) >= 0; });
      if (show === !r.box.hidden) return;
      r.box.hidden = !show;
      if (show && !first) r.box.classList.add("kit-reveal");
      $all("input, select, textarea", r.box).forEach(function (i) {
        // A hidden section is switched off: it isn't checked and isn't sent.
        if (show) {
          i.disabled = false;
          if (i.hasAttribute("data-kit-was-required")) { i.required = true; i.removeAttribute("data-kit-was-required"); }
        } else {
          if (i.required) { i.setAttribute("data-kit-was-required", ""); i.required = false; }
          i.disabled = true;
        }
      });
      if (!show) {
        self.questions.forEach(function (q) { if (r.box.contains(q.input)) self.clear(q); });
      }
    });
  };

  /* ---------- characters-left counts ---------- */

  Kit.prototype.setupCounters = function () {
    $all("textarea[maxlength]", this.form).forEach(function (ta) {
      var max = parseInt(ta.getAttribute("maxlength"), 10);
      if (!max) return;
      var shown = document.createElement("span");
      shown.className = "kit-count";
      shown.setAttribute("aria-hidden", "true");          // sighted readers see this one
      var spoken = document.createElement("span");
      spoken.className = "kit-sr";
      spoken.setAttribute("aria-live", "polite");         // screen readers hear this one, after a pause
      var limit = document.createElement("span");
      limit.className = "kit-sr";
      limit.id = (ta.id || ta.name) + "-limit";
      limit.textContent = "You can use up to " + max + " characters.";
      ta.insertAdjacentElement("afterend", shown);
      shown.insertAdjacentElement("afterend", spoken);
      spoken.insertAdjacentElement("afterend", limit);
      addId(ta, "aria-describedby", limit.id);
      var timer = null;
      function text() {
        var left = max - ta.value.length;
        return left >= 0 ? left + (left === 1 ? " character" : " characters") + " left"
                         : (-left) + " too many characters";
      }
      function update() {
        shown.textContent = text();
        shown.classList.toggle("kit-count--over", ta.value.length > max);
        clearTimeout(timer);
        timer = setTimeout(function () { spoken.textContent = text(); }, COUNT_PAUSE_MS);
      }
      ta.addEventListener("input", update);
      shown.textContent = text();
    });
  };

  /* ---------- checking ---------- */

  Kit.prototype.problem = function (q) {
    var input = q.input;
    if (input.disabled) return "";
    var custom = q.describe.getAttribute("data-kit-required-msg");
    if (q.group) {
      var ticked = q.inputs.filter(function (i) { return i.checked; }).length;
      var need = parseInt(q.group.getAttribute("data-kit-min") || (q.inputs.some(function (i) { return i.required; }) ? "1" : "0"), 10);
      if (ticked < need) {
        return custom || (input.type === "radio" ? "Choose an answer for " : "Tick at least one answer for ") + q.label.toLowerCase() + ".";
      }
      return "";
    }
    if (input.type === "checkbox") {
      return input.required && !input.checked ? (custom || "Tick the box to say: " + q.label + ".") : "";
    }
    var v = input.type === "file" ? "" : input.value.trim();
    if (input.type === "file") {
      var f = input.files && input.files[0];
      if (!f) return input.required ? (custom || "Choose a file for " + q.label.toLowerCase() + ".") : "";
      var maxMb = parseFloat(input.getAttribute("data-kit-max-mb") || "0");
      if (maxMb && f.size > maxMb * 1024 * 1024) return "That file is too big. Choose one smaller than " + maxMb + " MB.";
      var accept = (input.getAttribute("accept") || "").split(",").map(function (s) { return s.trim(); }).filter(Boolean);
      if (accept.length && accept.indexOf(f.type) < 0) return "That kind of file can't be sent. Choose a photo (JPG, PNG or WEBP) or a PDF.";
      return "";
    }
    if (!v) {
      if (!input.required) return "";
      if (custom) return custom;
      return (input.tagName === "SELECT" ? "Choose " : "Enter ") + q.label.toLowerCase() + ".";
    }
    if (input.type === "email" && !EMAIL.test(v)) return "Enter an email address like name@example.com.";
    if (input.type === "tel" && !TEL.test(v)) return "Enter a phone number using digits, like 555 123 4567.";
    var max = parseInt(input.getAttribute("maxlength") || "0", 10);
    if (max && input.value.length > max) return "Shorten this to " + max + " characters or fewer.";
    if (input.type === "date") {
      if (!/^\d{4}-\d{2}-\d{2}$/.test(v)) return "Enter a real date.";
      if (input.min && v < input.min) return "Enter a date on or after " + input.min + ".";
      if (input.max && v > input.max) return "Enter a date on or before " + input.max + ".";
      var afterId = input.getAttribute("data-kit-after"), other = afterId && document.getElementById(afterId);
      if (other && other.value && v < other.value) return "This date must be the same as or after the first date.";
    }
    return "";
  };

  Kit.prototype.show = function (q, message) {
    if (!q.error) {
      q.error = document.createElement("p");
      q.error.className = "kit-error";
      q.error.id = "kit-err-" + this.n + "-" + this.questions.indexOf(q);
      // GOV.UK-style placement: after the label and hint, just before the answer box.
      var anchor = q.group ? (q.group.querySelector(".kit-hint") || q.group.querySelector("legend")) :
        (q.holder.querySelector(".kit-hint") || q.holder.querySelector("label"));
      if (anchor && anchor.parentNode === q.holder) anchor.insertAdjacentElement("afterend", q.error);
      else if (q.group) q.group.querySelector("legend").insertAdjacentElement("afterend", q.error);
      else q.input.insertAdjacentElement("beforebegin", q.error);
    }
    q.error.textContent = message;
    q.error.hidden = false;
    addId(q.describe, "aria-describedby", q.error.id);
    q.inputs.forEach(function (i) { i.setAttribute("aria-invalid", "true"); });
    if (q.group) q.group.setAttribute("aria-invalid", "true");
    q.holder.classList.add("kit-field--invalid");
    this.flagged[q.key] = true;
  };

  Kit.prototype.clear = function (q) {
    if (q.error) { q.error.hidden = true; q.error.textContent = ""; removeId(q.describe, "aria-describedby", q.error.id); }
    q.inputs.forEach(function (i) { i.removeAttribute("aria-invalid"); });
    if (q.group) q.group.removeAttribute("aria-invalid");
    q.holder.classList.remove("kit-field--invalid");
  };

  Kit.prototype.check = function (q) {
    var p = this.problem(q);
    if (p) this.show(q, p); else this.clear(q);
    return p;
  };

  Kit.prototype.bind = function () {
    var self = this;
    this.questions.forEach(function (q) {
      q.inputs.forEach(function (input) {
        // Leaving a box: check it, but only if something was typed or it already showed an error.
        // Tabbing through empty boxes never produces a wall of red.
        input.addEventListener("blur", function () {
          if (q.group && q.group.contains(document.activeElement)) return;
          if (self.flagged[q.key] || (input.value && input.type !== "radio" && input.type !== "checkbox")) self.check(q);
        });
        input.addEventListener("change", function () { if (self.flagged[q.key]) self.check(q); });
        input.addEventListener("input", function () {
          if (self.flagged[q.key] && !self.problem(q)) self.clear(q);    // the moment it's fixed, the red goes
        });
      });
    });

    // Capture phase, so this runs before any other submit handler (such as ff.js).
    this.form.addEventListener("submit", function (ev) {
      if (self.sending) { ev.preventDefault(); ev.stopImmediatePropagation(); return; }
      var problems = [];
      self.questions.forEach(function (q) { var p = self.check(q); if (p) problems.push([q, p]); });
      if (problems.length) {
        ev.preventDefault();
        ev.stopImmediatePropagation();
        self.report(problems);
        return;
      }
      self.hideSummary();
      if (self.form.hasAttribute("data-kit-demo")) { ev.preventDefault(); return self.demoSent(); }
      if (self.form.hasAttribute("data-ff")) return;     // ff.js sends it from here
      self.sending = true;                                // a normal post: block the second press
      var btn = self.form.querySelector("[type=submit]");
      if (btn) { btn.setAttribute("aria-disabled", "true"); btn.textContent = "Sending…"; }
    }, true);
  };

  Kit.prototype.report = function (problems) {
    var self = this, s = this.summary;
    var n = problems.length;
    s.querySelector("h2").textContent = n === 1 ? "There is 1 problem to fix" : "There are " + n + " problems to fix";
    var ul = s.querySelector("ul");
    ul.textContent = "";
    problems.forEach(function (pair) {
      var q = pair[0], li = document.createElement("li"), a = document.createElement("a");
      var target = q.group ? (q.inputs.filter(function (i) { return i.checked; })[0] || q.inputs[0]) : q.input;
      if (!target.id) target.id = "kit-q-" + self.n + "-" + self.questions.indexOf(q);
      a.href = "#" + target.id;
      a.textContent = pair[1];
      a.addEventListener("click", function (ev) {
        ev.preventDefault();
        target.focus();
        // Bring the question's label into view too, not just the box.
        (q.group || q.holder).scrollIntoView({ block: "start" });
      });
      li.appendChild(a);
      ul.appendChild(li);
    });
    s.hidden = false;
    document.title = "Error: " + this.title;     // screen readers read the title first on some setups
    s.focus();
  };

  Kit.prototype.hideSummary = function () {
    this.summary.hidden = true;
    document.title = this.title;
  };

  Kit.prototype.demoSent = function () {
    var status = this.form.querySelector(".kit-status");
    if (!status) {
      status = document.createElement("div");
      status.className = "kit-status";
      status.setAttribute("tabindex", "-1");
      this.form.appendChild(status);
    }
    status.className = "kit-status kit-status--ok";
    status.innerHTML = "<p><strong>Demo only: nothing was sent.</strong> In a real setup this form would post to your " +
      "server and show your thank-you page.</p>";
    status.focus();
  };

  function start() {
    $all("form[data-kit]").forEach(function (form) { new Kit(form); });
  }
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", start);
  else start();
})();
