#!/usr/bin/env bash
# Audiobookshelf for the Audiobooks Bay (and The Ward's Sessions podcasts). http://10.6.9.20:13378
# Public: audio.songofeo.com and sessions.songofeo.com.
# WALLED (2026-11-21, the owner's rule: every instance of the same app is walled). It mounts ONLY its own folders,
# read-only, at the same /media paths its libraries already use, so nothing needs re-pointing. Talk Radio & Comedy
# Club and The Archives are separate Audiobookshelf servers (audiobookshelf-talk.sh :13379, audiobookshelf-archives.sh
# :13380) with their own pods, data and users. Books stays mounted only until Kavita's Books library takes over.
# Run as podsvc on the SGIN:  ./audiobookshelf.sh
here=$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)
# shellcheck source=../lib.sh
. "$here/../lib.sh"
# shellcheck source=pod.sh
. "$here/pod.sh"

IMAGE=${ABS_IMAGE:-ghcr.io/advplyr/audiobookshelf:latest}
DATA=$STREAM_DATA/abs

preflight
need_folders "$AUDIOBOOKS_DIR" "$SESSIONS_DIR"
ABS_MOUNTS=("$AUDIOBOOKS_DIR" "$SESSIONS_DIR")
[ -d "$DISKS/$BOOKS_DIR" ] && [ "${ABS_KEEP_BOOKS:-1}" = 1 ] && ABS_MOUNTS+=("$BOOKS_DIR")   # until Kavita Books is live
mounts=(); for m in "${ABS_MOUNTS[@]}"; do mounts+=(-v "$DISKS/$m:/media/$m:ro"); done
[ "${ABS_ALL_DISKS:-0}" = 1 ] && mounts=(-v "$DISKS:/media:ro,rbind")   # the old, unwalled way: only to undo
stream_pod
ensure_dir "$DATA/config" "$DATA/metadata"
keep_personal_state audiobookshelf

# PORT=13378: inside a pod every app shares one network, so ABS can't keep its default port 80.
run_container audiobookshelf "$STREAM_POD" "$IMAGE" \
  -e PORT=13378 \
  -v "$DATA/config:/config:Z" \
  -v "$DATA/metadata:/metadata:Z" \
  "${mounts[@]}"

wait_port 13378 60 || warn "Audiobookshelf isn't answering on :13378 yet; check podman logs audiobookshelf"
snapshot_personal_state audiobookshelf
done_msg audiobookshelf http://10.6.9.20:13378
echo "    Once: first visit creates the admin, then Libraries -> 'Audiobooks' (/media/$AUDIOBOOKS_DIR) and 'Sessions'"
echo "          (/media/$SESSIONS_DIR, type Podcast). Talk Radio & Comedy Club and The Archives are NOT here: they have their"
echo "          own servers (audiobookshelf-talk.sh, audiobookshelf-archives.sh)."
