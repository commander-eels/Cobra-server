# shellcheck shell=bash
# Shared by audiobookshelf-talk.sh and audiobookshelf-archives.sh: one walled Audiobookshelf server per Bay.
# Sourced, never run on its own. The caller sets, before sourcing:
#   NAME   container and pod name (audiobookshelf-talk | audiobookshelf-archives)
#   PORT   the one port it answers on (13379 | 13380)
#   MEDIA  the ONE media folder it may read, relative to $DISKS (e.g. dock1a/comedy)
#
# Why its own pod and not the stream pod: a pod's ports are fixed when it's made, and adding one to "stream"
# means re-creating it, which stops every media app at once. Its own pod adds a port without touching the others,
# and it shares no localhost with the other apps either.
# The wall: it mounts only MEDIA (read-only), keeps its own config and metadata, and has its own users.
# Nothing is shared with the main Audiobookshelf on :13378.
here=$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)
# shellcheck source=../lib.sh
. "$here/../lib.sh"

IMAGE=${ABS_IMAGE:-ghcr.io/advplyr/audiobookshelf:latest}
DATA=${COBRA_DATA:-/srv/stream}/$NAME

preflight
need_folders "$MEDIA"                                  # the drive must be mounted and the folder there
ensure_pod "$NAME" "$PORT:$PORT"                      # its own pod: publishes only this port
ensure_dir "$DATA/config" "$DATA/metadata"            # its own settings, users and covers
keep_personal_state "$NAME"                           # an EMPTY config is refilled from its own nightly snapshot (state.sh)

# A first start on an empty config folder shows the "create the root user" page. An existing one is kept as it is.
[ -n "$(ls -A "$DATA/config" 2>/dev/null)" ] && say "kept the existing settings and users in $DATA/config"

run_container "$NAME" "$NAME" "$IMAGE" \
  -e PORT="$PORT" \
  -v "$DATA/config:/config:Z" \
  -v "$DATA/metadata:/metadata:Z" \
  -v "$DISKS/$MEDIA:/media/${MEDIA##*/}:ro"

wait_port "$PORT" 90 || warn "$NAME isn't answering on :$PORT yet; check: podman logs --tail 40 $NAME"
snapshot_personal_state "$NAME"                       # its own snapshot, never mixed with the other two servers
done_msg "$NAME" "http://10.6.9.20:$PORT"
