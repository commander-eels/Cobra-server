#!/usr/bin/env bash
# The Archives: its own walled Audiobookshelf. http://10.6.9.20:13380  (public: archives.songofeo.com)
# Works like Talk Radio, but it's a separate server: its own pod, settings, covers, port and users.
# Run as podsvc on the SGIN:  bash ./audiobookshelf-archives.sh
# Its media: /srv/storage/disks/dock1a/archives (read-only), seen inside as /media/archives.
# shellcheck disable=SC2034  # used by abs-walled.sh
NAME=audiobookshelf-archives PORT=13380 MEDIA=${ARCHIVES_DIR_OVERRIDE:-dock1a/archives}
# shellcheck source=abs-walled.sh
. "$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/abs-walled.sh"
