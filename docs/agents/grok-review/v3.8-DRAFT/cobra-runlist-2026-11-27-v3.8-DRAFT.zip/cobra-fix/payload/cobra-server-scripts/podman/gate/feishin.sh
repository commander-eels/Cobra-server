#!/usr/bin/env bash
# Feishin: a better-looking web player for the Music Bay's Navidrome (2026-11-21, the Commander's call:
# Navidrome's own player is too plain). https://player.songofeo.com, behind the same Music wall as music.
# Feishin is only the page; the music, playlists, stars and play counts stay in Navidrome. The browser signs in
# to Navidrome with the person's own username and password (the Multi-Pass keeps it the same everywhere).
# Run as podsvc on the gate:  bash ./feishin.sh
here=$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)
# shellcheck source=../lib.sh
. "$here/../lib.sh"
# shellcheck source=pod.sh
. "$here/pod.sh"

IMAGE=${FEISHIN_IMAGE:-ghcr.io/jeffvli/feishin:latest}

preflight
gate_pod

# SERVER_URL is the address the BROWSER uses to reach Navidrome, so it's the public name, not 10.6.9.20.
# SERVER_LOCK=true: the page offers only this one server. Feishin listens on 9180 inside the gate pod.
run_container feishin "$GATE_POD" "$IMAGE" \
  -e SERVER_NAME="Song of Eo Music" \
  -e SERVER_TYPE=navidrome \
  -e SERVER_URL="${FEISHIN_SERVER_URL:-https://music.songofeo.com}" \
  -e SERVER_LOCK=true \
  -e PUBLIC_PATH=/

pod_http feishin http://127.0.0.1:9180 60 || warn "Feishin isn't answering on 9180 yet; check podman logs feishin"
done_msg feishin https://player.songofeo.com
