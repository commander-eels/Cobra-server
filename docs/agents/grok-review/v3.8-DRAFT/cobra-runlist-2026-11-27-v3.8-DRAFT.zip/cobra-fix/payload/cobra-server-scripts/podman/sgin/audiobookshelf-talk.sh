#!/usr/bin/env bash
# Talk Radio & Comedy Club: its own Audiobookshelf. http://10.6.9.20:13379  (public: talk.songofeo.com, comedy.songofeo.com)
# Long talk-radio shows (2+ hours a file) and comedy specials and CDs (about an hour). Audiobookshelf keeps each
# person's spot and bookmarks per file, and its phone app plays offline, which is why it's used here.
# Run as podsvc on the SGIN:  bash ./audiobookshelf-talk.sh
# Its media: /srv/storage/disks/dock1a/comedy (read-only), seen inside as /media/comedy.
# shellcheck disable=SC2034  # used by abs-walled.sh
NAME=audiobookshelf-talk PORT=13379 MEDIA=${TALK_DIR:-dock1a/comedy}
# shellcheck source=abs-walled.sh
. "$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/abs-walled.sh"
