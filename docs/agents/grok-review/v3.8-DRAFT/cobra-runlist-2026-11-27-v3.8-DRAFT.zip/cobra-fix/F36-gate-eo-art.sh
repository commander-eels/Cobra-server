#!/usr/bin/env bash
# F36-gate-eo-art.sh  --  checks eo-art (the custom wall-art covers in each Bay's window) after all the wall changes,
# and fixes the three things the check found.
#
# Where it runs: eo-art is a container on the GATE (10.6.9.10, inside the gate pod, 127.0.0.1:8790, art.songofeo.com).
# The pictures live on cobra-stream (the SGIN): dock1a/art and dock1a/comedy, which the gate reads over the
# read-only media share. So the pictures are "on cobra-stream", and this script runs on the gate.
# How:    sudo machinectl shell podsvc@ /bin/bash /tmp/cobra-fix/F36-gate-eo-art.sh
#
# What Claude found (eo_art.py itself is unchanged and was test-run with every wall: it works):
#   1. Two Bays ask for a wall that folders.json never had, so they always show their drawn art:
#        the Library    /books/ebook/cover   -> new folder dock1a/art/ebooks  (copies of covers you pick)
#        The Archives   /archives/cover      -> new folder dock1a/art/archives (copies YOU pick: the recordings
#                                               themselves are never read, they're private)
#   2. eo-art could read ALL of dock1a (the old one-shot gave it that for the comedy covers), which includes The
#      Archives' recordings. The wall rule says it reads only what it needs: dock1a/art and dock1a/comedy.
#   3. Nothing else changed for it: Kavita and the Audiobookshelf walls don't touch eo-art, and every path it
#      uses (/art/..., /media/dock1a/comedy) stays the same.
#
# Each change: a diff, your y, a backup. eo-art is restarted once and checked; a failed check puts it all back.
# It keeps no personal data, so a restart loses nothing.
. "$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/fixlib.sh"
need_podsvc
[ "$(which_box)" = gate ] || die "this is for the gate (10.6.9.10): eo-art runs there and reads the SGIN's pictures"
APP=/srv/gate/eo-art
J=$APP/folders.json
QF=$QDIR_FIX/eo-art.container

art_code() {   # the status code one wall answers inside the pod (eo-art's image has python, not curl)
  podman exec eo-art python3 -c '
import sys, urllib.request, urllib.error
try: print(urllib.request.urlopen("http://127.0.0.1:8790" + sys.argv[1], timeout=4).status)
except urllib.error.HTTPError as e: print(e.code)
except Exception: print("000")' "$1" 2>/dev/null || echo 000
}
WALLS=(/cinema/poster /cinema/backdrop /radio/cover /books/audio/cover /books/ebook/cover /comedy/cover /comics/cover /gaming/cover /archives/cover)

say "1/4 Read-only: is eo-art running, and what does each wall answer?"
podman container exists eo-art || die "no eo-art container. Run F40 --fix (it's started by $( [ -f "$QF" ] && echo 'its Quadlet' || echo 'gate/eo-art.sh'))."
note "state: $(podman inspect -f '{{.State.Status}}' eo-art)   started by: $( [ -f "$QF" ] && echo "Quadlet ($QF)" || echo 'the run script gate/eo-art.sh')"
for w in "${WALLS[@]}"; do printf '    %-20s %s\n' "$w" "$(art_code "$w")"; done
note "200 = it has pictures for that wall. 404 = no pictures yet (that Bay shows its drawn art). 000 = eo-art isn't answering."
note "what eo-art can read now:"
podman inspect -f '{{range .Mounts}}    {{.Source}} -> {{.Destination}}{{"\n"}}{{end}}' eo-art
for d in "$ART_DIR/ebooks" "$ART_DIR/archives"; do
  [ -d "$DISKS/$d" ] && note "$d: $(find "$DISKS/$d" -maxdepth 2 -iname '*.jpg' | wc -l) pictures" || warn "$d doesn't exist yet (see the end of this script's output)"
done

say "2/4 folders.json: add the two missing walls"
[ -f "$J" ] || die "$J doesn't exist. eo-art then uses its built-in defaults; send this output to Claude or Grok."
new=$(mktemp)
podman exec -i eo-art python3 -c '
import json, sys
c = json.load(sys.stdin)
w = c.setdefault("walls", {})
w.setdefault("books/ebook/cover", [{"path": "/art/ebooks"}])
w.setdefault("archives/cover", [{"path": "/art/archives"}])
json.dump(c, sys.stdout, indent=2); print()' <"$J" >"$new" || die "couldn't read $J as JSON; nothing changed"
changed=0
if offer "$J" "$new" "eo-art's folders.json"; then changed=1; fi

say "3/4 Narrow what eo-art can read to dock1a/art and dock1a/comedy"
if [ -f "$QF" ]; then
  newq=$(mktemp)
  # The one-shot gave the Quadlet a line like  Volume=/srv/storage/disks/dock1a:/media/dock1a:ro  -> comedy only.
  sed -E "s#^(Volume=)([^:]*)/dock1a:/media/dock1a(:ro)?\$#\1\2/$COMEDY_DIR:/media/$COMEDY_DIR:ro#" "$QF" >"$newq"
  if offer "$QF" "$newq" "eo-art's Quadlet file"; then changed=1; systemctl --user daemon-reload; fi
fi

say "4/4 Restart and check"
if [ $changed = 0 ] && [ ! -f "$QF" ] && podman inspect -f '{{range .Mounts}}{{.Destination}} {{end}}' eo-art | grep -qw /media/dock1a; then
  confirm "eo-art runs from its script with all of dock1a. Re-create it from the walled gate/eo-art.sh?" && { bash "$PODS/gate/eo-art.sh"; changed=1; }
fi
if [ $changed = 0 ]; then note "nothing changed, nothing restarted"
else
  if [ -f "$QF" ]; then systemctl --user restart eo-art; else podman restart eo-art >/dev/null; fi
  sleep 6
  bad=0
  for w in "${WALLS[@]}"; do c=$(art_code "$w"); printf '    %-20s %s\n' "$w" "$c"; [ "$c" = 000 ] && bad=1; done
  if [ $bad = 1 ]; then
    warn "eo-art isn't answering: putting the backups back"
    for f in "$J" "$QF"; do b=$(ls -1t "$f".bak-* 2>/dev/null | head -1); [ -n "$b" ] && cp -p "$b" "$f"; done
    [ -f "$QF" ] && { systemctl --user daemon-reload; systemctl --user restart eo-art; } || podman restart eo-art >/dev/null
    die "put back. Send: podman logs --tail 30 eo-art"
  fi
  say "eo-art is up with the new walls"
fi
cat <<TXT

==> The two new walls need pictures. On cobra-stream (the SGIN), as eels, make the folders once:
      sudo mkdir -p $DISKS/$ART_DIR/ebooks $DISKS/$ART_DIR/archives
    then copy .jpg pictures in from the-box (\\\\cobra-stream share, dock1a\\art\\ebooks and \\art\\archives).
    eo-art picks them up within 6 hours, or at once if you run this script again.
    The Archives wall only ever shows what you put in art/archives, and only to people signed in to the station.
TXT
