#!/usr/bin/env bash
# F35-gate-kavita-routes.sh  --  points the gate at the three walled Kavitas (2026-11-21, Calibre-Web retiring):
#   books.songofeo.com, ebooks.songofeo.com -> Kavita Books, the bookstore sections   (10.6.9.20:5001; was Calibre-Web :8083)
#   gaming.songofeo.com                     -> Kavita RPG Vault                       (10.6.9.20:5002; was a holding page)
#   comics.songofeo.com                     -> Kavita Comics, unchanged               (10.6.9.20:5000)
# and lets Kavita's phone and OPDS apps use books., ebooks. and gaming. the way comics. already does: their /api/
# paths skip the gate sign-in, and each Kavita's own login (its own accounts, its own API keys) is the wall there.
#
# Where:  the gate (10.6.9.10), as podsvc.
# How:    sudo machinectl shell podsvc@ /bin/bash /tmp/cobra-fix/F35-gate-kavita-routes.sh
# First:  on the SGIN, cobra-server scripts/podman/sgin/kavita.sh books and rpg (docs/kavita-walls-runbook.md
#         steps 1-3), so 5001 and 5002 answer.
#
# It edits only those lines in the LIVE songofeo.conf (no template rewrite, so hand edits stay): a diff, your y,
# a backup, then nginx -t; a failed check puts the file back. Authelia isn't touched: books., ebooks. and gaming.
# are already in its rules, so nobody is signed out. Calibre-Web itself keeps running; removing it is a separate,
# later step (the runbook's step 5), after the owner's yes.
. "$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/fixlib.sh"
need_podsvc
[ "$(which_box)" = gate ] || die "this is for the gate (10.6.9.10)"
[ -f "$NG" ] || die "$NG doesn't exist"

say "0/2 Can the gate reach the new Kavitas? (read-only)"
for u in http://10.6.9.20:5001/api/health http://10.6.9.20:5002/api/health; do printf '    %-40s %s\n' "$u" "$(probe_code "$u")"; done
note "000 means not yet: start kavita-books and kavita-rpg on the SGIN first (and open 5001/5002 in its nftables)."
note "You can still go on; those doors just show an error until then."

say "1/2 nginx ($NG)"
new=$(mktemp)
# sed, line by line:
#   - books. and ebooks. upstream lines move to 5001 (whatever port they had before), with a new comment
#   - the old Calibre-Web OPDS skip becomes a Kavita /api/ skip for books., ebooks. and gaming.
# awk then:
#   - removes the Game Cellar holding-page server block (from its comment to the closing brace)
#   - adds gaming. to the station map, under comics., and to the floors' server_name
sed -E \
  -e 's#^(\s*books\.songofeo\.com\s+)http://10\.6\.9\.20:[0-9]+;.*#\1http://10.6.9.20:5001;    \# Library Bay: Kavita Books, one library per bookstore section (F35)#' \
  -e 's#^(\s*ebooks\.songofeo\.com\s+)http://10\.6\.9\.20:[0-9]+;.*#\1http://10.6.9.20:5001;    \# old name for books.: Kavita Books (F35)#' \
  -e 's#^(\s*)~\^\(books\|ebooks\)\\\.songofeo\\\.com/opds\(/\|\\\?\|\$\)(\s+)1;.*#\1~^(books|ebooks|gaming)\\.songofeo\\.com/api/\2         1;   \# Kavita Books and RPG Vault: phone and OPDS apps, their own login (F35)#' \
  "$NG" >"$new"
awk '
  /^# --- Game Cellar: no app yet/ { skip = 1; next }
  skip && /^}/ { skip = 0; next }
  skip { next }
  { print }
  /^[[:space:]]*comics\.songofeo\.com[[:space:]]+http/ && !added && !have {
    print "  gaming.songofeo.com       http://10.6.9.20:5002;    # RPG Vault Bay: its own walled Kavita (F35)"; added = 1
  }
' have="$(grep -cE '^\s*gaming\.songofeo\.com\s+http' "$NG" || true)" "$new" >"$new.2" && mv "$new.2" "$new"
# awk's "have" is a count string; "0" is false there, so gaming. is added only when the map doesn't have it yet.
# The floors' server_name runs over two lines; comics. sits on the second. Add gaming. right after it, on the first
# line that names comics. as a host (no "http", so not the map), unless a server_name already has gaming.
# host_lines FILE: how many server_name lines (not map lines, not regex lines) list gaming. as a host.
host_lines() { grep -vE 'http|~\^|^\s*#' "$1" | grep -cE '\sgaming\.songofeo\.com(\s|;|$)' || true; }
if [ "$(host_lines "$new")" = 0 ]; then
  awk '!done && / comics\.songofeo\.com / && !/http/ { sub(/ comics\.songofeo\.com /, " comics.songofeo.com gaming.songofeo.com "); done = 1 } { print }' "$new" >"$new.2" && mv "$new.2" "$new"
fi

# Checks before anything is offered: exactly one gaming. server_name, books. on 5001, no Calibre-Web port left.
[ "$(host_lines "$new")" = 1 ] || die "gaming.songofeo.com isn't in exactly one server_name after the edit. Nothing changed. Send Claude: grep -n gaming $NG"
grep -qE '^\s*books\.songofeo\.com\s+http://10\.6\.9\.20:5001;' "$new" || die "books. didn't move to 5001. Nothing changed. Send Claude: grep -n 'books\.' $NG"
! grep -q ':8083' "$new" || die "a :8083 line is still there. Nothing changed. Send Claude: grep -n 8083 $NG"

if offer "$NG" "$new" "nginx's songofeo.conf"; then
  say "2/2 Check and reload"
  gate_check_and_reload no_authelia "$NG"
else
  note "kept as it was; nothing to reload"
fi
cat <<'TXT'

==> Then, in a browser:
    https://books.songofeo.com   Kavita Books: its own admin and users (it's a new Kavita, so nobody has an account yet)
    https://gaming.songofeo.com  Kavita RPG Vault: same accounts as Comics had, new sign-in (it was cut loose from Comics)
    DNS and the certificate need nothing: books., ebooks. and gaming. already point at the gate and are covered.
TXT
