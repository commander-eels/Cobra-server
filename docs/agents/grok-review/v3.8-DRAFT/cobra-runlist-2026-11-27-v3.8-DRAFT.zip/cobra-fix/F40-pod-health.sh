#!/usr/bin/env bash
# F40-pod-health.sh  --  is EVERY pod installed, running and healthy? Read-only unless you add --fix.
#
# Where:  the gate (10.6.9.10) and the SGIN (10.6.9.20), as podsvc. It knows which machine it's on.
# How (look only):              sudo machinectl shell podsvc@ /bin/bash /tmp/cobra-fix/F40-pod-health.sh
# How (offer to start/install): sudo machinectl shell podsvc@ /bin/bash /tmp/cobra-fix/F40-pod-health.sh --fix
#
# For each app it prints OK, WARN or DOWN with the reason (not installed, stopped, unhealthy, page not answering).
# With --fix it asks about each problem ONE AT A TIME (y/N):
#   stopped, run by Quadlet  -> systemctl --user start <name>
#   stopped or missing, run by a cobra-server script -> bash <that script>  (it re-creates the container from the
#                               same data folders; data is never deleted, the nightly snapshot fills an empty app)
#   anything set up by a cobra-setup step (eo-account, forms) -> it tells you which step, it doesn't guess
# Healthy apps are never touched. Run it again afterwards: a clean run prints only OK lines.
. "$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/fixlib.sh"
set +e
need_podsvc
FIXMODE=0; [ "${1:-}" = --fix ] && FIXMODE=1
BOX=$(which_box)
case $BOX in
  gate) list=("${EXPECTED_GATE[@]}") ;;
  sgin) list=("${EXPECTED_SGIN[@]}") ;;
  *) die "this machine is neither the gate (10.6.9.10) nor the SGIN (10.6.9.20)" ;;
esac
say "Pod health on the $BOX ($( [ $FIXMODE = 1 ] && echo 'fix mode: asks before each change' || echo 'read-only'))"
bad=0

for row in "${list[@]}"; do
  IFS='|' read -r name url how what <<<"$row"
  state=$(podman inspect -f '{{.State.Status}}' "$name" 2>/dev/null || echo missing)
  health=$(podman inspect -f '{{if .State.Health}}{{.State.Health.Status}}{{end}}' "$name" 2>/dev/null)
  code=""; [ "$state" = running ] && [ -n "$url" ] && code=$(probe_code "$url")
  problem=""
  if [ "$state" = missing ]; then problem="not installed"
  elif [ "$state" != running ]; then problem="$state"
  elif [ "$health" = unhealthy ]; then problem="unhealthy (podman's health check fails)"
  elif [ -n "$code" ] && { [ "$code" = 000 ] || [ "$code" -ge 500 ]; }; then problem="running, but its page answers $code"
  fi
  if [ -z "$problem" ]; then
    printf '  \033[1;32mOK  \033[0m %-24s %s%s\n' "$name" "$what" "${code:+ (page $code)}"
    continue
  fi
  bad=$((bad + 1))
  printf '  \033[1;31mDOWN\033[0m %-24s %s: %s\n' "$name" "$what" "$problem"
  [ $FIXMODE = 1 ] || continue

  # ---- fix mode: one question per problem
  if [ -f "$QDIR_FIX/$name.container" ]; then
    if confirm "    Start $name with systemctl --user start $name?"; then
      systemctl --user start "$name" && sleep 5 && printf '    now: %s\n' "$(podman inspect -f '{{.State.Status}}' "$name" 2>/dev/null)"
    fi
  elif [ "${how%%:*}" = script ] && [ -f "$PODS/${how#script:}" ]; then
    if [ "$state" = exited ] || [ "$state" = stopped ] || [ "$state" = created ]; then
      confirm "    Start the existing $name container (podman start $name)?" && podman start "$name" >/dev/null && note "started"
    else
      confirm "    Run ${how#script:} to install/re-create $name? (keeps its data folders)" && bash "$PODS/${how#script:}"
    fi
  elif [ "$problem" = "running, but its page answers $code" ] || [ "${problem%% *}" = unhealthy ]; then
    if confirm "    Restart $name (podman restart)?"; then restart_app "$name"; sleep 8; note "now: $(probe_code "$url")"; fi
  else
    note "    $name is set up by ${how#*:}. Run that step; this script doesn't guess its settings."
  fi
done

echo
# Retired containers are reported, never stopped: they go only when you say so.
podman ps -a --filter name=calibre-web --format "  NOTE {{.Names}} ({{.Status}}): retiring: Kavita Books has the books now (F35). Removing it is step 5 of cobra-server docs/kavita-walls-runbook.md, after the owner's yes. Left alone here." 2>/dev/null
podman ps -a --filter name=navidrome-talk --filter name=navidrome-archives --format '  NOTE old {{.Names}} ({{.Status}}): retired, left alone until you OK removing it' 2>/dev/null
if [ $bad = 0 ]; then say "All $BOX pods are installed and healthy."
else warn "$bad pod(s) need attention on the $BOX.$( [ $FIXMODE = 0 ] && echo ' Run again with --fix to be asked about each one.')"; fi
