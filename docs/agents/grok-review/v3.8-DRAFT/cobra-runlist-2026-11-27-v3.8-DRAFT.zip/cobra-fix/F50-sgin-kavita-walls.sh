#!/usr/bin/env bash
# F50-sgin-kavita-walls.sh  --  the three walled Kavitas on cobra-stream (the SGIN), in the right order:
#   Comics   :5000  dock1a/comics only                 (stream pod, as before)
#   RPG Vault:5002  dock1a/books/RPG Books only        (pod kavita-rpg)   <- moved out of Comics, progress kept
#   Books    :5001  your bookstore sections only        (pod kavita-books) <- replaces Calibre-Web, later
#
# Where:  the SGIN (10.6.9.20), as podsvc.  First: F31 (opens 5001 and 5002, with the Audiobookshelf ports).
# How:    sudo machinectl shell podsvc@ /bin/bash /tmp/cobra-fix/F50-sgin-kavita-walls.sh
#
# It walks the cobra-server runbook (docs/kavita-walls-runbook.md, steps 2 and 3) one step at a time and waits for
# you between steps, because two of them are clicks in a browser. Every step asks first. Read-only mounts only:
# no Kavita can move, rename or delete a book. Calibre-Web keeps running; removing it is the runbook's step 5,
# only after your yes, and it's NOT in this fix list.
. "$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/fixlib.sh"
need_podsvc
[ "$(which_box)" = sgin ] || die "this is for the SGIN (10.6.9.20)"
K=$PODS/sgin/kavita.sh
[ -f "$K" ] || die "$K is missing from the fix list"
pause() { read -r -p "    Done in the browser? Press Enter to go on (Ctrl+C stops here, nothing half-done): " _ </dev/tty; }

say "0/3 Read-only: what's there now"
for n in kavita kavita-rpg kavita-books; do
  printf '    %-13s %s\n' "$n" "$(podman inspect -f '{{.State.Status}}' "$n" 2>/dev/null || echo 'not made yet')"
done
for p in 5000 5001 5002; do printf '    :%s -> %s\n' "$p" "$(probe_code "http://127.0.0.1:$p/")"; done
for d in "$COMICS_DIR" "$RPG_DIR" "$BOOKS_DIR"; do [ -d "$DISKS/$d" ] && note "$d is there" || warn "$d is missing"; done

# ---------------------------------------------------------------- 1. RPG Vault
say "1/3 The RPG Vault gets its own Kavita (:5002)"
if podman container exists kavita-rpg; then
  note "kavita-rpg already exists: re-created on the same settings (nothing is copied again)"
  confirm "Re-create kavita-rpg?" && bash "$K" rpg
else
  note "It starts from a COPY of Comics' settings (accounts and RPG reading progress come along), then gets its own"
  note "signing key and API keys so a Comics sign-in can't open it. Comics stops for a few seconds during the copy."
  if confirm "Make the RPG Vault's Kavita now, copied from Comics?"; then
    COPY_FROM_COMICS=1 bash "$K" rpg || die "kavita.sh rpg stopped (reason above). Nothing else was changed."
  else
    note "skipped. To start it blank instead (new accounts, no progress): bash $K rpg"
  fi
fi
cat <<'TXT'

    In a browser on the-box (PIA off):
      1. http://10.6.9.20:5002  (RPG Vault): Admin -> Libraries -> delete "Comics". Keep "RPG Vault".
      2. http://10.6.9.20:5000  (Comics):    Admin -> Libraries -> delete "RPG Vault".
    Deleting a library only drops it from that Kavita's database. The book files are read-only and stay.
TXT
pause

# ---------------------------------------------------------------- 2. Comics
say "2/3 Comics reads only dock1a/comics"
note "kavita.sh refuses, and lists them, if Comics still has a library outside dock1a/comics (then do step 2 above)"
confirm "Re-create Comics with only its own folder?" && bash "$K" comics

# ---------------------------------------------------------------- 3. Books
say "3/3 Books (:5001), one library per bookstore section"
SEC=${COBRA_CONF:-$HOME/.config/cobra}/kavita-books.sections   # the same file kavita.sh reads
if [ ! -s "$SEC" ]; then
  note "First run: kavita.sh writes the list of section folders it found, and stops so you can check it."
  confirm "Write the section list now?" && bash "$K" books
  [ -s "$SEC" ] || die "no section list was written. Send this output to Claude or Grok."
fi
note "Books will see exactly these folders (one per line; # lines are ignored). RPG Books is never allowed:"
sed 's/^/      /' "$SEC"
note "To change the list, stop here (Ctrl+C) and run:  nano $SEC  then run this script again."
confirm "Start Books with exactly those folders?" && bash "$K" books
cat <<'TXT'

==> Books, first time only, at http://10.6.9.20:5001:
      the first visit makes the admin (its own password: save it in Vaultwarden), then
      Admin -> Libraries -> Add, once per section, type Book. kavita.sh printed each name and folder above.
    Then on the gate: F35 points books. and gaming. at these Kavitas.
TXT
