#!/usr/bin/env bash
# F33-gate-feishin.sh  --  starts Feishin, a nicer web player for the Music Bay's Navidrome, on the gate.
#   https://player.songofeo.com  (needs F32 for the door and the Porkbun CNAME it prints)
#
# Where:  the gate (10.6.9.10), as podsvc.
# How:    sudo machinectl shell podsvc@ /bin/bash /tmp/cobra-fix/F33-gate-feishin.sh
#
# Feishin is only the page. Music, playlists, stars and play counts stay in Navidrome, so nothing moves and
# Navidrome's own page at music. keeps working. People sign in to Feishin with their station username and password.
. "$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/fixlib.sh"
need_podsvc
[ "$(which_box)" = gate ] || die "this is for the gate (10.6.9.10)"

say "1/2 Read-only checks"
printf '    Navidrome from the gate (http://10.6.9.20:4533/ping): %s\n' "$(probe_code http://10.6.9.20:4533/ping)"
podman container exists feishin && note "feishin already exists; it's re-created on the same settings (it keeps no data)"
grep -q 'player\.songofeo\.com' "$NG" || warn "nginx has no player.songofeo.com yet: run F32 too, or the page won't open from outside the gate"
confirm "Start (or update) Feishin now?" || die "nothing changed"

say "2/2 Start it"
bash "$PODS/gate/feishin.sh"
cat <<'TXT'

==> Try it: https://player.songofeo.com  -> the gate's sign-in (Music wall) -> Feishin asks for your username
    and password once (the same ones as everywhere). On a phone, "Add to Home screen" makes it an app icon.
    If Feishin says it can't reach the server: send Claude or Grok the line from  podman logs --tail 20 feishin
    and what the browser's console shows (F12 -> Console). That's usually CORS on music.'s /rest paths.
TXT
