#!/usr/bin/env bash
# F11-sgin-arcade-own-pod.sh  --  (v3.2) gives the Arcade (RomM + its MariaDB) a pod of its own, so RomM can start.
#
# Why (from the 2026-11-21 SGIN survey): RomM's page answers on 8080, but its engine (gunicorn) crash-loops with
#   "connection to ('0.0.0.0', 5000) failed: [Errno 98] Address in use". Inside the RomM image, gunicorn always
#   listens on 5000, and Kavita Comics always listens on 5000 too. A pod is ONE shared network, and both live in
#   the "stream" pod, so whichever starts first wins. Kavita won, so RomM's /api/heartbeat never answers and
#   its setup wizard can never show. This is also the owner's walled rule: RomM gets its own pod.
#
# What it changes (Quadlet files in ~/.config/containers/systemd, each with a diff, your y and a backup):
#   1. NEW  arcade.pod            PodName=arcade, PublishPort=8080:8080
#   2. EDIT stream.pod            the PublishPort=8080:8080 line is commented out (not deleted), so the
#                                 Arcade pod can publish 8080. Every other port stays.
#   3. EDIT romm.container        Pod=stream.pod  ->  Pod=arcade.pod
#   4. EDIT romm-db.container     Pod=stream.pod  ->  Pod=arcade.pod   (RomM still reaches it on 127.0.0.1)
#   The address stays http://10.6.9.20:8080 and arcade.songofeo.com, so the gate, the firewall and the
#   Multi-Pass need no change. No data folder is touched; the database stays in /srv/stream/romm/db.
#
# DOWNTIME: restarting the stream pod stops Jellyfin, ErsatzTV, Navidrome, Audiobookshelf, Kavita and Calibre-Web
#   for about a minute. Run it when nobody is watching the TV. It asks before that part.
#
# Where:  the SGIN (10.6.9.20), as podsvc.
# How:    sudo machinectl shell podsvc@ /bin/bash /tmp/cobra-fix/F11-sgin-arcade-own-pod.sh
# After:  README step 3b (RomM 5 password reset), if the wizard is off.
# Undo:   it prints the exact undo lines at the end (put the .bak files back, daemon-reload, restart).
. "$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/fixlib.sh"
need_podsvc
[ "$(which_box)" = sgin ] || die "this is for the SGIN (10.6.9.20)"
Q=$HOME/.config/containers/systemd
SP=$Q/stream.pod; AP=$Q/arcade.pod; RC=$Q/romm.container; DC=$Q/romm-db.container
for f in "$SP" "$RC" "$DC"; do [ -f "$f" ] || die "$f doesn't exist. Send F01's survey to Claude or Grok."; done

say "1/5 Look first (read-only)"
note "Pod lines:"; grep -Hn '^\s*Pod=' "$RC" "$DC" | sed 's/^/      /' || true
note "stream.pod ports:"; grep -n 'PublishPort' "$SP" | sed 's/^/      /' || true
note "RomM's last engine lines:"; podman logs --tail 3 romm 2>&1 | sed 's/^/      /' || true
if grep -qE '^\s*Pod=arcade\.pod' "$RC" && grep -qE '^\s*Pod=arcade\.pod' "$DC" && [ -f "$AP" ]; then
  say "RomM is already in its own pod."; romm_hb 20 | head -c 300; echo; exit 0
fi
grep -qE '^\s*Pod=stream\.pod' "$RC" || die "romm.container isn't in stream.pod (see above). Send this screen to Claude or Grok."
grep -qE '^\s*Pod=stream\.pod' "$DC" || die "romm-db.container isn't in stream.pod (see above). Send this screen to Claude or Grok."
grep -qE '^\s*PublishPort=(0\.0\.0\.0:)?8080:8080\s*$' "$SP" || die "stream.pod has no plain PublishPort=8080:8080 line (see above). Send this screen to Claude or Grok."

restore_files() {
  warn "putting the Quadlet files back"
  for f in "$SP" "$RC" "$DC"; do restore "$f"; done
  [ -f "$AP.bak-$TS" ] && restore "$AP"
  [ -f "$AP" ] && [ ! -f "$AP.bak-$TS" ] && mv "$AP" "$AP.unused-$TS" && note "moved the new arcade.pod aside: $AP.unused-$TS"
  systemctl --user daemon-reload
}
undo() {
  restore_files
  systemctl --user stop romm romm-db arcade-pod 2>/dev/null || true
  systemctl --user restart stream-pod
  systemctl --user start romm-db romm || true
}

say "2/5 The four Quadlet changes (all four, or none)"
changed=(); said_no=0
new=$(mktemp)
cat >"$new" <<'EOF'
# The Arcade's own pod (F11, 2026-11-21): RomM + romm-db. RomM's engine listens on 5000 inside, which clashed
# with Kavita Comics in the stream pod. Same address as before: http://10.6.9.20:8080
[Pod]
PodName=arcade
PublishPort=8080:8080
EOF
rc=0; offer "$AP" "$new" "the new arcade.pod" || rc=$?; [ $rc = 0 ] && changed+=("$AP"); [ $rc = 2 ] && said_no=1

new=$(mktemp)
sed -E 's/^(\s*PublishPort=(0\.0\.0\.0:)?8080:8080\s*)$/# \1    # F11: moved to arcade.pod/' "$SP" >"$new"
rc=0; offer "$SP" "$new" "stream.pod" || rc=$?; [ $rc = 0 ] && changed+=("$SP"); [ $rc = 2 ] && said_no=1
for f in "$RC" "$DC"; do
  new=$(mktemp)
  sed -E 's/^(\s*)Pod=stream\.pod\s*$/\1Pod=arcade.pod/' "$f" >"$new"
  rc=0; offer "$f" "$new" "$(basename "$f")" || rc=$?; [ $rc = 0 ] && changed+=("$f"); [ $rc = 2 ] && said_no=1
done

if [ $said_no = 1 ]; then restore_files; die "the four changes only work together, so the ones you said yes to were put back. Nothing restarted beyond that."; fi
[ ${#changed[@]} -gt 0 ] || die "nothing to change"

say "3/5 Restart (about a minute of no TV, music or books)"
if ! confirm "Restart the stream pod and start the Arcade pod now?"; then
  restore_files; die "you said no, so the files were put back and nothing restarted"
fi
systemctl --user daemon-reload
systemctl --user stop romm romm-db
systemctl --user restart stream-pod
systemctl --user start arcade-pod romm-db
# Give MariaDB up to a minute to be ready before RomM starts (Grok's v3.5 note), so a slow DB can't fail the check.
for _ in $(seq 1 12); do
  st=$(podman inspect -f '{{.State.Health.Status}}' romm-db 2>/dev/null || true)
  [ "$st" = healthy ] && break
  podman exec romm-db sh -c 'mariadb-admin -uroot -p"$MARIADB_ROOT_PASSWORD" ping' >/dev/null 2>&1 && break
  sleep 5
done
systemctl --user start romm

say "4/5 Check"
ok=1
for _ in $(seq 1 24); do [ "$(probe_code http://127.0.0.1:8096/health)" = 200 ] && break; sleep 5; done
for u in http://127.0.0.1:8096/health http://127.0.0.1:5000/ http://127.0.0.1:4533/ping http://127.0.0.1:13378/ping http://127.0.0.1:8409/; do
  c=$(probe_code "$u"); printf '    %-36s %s\n' "$u" "$c"; [ "$c" = 000 ] && ok=0
done
hb=""; for _ in $(seq 1 24); do hb=$(romm_hb 20 || true); [[ $hb == *"{"* ]] && break; sleep 5; done
if [[ $hb == *"{"* ]]; then note "RomM heartbeat: $(printf '%s' "$hb" | head -c 200)"
elif podman logs --tail 40 romm 2>&1 | grep -q 'Address in use'; then warn "RomM's engine still says 'Address in use'"; ok=0
elif romm_up >/dev/null; then warn "RomM's page answers and its engine no longer clashes, but /api/heartbeat gave no JSON (RomM 5 may have moved it). Keeping the change."
else warn "RomM doesn't answer at all"; ok=0; fi
podman logs --tail 3 romm 2>&1 | sed 's/^/      /' || true

say "5/5 Result"
if [ $ok = 1 ]; then
  say "Done. RomM runs in its own pod (arcade) on http://10.6.9.20:8080, and the stream pod is back."
  if grep -qE '"SHOW_SETUP_WIZARD": *true' <<<"$hb"; then note "The setup wizard is ON. Open http://10.6.9.20:8080 on the-box and make the new admin."
  else note "The wizard is off (RomM already has an admin). Next: README step 3b (reset that admin's password)."; fi
  note "Undo, if ever needed: put back each .bak-$TS file in $Q, move arcade.pod aside, then"
  note "  systemctl --user daemon-reload && systemctl --user restart stream-pod && systemctl --user restart romm-db romm"
else
  warn "Something didn't come back (000 above)."
  if confirm "Put everything back the way it was?"; then undo; die "put back; send this screen to Claude or Grok"; fi
  die "left as it is; send this screen to Claude or Grok"
fi
