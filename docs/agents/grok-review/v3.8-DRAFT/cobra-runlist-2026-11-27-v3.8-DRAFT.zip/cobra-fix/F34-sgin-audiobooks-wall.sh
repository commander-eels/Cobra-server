#!/usr/bin/env bash
# F34-sgin-audiobooks-wall.sh  --  walls the MAIN Audiobookshelf (the Audiobooks Bay, :13378) like the other two.
#
# The rule (the owner's, 2026-11-21): every instance of the same app is walled. Three Audiobookshelf servers:
#   audiobookshelf           :13378  Audiobooks (+ The Ward's Sessions)  audio., sessions.   <- this script
#   audiobookshelf-talk      :13379  Talk Radio & Comedy Club            talk., comedy.      (F30)
#   audiobookshelf-archives  :13380  The Archives (private)              home / WireGuard    (F30)
# Each has its own settings, users, libraries and port. Until now the main one could read EVERY drive
# (it mounted all of /srv/disks). After this it reads only its own folders: audiobooks, sessions, and books
# (books only until Kavita's Books library takes over), at the same /media paths, so its libraries keep working.
#
# Where:  the SGIN (10.6.9.20), as podsvc.  Run F30 first (the Talk and Archives servers must exist).
# How:    sudo machinectl shell podsvc@ /bin/bash /tmp/cobra-fix/F34-sgin-audiobooks-wall.sh
#
# What changes: the audiobookshelf CONTAINER is re-created with the narrower mounts. Its data folder
# (settings, users, progress, covers) is kept exactly as it is. No file is moved or deleted.
# Any old "Talk Radio & Comedy Club" or "The Archives" library inside this server then shows its items as
# missing (they are no longer mounted here). Their files are untouched. Delete those two libraries in its
# Settings -> Libraries only when you're happy with the new servers.
# Undo (the old, unwalled mounts):
#   sudo machinectl shell podsvc@ /usr/bin/env ABS_ALL_DISKS=1 bash /tmp/cobra-fix/payload/cobra-server-scripts/podman/sgin/audiobookshelf.sh
#
# Not done here, on purpose: its own POD. It shares the "stream" pod with Jellyfin and the others, and that pod
# publishes 13378; moving it means re-creating the stream pod, which stops every media app at once. That's a
# maintenance-window step for later (see README step 9b). It already shares no data, users or libraries.
. "$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/fixlib.sh"
need_podsvc
[ "$(which_box)" = sgin ] || die "this is for the SGIN (10.6.9.20)"

say "1/3 Read-only checks"
podman container exists audiobookshelf || die "there's no audiobookshelf container. Run F40 --fix first."
note "what the main Audiobookshelf can read now:"
podman inspect -f '{{range .Mounts}}{{if ne .Destination "/config"}}{{if ne .Destination "/metadata"}}    {{.Source}} -> {{.Destination}} ({{if .RW}}read-write{{else}}read-only{{end}}){{"\n"}}{{end}}{{end}}{{end}}' audiobookshelf
for n in audiobookshelf-talk audiobookshelf-archives; do
  if podman container exists "$n"; then note "$n exists ($(podman inspect -f '{{.State.Status}}' "$n"))"
  else warn "$n doesn't exist yet. Run F30 first, so Talk and Archives have their new home before this one stops reading them."; fi
done
printf '    Audiobooks now: http://127.0.0.1:13378/ping -> %s\n' "$(probe_code http://127.0.0.1:13378/ping)"

say "2/3 Wall it"
note "after: it reads only $AUDIOBOOKS_DIR, $SESSIONS_DIR$( [ -d "$DISKS/$BOOKS_DIR" ] && echo " and $BOOKS_DIR (until Kavita Books)"), read-only"
confirm "Re-create the audiobookshelf container with only those folders? (settings, users and progress are kept)" || die "nothing changed"
bash "$PODS/sgin/audiobookshelf.sh"

say "3/3 Check"
sleep 5
printf '    http://127.0.0.1:13378/ping -> %s\n' "$(probe_code http://127.0.0.1:13378/ping)"
podman inspect -f '{{range .Mounts}}{{if ne .Destination "/config"}}{{if ne .Destination "/metadata"}}    now: {{.Source}} -> {{.Destination}}{{"\n"}}{{end}}{{end}}{{end}}' audiobookshelf
cat <<'TXT'

==> Open https://audio.songofeo.com (or http://10.6.9.20:13378). The Audiobooks library should play as before,
    with everyone's saved spot. If a library says its folder is missing and it ISN'T Talk or Archives,
    send Claude or Grok that library's folder path (Settings -> Libraries -> edit) and run the undo line above.
TXT
