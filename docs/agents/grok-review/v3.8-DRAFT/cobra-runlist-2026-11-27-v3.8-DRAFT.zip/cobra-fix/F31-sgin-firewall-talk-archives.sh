#!/usr/bin/env bash
# F31-sgin-firewall-talk-archives.sh  --  lets the LAN and WireGuard reach the four new walled servers, the same way
# they already reach the main Audiobookshelf on 13378 and Kavita Comics on 5000:
#   13379 Talk Radio & Comedy Club   13380 The Archives   5001 Kavita Books   5002 Kavita RPG Vault
# (v3: the Kavita ports joined this step, so the firewall changes once, with one rollback, instead of twice.) Nobody on the internet reaches them directly:
# the internet only ever gets to the gate, and the gate forwards talk., comedy., books. and gaming. (never archives.).
#
# Where:  the SGIN (10.6.9.20), as eels (the firewall belongs to root, so it uses sudo).
# How:    bash /tmp/cobra-fix/F31-sgin-firewall-talk-archives.sh
#
# Safety: your SSH session stays up (established connections are always let through first). The new rules are
# checked with nft -c before loading; /etc/nftables.conf is backed up; after loading you must open a SECOND SSH
# login and type y within 2 minutes, or the old rules go back by themselves.
. "$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/fixlib.sh"
need_eels
CONF=/etc/nftables.conf

sudo test -f "$CONF" || die "$CONF doesn't exist"
LINE=$(sudo grep -nE 'tcp dport \{[^}]*13378' "$CONF" | head -1)
[ -n "$LINE" ] || die "couldn't find the LAN's port list (the line with 13378) in $CONF. Send F01's survey to Claude or Grok."
WANT=(13379 13380 5001 5002)
ADD=(); for p in "${WANT[@]}"; do grep -qE "(^|[^0-9])$p([^0-9]|$)" <<<"${LINE#*:}" || ADD+=("$p"); done
if [ ${#ADD[@]} = 0 ]; then say "${WANT[*]} are already open. Nothing to do."; exit 0; fi
note "to add: ${ADD[*]}"
ADDS=$(printf ', %s' "${ADD[@]}")

new=$(mktemp)
# Add the missing ports right after 13378 on that one line only (the first line that lists 13378).
sudo cat "$CONF" | awk -v adds="$ADDS" '!done && /tcp dport \{[^}]*13378/ { sub(/13378/, "13378" adds); done=1 } { print }' >"$new"
say "Proposed change to $CONF:"
diff -u <(sudo cat "$CONF") "$new" | sed 's/^/    /' || true
say "Checking the new rules without loading them (nft -c)"
sudo nft -c -f "$new" || { rm -f "$new"; die "nft refused the new file; nothing changed"; }
confirm "Load it?" || { rm -f "$new"; die "nothing changed"; }

sudo cp -p "$CONF" "$CONF.bak-$TS" && note "backup: $CONF.bak-$TS"
sudo install -m 644 "$new" "$CONF"; rm -f "$new"
sudo nft -f "$CONF"                                   # the file starts with "flush ruleset": one clean swap

echo
warn "Open a NEW terminal on the-box now and log in:  ssh eels@10.6.9.20"
if read -rt 120 -p "Did the new SSH login work? Type y within 2 minutes: " a </dev/tty && [[ ${a,,} == y* ]]; then
  say "Kept. ${ADD[*]} are open to the LAN and WireGuard."
else
  echo
  sudo cp -p "$CONF.bak-$TS" "$CONF" && sudo nft -f "$CONF"
  die "no confirmation, so the old rules are back (from $CONF.bak-$TS)"
fi
