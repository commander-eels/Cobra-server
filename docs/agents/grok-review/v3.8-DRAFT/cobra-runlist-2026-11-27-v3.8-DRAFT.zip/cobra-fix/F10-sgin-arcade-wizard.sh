#!/usr/bin/env bash
# F10-sgin-arcade-wizard.sh  --  gets RomM's first-run setup wizard (the Arcade) to show again.
#
# Where:  the SGIN (10.6.9.20), as podsvc.
# How:    sudo machinectl shell podsvc@ /bin/bash /tmp/cobra-fix/F10-sgin-arcade-wizard.sh
#
# WHY THE WIZARD NEVER CAME BACK (what the earlier tries ran into):
#   1. RomM shows its wizard only while its database has NO admin account. Any admin left over keeps the login page.
#   2. The bundle you downloaded (cobra-setup55.zip) never had the reset scripts: 24-sgin-romm-reset.sh and the
#      fixed romm-reset.sh were only on GitHub, so the README's reset lines pointed at files that weren't there.
#   3. The old reset checked RomM only on 127.0.0.1:8080. On this SGIN RomM may answer only on 10.6.9.20:8080,
#      so the scripts thought RomM was down and stopped (fixed in the merged lib.sh: it tries both).
#   4. Starting RomM with an EMPTY database (romm.sh, 22-sgin-romm.sh, up-all.sh) restores last night's snapshot
#      from the vault, and the old admin comes straight back. A reset must run with SKIP_STATE_RESTORE=1.
#   5. With Quadlet files whose database is a named podman volume, the old script refused and stopped.
#
# TWO WAYS, you pick one (both read-only until you type the word it asks for):
#   WIZARD  (recommended)  backs up RomM's users table to a file, then turns every admin into a viewer.
#                          Games, scans, covers, saves and every user stay. The wizard shows; you make a new admin.
#                          Undo: the backup file goes back in with one command (printed at the end).
#   FRESH                  a completely empty RomM: its database folder is MOVED aside (never deleted) and RomM
#                          starts blank, without the nightly snapshot. ROMs on dock1b are never touched.
#                          Only for a folder database; a named volume is offered WIZARD only.
. "$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/fixlib.sh"
need_podsvc
[ "$(which_box)" = sgin ] || die "this is for the SGIN (10.6.9.20)"
QDIR=$QDIR_FIX
SCRIPTS=$PODS/sgin
DATA=${COBRA_DATA:-/srv/stream}/romm
SAFE=${COBRA_DATA:-/srv/stream}/romm-backups      # where the users-table backups go (podsvc owns /srv/stream)
mkdir -p "$SAFE" && chmod 700 "$SAFE"

# sql "QUERY"   Runs one query in romm-db as MariaDB's root. The root password is read INSIDE the container
# (it's a podman secret there), so it's never on this command line or in the output.
sql() { podman exec -i romm-db sh -c 'mariadb -uroot -p"$MARIADB_ROOT_PASSWORD" -N romm' <<<"$1"; }

wizard_on() { romm_hb 20 | grep -qE '"SHOW_SETUP_WIZARD": *true'; }   # RomM's own status page says so

# ------------------------------------------------------------------ 1. look (read-only)
say "1/4 RomM right now (read-only)"
MODE=scripts; [ -f "$QDIR/romm.container" ] && MODE=quadlet
note "RomM runs from: $MODE"
podman ps -a --filter name=romm --format '    {{.Names}}  {{.Status}}'
if wizard_on; then
  say "RomM already wants its setup wizard. Nothing to change."
  note "On the-box open http://10.6.9.20:8080/setup in a private window (Ctrl+Shift+N)."
  exit 0
fi
running romm-db || die "romm-db isn't running, so its accounts can't be read. Start it first:
       $( [ $MODE = quadlet ] && echo 'systemctl --user start romm-db' || echo "SKIP_STATE_RESTORE=1 bash $SCRIPTS/romm.sh")
       then run this again. (If an earlier reset moved the data aside, F01's survey lists the folder.)"
roles=$(sql "SELECT role, COUNT(*) FROM users GROUP BY role;") || die "couldn't read RomM's users table (lines above)"
note "accounts by role:"; printf '%s\n' "$roles" | sed 's/^/      /'
# The role column is an ENUM. Its exact words (VIEWER/ADMIN or viewer/admin) differ between RomM versions,
# so they're read from the column itself instead of guessed.
coltype=$(sql "SHOW COLUMNS FROM users LIKE 'role';" | awk -F'\t' '{print $2}')
ADMIN=$(grep -oiE "'admin'" <<<"$coltype" | head -1 | tr -d "'")
VIEWER=$(grep -oiE "'viewer'" <<<"$coltype" | head -1 | tr -d "'")
[ -n "$ADMIN" ] && [ -n "$VIEWER" ] || die "RomM's role column looks different than expected ($coltype). Send this line to Claude or Grok; nothing changed."
admins=$(sql "SELECT COUNT(*) FROM users WHERE role='$ADMIN';")
note "admins: $admins (the wizard shows only when this is 0)"

DBV=""
if [ $MODE = quadlet ]; then
  DBV=$(sed -nE 's#^Volume=([^:]+):/var/lib/mysql.*#\1#p' "$QDIR/romm-db.container" | head -1)
else
  DBV=$DATA/db
fi
FOLDER=0; case $DBV in /*) FOLDER=1 ;; esac

# ------------------------------------------------------------------ 2. choose
say "2/4 Which way?"
cat <<TXT

    WIZARD  keeps everything (games, scans, saves, every user) and turns the $admins admin(s) into viewers.
            A backup of the users table is written first to $SAFE.
    FRESH   $( [ $FOLDER = 1 ] && echo "moves the whole database folder $DBV aside (kept, not deleted) and starts RomM empty." || echo "not offered: the database is the podman volume '$DBV', which can't be moved aside safely.")
    Anything else, or just Enter: stop, nothing changed.

TXT
read -r -p "    Type WIZARD$( [ $FOLDER = 1 ] && echo ' or FRESH'): " way </dev/tty

if [ "$way" = WIZARD ]; then
  # ---------------------------------------------------------------- 3a. wizard: demote admins (after a backup)
  say "3/4 Backing up the users table, then turning admins into viewers"
  bak=$SAFE/users-$TS.sql
  podman exec romm-db sh -c 'mariadb-dump -uroot -p"$MARIADB_ROOT_PASSWORD" --single-transaction romm users' >"$bak" \
    || die "the backup failed, so nothing was changed"
  chmod 600 "$bak"
  [ -s "$bak" ] && grep -q 'CREATE TABLE' "$bak" || die "the backup file looks empty ($bak), so nothing was changed"
  note "backup: $bak ($(stat -c %s "$bak") bytes)"
  sql "SELECT id, username FROM users WHERE role='$ADMIN';" >"$SAFE/admins-$TS.txt"   # who they were, for the undo
  chmod 600 "$SAFE/admins-$TS.txt"
  sql "UPDATE users SET role='$VIEWER' WHERE role='$ADMIN';" || die "the change failed (lines above). The backup is $bak"
  note "every admin is a viewer now (their names: $SAFE/admins-$TS.txt)"
  restart_app romm                                    # a fresh start forgets any cached sign-in state
elif [ "$way" = FRESH ] && [ $FOLDER = 1 ]; then
  # ---------------------------------------------------------------- 3b. fresh: move the database folder aside
  say "3/4 Moving the database aside and starting RomM empty"
  if [ $MODE = scripts ]; then
    # romm-reset.sh (fixed copy in this fix list) stops both, MOVES /srv/stream/romm aside and starts RomM
    # with SKIP_STATE_RESTORE=1, so the nightly snapshot can't put the old admin back.
    ROMM_RESET_YES=1 bash "$SCRIPTS/romm-reset.sh" || die "romm-reset.sh stopped (lines above). Your old data is in $DATA.pre-reset-*; nothing was deleted"
  else
    systemctl --user stop romm.service romm-db.service
    mv "$DBV" "$DBV.pre-reset-$TS" && note "moved $DBV to $DBV.pre-reset-$TS (kept)"
    mkdir -p "$DBV"
    systemctl --user start romm-db.service && sleep 15 && systemctl --user start romm.service
  fi
else
  die "stopped. Nothing changed."
fi

# ------------------------------------------------------------------ 4. check
say "4/4 Does RomM want the wizard now? (up to 3 minutes)"
for _ in $(seq 18); do wizard_on && break; sleep 10; done
if wizard_on; then
  say "Yes. RomM is waiting for its setup wizard."
else
  warn "RomM still doesn't ask for the wizard. Send Claude or Grok the next lines:"
  romm_hb 20 | head -c 400; echo
  podman logs --tail 20 romm 2>&1 | sed 's/^/    /'
fi
cat <<TXT

==> On the-box (PIA off): open  http://10.6.9.20:8080/setup  in a private window (Ctrl+Shift+N), press Ctrl+F5.
    Make the new admin, save it in Vaultwarden, then Scan.
TXT
if [ "$way" = WIZARD ]; then cat <<TXT
    Your old users are still there as viewers. Make any of them admin again in RomM: Administration -> Users.
    UNDO (puts the users table back exactly as it was before this script; the admin made in the wizard goes away):
      podman exec -i romm-db sh -c 'mariadb -uroot -p"\$MARIADB_ROOT_PASSWORD" romm' < $bak
TXT
fi
cat <<'TXT'
    Last: the Multi-Pass sets RomM passwords with an admin login. Give it the NEW admin (README, Arcade step 5).
TXT
