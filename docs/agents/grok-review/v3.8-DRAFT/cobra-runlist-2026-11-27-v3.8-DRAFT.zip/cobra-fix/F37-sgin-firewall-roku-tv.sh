#!/usr/bin/env bash
# F37-sgin-firewall-roku-tv.sh  --  (v3.1) lets the Roku TV on the Xfinity side reach Jellyfin, and nothing else.
#
# Why: home-wifi step 7b (cobra-server docs/home-wifi + docs/roku-tv) adds an OPNsense port forward
#   WAN 10.0.0.2:8096 -> 10.6.9.20:8096, source 10.0.0.0/24 only. A port forward keeps the TV's own 10.0.0.x
#   source address, and the SGIN's /etc/nftables.conf only accepts 8096 from the LAN (10.6.9.0/24) and
#   WireGuard (10.6.99.0/24). So without this line the SGIN silently drops the TV, even with OPNsense right.
#   Risk accepted by the owner on 2026-11-21 (cobra-server docs/security/decision-log.md).
#
# What it adds, one line, right under the LAN's port list:
#     ip saddr 10.0.0.0/24 tcp dport 8096 accept
#   Only Jellyfin (8096), only from the Xfinity side. Nothing for 13380 (The Archives) or any other port:
#   the Archives stays LAN/WireGuard only (F32). Nothing on the internet changes: only OPNsense can deliver a
#   10.0.0.x source to the SGIN, and only through the 10.0.0.0/24-only forward.
#
# Not needed if the Roku is plugged into the Omada switch (home-wifi 7a): it is then a LAN device (10.6.9.x).
#
# Where:  the SGIN (10.6.9.20), as eels (the firewall belongs to root, so it uses sudo).
# How:    bash /tmp/cobra-fix/F37-sgin-firewall-roku-tv.sh
# Order:  any time, before or after F31 (F31 edits the LAN line itself; this adds a separate line below it).
#
# Safety (the same as F31): your SSH session stays up; the new rules are checked with nft -c before loading;
# /etc/nftables.conf is backed up; after loading you must open a SECOND SSH login and type y within 2 minutes,
# or the old rules go back by themselves.
# Undo:   sudo cp -p /etc/nftables.conf.bak-<time> /etc/nftables.conf   then   sudo nft -f /etc/nftables.conf
. "$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/fixlib.sh"
need_eels
CONF=/etc/nftables.conf
RULE='ip saddr 10.0.0.0/24 tcp dport 8096 accept'

sudo test -f "$CONF" || die "$CONF doesn't exist"

say "1/4 Look first (read-only)"
if sudo grep -qE 'ip saddr (\{ *)?10\.0\.0\.0/24.*dport[^#]*8096' "$CONF"; then
  sudo grep -nE '10\.0\.0\.0/24' "$CONF" | sed 's/^/    /'
  say "The TV's rule is already there. Nothing to do."; exit 0
fi
LINE=$(sudo grep -nE 'ip saddr \{[^}]*10\.6\.9\.0/24[^}]*\} tcp dport \{[^}]*8096' "$CONF" | head -1)
[ -n "$LINE" ] || die "couldn't find the LAN's tcp port list (the line with 10.6.9.0/24 and 8096) in $CONF. Send F01's survey to Claude or Grok."
note "the LAN's line: $LINE"
note "the live ruleset says Jellyfin answers on:"; sudo nft list ruleset | grep -n 'dport' | sed 's/^/      /'

say "2/4 Proposed change"
new=$(mktemp)
# Copy the file; after the first LAN tcp line, add the TV's line with the same indentation. Nothing else moves.
sudo cat "$CONF" | awk -v rule="$RULE" '
  { print }
  !done && /ip saddr \{[^}]*10\.6\.9\.0\/24[^}]*\} tcp dport \{[^}]*8096/ {
    match($0, /^[ \t]*/); ind = substr($0, 1, RLENGTH)
    print ind rule "    # v3.1 F37: Roku TV on the Xfinity side -> Jellyfin only (decision log 2026-11-21)"
    done = 1
  }' >"$new"
diff -u <(sudo cat "$CONF") "$new" | sed 's/^/    /' || true

say "3/4 Checking the new rules without loading them (nft -c)"
sudo nft -c -f "$new" || { rm -f "$new"; die "nft refused the new file; nothing changed"; }
confirm "Load it?" || { rm -f "$new"; die "nothing changed"; }

sudo cp -p "$CONF" "$CONF.bak-$TS" && note "backup: $CONF.bak-$TS"
sudo install -m 644 "$new" "$CONF"; rm -f "$new"
sudo nft -f "$CONF"                                   # the file starts with "flush ruleset": one clean swap

say "4/4 Keep it?"
warn "Open a NEW terminal on the-box now and log in:  ssh eels@10.6.9.20"
if read -rt 120 -p "Did the new SSH login work? Type y within 2 minutes: " a </dev/tty && [[ ${a,,} == y* ]]; then
  say "Kept. The Xfinity side (10.0.0.0/24) can reach Jellyfin on 8096, and nothing else."
  note "live check:"; sudo nft list ruleset | grep -n '10.0.0.0/24' | sed 's/^/      /'
  note "next: on the phone (on Electronomicon Wi-Fi, WireGuard off) open http://10.0.0.2:8096 -> Jellyfin login."
  note "then on the Roku: Jellyfin app -> Add Server -> http://10.0.0.2:8096"
else
  echo
  sudo cp -p "$CONF.bak-$TS" "$CONF" && sudo nft -f "$CONF"
  die "no confirmation, so the old rules are back (from $CONF.bak-$TS)"
fi
