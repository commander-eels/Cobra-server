#!/usr/bin/env bash
# F62-gate-ha-route.sh  --  (v3.8 draft) opens https://ha.songofeo.com: Home Assistant (VM 120), admins only, password + TOTP.
#
# Where:  the gate (10.6.9.10), as podsvc.
# How:    sudo machinectl shell podsvc@ /bin/bash /tmp/cobra-fix/F62-gate-ha-route.sh
# First:  VM 120 (cobra-home, 10.6.9.11) is running and its configuration.yaml trusts the gate (README 9.22 to 9.24).
#         Porkbun: ha.songofeo.com is a CNAME like command. (not a URL forward).
#         The certificate is the *.songofeo.com wildcard, so it already covers ha.
#
# What it changes (each one: a diff, your y, a backup; a failed check puts every file back):
#   1. nginx songofeo.conf: ha.songofeo.com joins the admin apps block ($protected map + its server_name), so it gets
#      the same Authelia check, rate limit and 1-hour websocket timeout as command. and status.
#   2. Authelia configuration.yml: two rules ABOVE the admin-apps rule (Authelia reads top to bottom, first match wins):
#        ha.songofeo.com  user eels or group admins  two_factor
#        ha.songofeo.com  everyone else              deny
#      So a friend with 2FA set up still can't open it. (The existing admin-apps rule has no subject line: see
#      README Help 9.36 / 9.37, a separate decision for you as CSO. This script doesn't change that rule.)
#   3. nginx -t and authelia validate-config, then nginx reloads and Authelia restarts (signs everyone out once).
. "$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/fixlib.sh"
need_podsvc
[ "$(which_box)" = gate ] || die "this is for the gate (10.6.9.10)"
[ -f "$NG" ] || die "$NG doesn't exist"
[ -f "$AU" ] || die "$AU doesn't exist"

say "0/3 Can the gate reach Home Assistant, and does it trust the gate? (read-only)"
code=000
if running nginx; then
  # A made-up visitor address in X-Forwarded-For: 200 means Home Assistant saw the request come from 10.6.9.10 and
  # trusted it. 400 means it saw some other source address (rootless port forwarding can hide the gate's address).
  code=$(podman exec nginx curl -s -o /dev/null -w '%{http_code}' --max-time 8 \
           -H 'X-Forwarded-For: 203.0.113.7' http://10.6.9.11:8123/manifest.json 2>/dev/null || true)
fi
case ${code:-000} in
  200) note "200: Home Assistant answers the gate and trusts it" ;;
  400) die "400: Home Assistant answers but doesn't trust the gate yet, so it would refuse every visitor.
       Nothing changed. Check the http: lines in Home Assistant's configuration.yaml (README 9.23), restart it (9.24), run this again." ;;
  000) die "no answer from 10.6.9.11:8123. Is VM 120 running and plugged into the LAN (README 9.9)? Nothing changed." ;;
  *)   warn "Home Assistant answered $code. Going on; the browser check at the end will show if it's wrong." ;;
esac

say "1/3 nginx ($NG)"
if grep -qE '^[[:space:]]*ha\.songofeo\.com[[:space:]]+http' "$NG"; then
  note "ha. is already in a map:"; grep -nE 'ha\.songofeo\.com' "$NG" | sed 's/^/      /'
else
  new=$(mktemp)
  # After the command. line in the $protected map, add ha.; then add ha. to the server_name that lists command.
  awk '
    { line = $0 }
    /^[[:space:]]*command\.songofeo\.com[[:space:]]+http:\/\/127\.0\.0\.1:3000;/ && !m {
      print line; print "  ha.songofeo.com       http://10.6.9.11:8123;    # Home Assistant, VM 120 cobra-home, admins only (v3.8 F62)"; m = 1; next }
    /^[[:space:]]*server_name .*command\.songofeo\.com/ && !s { sub(/command\.songofeo\.com/, "command.songofeo.com ha.songofeo.com", line); s = 1 }
    { print line }
    END { if (!m || !s) exit 3 }' "$NG" >"$new" \
    || { rm -f "$new"; die "couldn't find command.'s map line and server_name in $NG (hand-edited?). Nothing changed. Send Claude: grep -n command $NG"; }
  [ "$(grep -cE '^[[:space:]]*server_name .*\sha\.songofeo\.com([[:space:]]|;)' "$new")" = 1 ] || { rm -f "$new"; die "ha. isn't in exactly one server_name after the edit. Nothing changed."; }
  offer "$NG" "$new" "nginx's songofeo.conf" || true
fi

say "2/3 Authelia ($AU)"
if grep -qE '^[[:space:]]*- domain:[[:space:]]*ha\.songofeo\.com' "$AU"; then
  note "Authelia already has ha. rules:"; grep -nE 'ha\.songofeo\.com' "$AU" | sed 's/^/      /'
  # Manual part 10.7 (Oct 26) once suggested "networks: [home] policy: bypass" for ha.; the Nov 6 Authelia redo
  # says one sign-in everywhere, no home bypass. Don't keep a bypass by accident.
  if grep -A3 -E '^[[:space:]]*- domain:[[:space:]]*ha\.songofeo\.com' "$AU" | grep -qE 'policy:[[:space:]]*bypass'; then
    die "an ha. rule above uses 'policy: bypass' (the old manual 10.7 idea). Your Authelia rule is no home bypass.
       Nothing changed. Delete that ha. rule by hand (keep a copy), then run this again."
  fi
else
  new=$(mktemp)
  awk '
    /^[[:space:]]*# admin apps: password \+ TOTP, from anywhere/ && !d {
      match($0, /^[ \t]*/); i = substr($0, 1, RLENGTH)
      print i "# smart home (v3.8 F62): Home Assistant, admins only, password + TOTP, from anywhere"
      print i "- domain: ha.songofeo.com"
      print i "  subject: [\"user:eels\", \"group:admins\"]"
      print i "  policy: two_factor"
      print i "- domain: ha.songofeo.com"
      print i "  policy: deny"
      d = 1 }
    { print }
    END { if (!d) exit 3 }' "$AU" >"$new" \
    || { rm -f "$new"; die "couldn't find the '# admin apps: password + TOTP, from anywhere' line in $AU. Nothing changed. Send Claude: grep -n 'policy' $AU"; }
  offer "$AU" "$new" "Authelia's access rules" || true
fi

say "3/3 Check and reload"
if [ -e "$NG.bak-$TS" ] || [ -e "$AU.bak-$TS" ]; then
  gate_check_and_reload restart_authelia "$NG" "$AU"
else
  note "nothing changed, so nothing to reload"
fi
cat <<'TXT'

==> Then, on the-box (PIA off), in a private browser window:
    https://ha.songofeo.com  -> the gate asks for your password and TOTP -> Home Assistant's own login
    page. README Part 9 goes on from there.
TXT
