#!/usr/bin/env bash
# F63-gate-ha-token.sh  --  (v3.8 draft) connects the Multi-Pass's Smart home window to Home Assistant.
#
# Where:  the gate (10.6.9.10), as podsvc.
# How:    sudo machinectl shell podsvc@ /bin/bash /tmp/cobra-fix/F63-gate-ha-token.sh
# First:  F20 (this fix list's Multi-Pass build, which has the Smart home window), F62, and Home Assistant's owner
#         account made at https://ha.songofeo.com. Then in Home Assistant: your name (bottom left) -> Security ->
#         Long-lived access tokens -> Create token -> name it eo-account -> copy it (it's shown once).
#
# What it does: asks for the token (typed hidden, sent on stdin, so it's never on screen or in the process list),
# backs up apps.json, and writes ONE entry, "home", into it (mode 600, like the app tokens):
#   "home": {"url": "http://10.6.9.11:8123", "token": "...", "enabled": true}
# Nothing else in apps.json changes. Then it restarts eo-account and checks it answers.
# Undo:  cp -p /srv/gate/eo-account/data/apps.json.bak-<time> /srv/gate/eo-account/data/apps.json && systemctl --user restart eo-account
# Revoke: delete the eo-account token in Home Assistant (same Security page). The window then says "Token refused" and stops asking (README Help 9.37).
. "$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/fixlib.sh"
need_podsvc
[ "$(which_box)" = gate ] || die "this is for the gate (10.6.9.10)"
DIR=/srv/gate/eo-account
[ -f "$QDIR_FIX/eo-account.container" ] || die "eo-account isn't set up yet (no Quadlet). Run F20 first."
[ -f "$DIR/data/apps.json" ] || die "$DIR/data/apps.json is missing. Run F20 first."
grep -q 'def home_block' "$DIR/app/eo_account.py" || die "the live Multi-Pass has no Smart home window yet. Run F20 (this fix list) first."
IMAGE=$(sed -n 's/^Image=//p' "$QDIR_FIX/eo-account.container" | head -1)
py() { podman run --rm -i -v "$DIR/data:/data" -e PYTHONDONTWRITEBYTECODE=1 "$IMAGE" python3 "$@"; }

say "1/3 Look first (read-only)"
note "Smart home entry in apps.json: $(py -c "import json;h=json.load(open('/data/apps.json')).get('home') or {};print('on' if h.get('enabled') and h.get('token') else 'not set')")"

say "2/3 The token"
read -rsp "    Paste the eo-account token from Home Assistant (hidden), or just Enter to stop: " tok </dev/tty; echo
[ -n "$tok" ] || die "no token typed; nothing changed"
confirm "Write it into apps.json as the Smart home connection? (a backup is made first)" || die "nothing changed"
backup "$DIR/data/apps.json"
printf '%s\n' "$tok" | py -c "
import json, os, sys
p = '/data/apps.json'; c = json.load(open(p))
c['home'] = {'url': 'http://10.6.9.11:8123', 'token': sys.stdin.readline().strip(), 'enabled': True}
tmp = p + '.new'; open(tmp, 'w').write(json.dumps(c, indent=2) + '\n'); os.chmod(tmp, 0o600); os.replace(tmp, p)
" || { restore "$DIR/data/apps.json"; die "couldn't write apps.json; the backup was put back"; }
unset tok

say "3/3 Restart the Multi-Pass and check"
restart_app eo-account
up=0
for _ in $(seq 1 20); do
  sleep 1
  podman exec eo-account python3 -c "import urllib.request; urllib.request.urlopen('http://127.0.0.1:8098/health', timeout=2)" 2>/dev/null && { up=1; break; }
done
if [ $up = 1 ]; then
  say "The Multi-Pass is back. Open https://account.songofeo.com -> Smart home: your lights, switches and thermostat."
else
  restore "$DIR/data/apps.json"; restart_app eo-account
  die "eo-account didn't answer, so apps.json was put back and it restarted again. Look at: podman logs --tail 40 eo-account"
fi
