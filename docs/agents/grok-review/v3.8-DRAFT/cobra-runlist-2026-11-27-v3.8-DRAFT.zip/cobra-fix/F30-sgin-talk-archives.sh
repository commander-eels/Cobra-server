#!/usr/bin/env bash
# F30-sgin-talk-archives.sh  --  starts the two new walled Audiobookshelf servers on the SGIN.
#
#   Talk Radio & Comedy Club   http://10.6.9.20:13379   reads dock1a/comedy (read-only)    talk., comedy.
#   The Archives               http://10.6.9.20:13380   reads dock1a/archives (read-only)  archives.
#
# Where:  the SGIN (10.6.9.20), as podsvc.
# How:    sudo machinectl shell podsvc@ /bin/bash /tmp/cobra-fix/F30-sgin-talk-archives.sh
#
# Each is its own pod with its own settings, covers, port and users. Neither shares anything with the main
# Audiobookshelf (:13378, Audiobooks), or with each other. That's the wall: a person can only open a server
# they have an account on, and only see the one folder that server mounts.
# Nothing is moved or deleted: your files stay where they are; the servers only read them.
# The old Talk/Comedy Navidrome (if it still runs) is left alone; this script only reports it.
. "$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/fixlib.sh"
need_podsvc
[ "$(which_box)" = sgin ] || die "this is for the SGIN (10.6.9.20)"

say "1/3 Read-only checks"
for d in dock1a/comedy dock1a/archives; do
  f=$DISKS/$d
  if [ -d "$f" ]; then note "$f: $(find "$f" -maxdepth 1 -mindepth 1 | wc -l) entries"
  else warn "$f is missing. Make it (as eels): sudo mkdir -p $f && sudo chown podsvc:media $f   then run this again"; fi
done
for p in 13379 13380; do
  if ss -ltnH "sport = :$p" | grep -q . && ! podman container exists "audiobookshelf-$( [ $p = 13379 ] && echo talk || echo archives)"; then
    die "port $p is already used by something else (ss -ltnp 'sport = :$p'). Nothing changed."
  fi
done
podman ps -a --filter name=navidrome- --format '    old Navidrome left as it is: {{.Names}} ({{.Status}})'

say "2/3 Start them"
confirm "Start (or update) both servers now? Existing settings and users are kept." || die "nothing changed"
bash "$PODS/sgin/audiobookshelf-talk.sh"
bash "$PODS/sgin/audiobookshelf-archives.sh"

say "3/3 Check"
for p in 13379 13380; do printf '    :%s/ping -> %s\n' "$p" "$(probe_code "http://127.0.0.1:$p/ping")"; done
cat <<'TXT'

==> First time only, for EACH server (on the-box, PIA off, in a browser):
    1. Open http://10.6.9.20:13379 (Talk Radio & Comedy Club), later http://10.6.9.20:13380 (The Archives).
       If it doesn't load from the-box, run F31 (the firewall) first.
    2. Make the root user. Use a different password for each server and save both in Vaultwarden.
    3. Settings -> Libraries -> Add:
         Talk server:     "Talk Radio"    type Book (Podcast only for shows you follow by RSS), folder /media/comedy/<its folder>
                          "Comedy Club"   type Book, folder /media/comedy/<its folder>
         Archives server: "The Archives"  type Book, folder /media/archives
       Type Book is right for long recordings: one item per folder, its own saved spot and bookmarks per person.
    4. Settings -> Users -> Add: one user per friend with that Bay on their pass, the SAME username as their gate account.
    5. Settings -> API Keys -> Add, name eo-account. Keep the page open for F20 (it asks for the token).
TXT
