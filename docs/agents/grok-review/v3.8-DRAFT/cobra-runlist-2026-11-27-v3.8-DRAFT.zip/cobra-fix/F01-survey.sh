#!/usr/bin/env bash
# F01-survey.sh  --  READ-ONLY. Changes nothing, anywhere. Run it on the gate AND on the SGIN, then send the two
# files it writes (to Claude or Grok) before running anything else in this fix list.
#
# Where:  the gate (10.6.9.10) and the SGIN (10.6.9.20), as podsvc (it reads podsvc's containers).
# How:    sudo machinectl shell podsvc@ /bin/bash /tmp/cobra-fix/F01-survey.sh
# Writes: /tmp/cobra-fix-survey-gate.txt or /tmp/cobra-fix-survey-sgin.txt (also printed on screen)
#
# What it looks at:
#   both:  every expected container (running? healthy? does its page answer?), Quadlet units, listening ports
#   gate:  which Multi-Pass build is live (compared with this fix list's), the nginx and Authelia lines for
#          talk., archives. and player., the Multi-Pass's app list (names and on/off only, never a password)
#   SGIN:  the Arcade: why the setup wizard doesn't show (heartbeat, RomM's accounts by role, half-done resets,
#          the nightly snapshot), the Talk and Archives folders, and whether ports 13379/13380 are free
# Secrets, password hashes and tokens are never printed.
set -uo pipefail                       # no -e: a survey keeps going past a failed check and reports it
. "$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/fixlib.sh"
set +e
need_podsvc
BOX=$(which_box)
OUT=/tmp/cobra-fix-survey-$BOX.txt

{
echo "# cobra-fix survey  $(date '+%F %T %Z')  host=$(hostname)  box=$BOX  user=$(id -un)"
echo "## podman $(podman --version 2>/dev/null | awk '{print $3}')   linger=$(loginctl show-user "$(id -un)" -p Linger --value 2>/dev/null)"
echo "## awk: $(readlink -f "$(command -v awk)" 2>/dev/null)  ($(awk -W version 2>/dev/null | head -1 || awk --version 2>/dev/null | head -1))"   # v3.8: mawk ignores \s

echo; echo "## Expected containers (name | state | health | page | started by)"
if [ "$BOX" = gate ]; then list=("${EXPECTED_GATE[@]}"); else list=("${EXPECTED_SGIN[@]}"); fi
for row in "${list[@]}"; do
  IFS='|' read -r name url how what <<<"$row"
  st=$(podman inspect -f '{{.State.Status}}' "$name" 2>/dev/null || echo missing)
  hl=$(podman inspect -f '{{if .State.Health}}{{.State.Health.Status}}{{else}}-{{end}}' "$name" 2>/dev/null || echo -)
  code=-; [ -n "$url" ] && [ "$st" = running ] && code=$(probe_code "$url")
  printf '  %-24s %-9s %-9s %-4s %-8s %s\n' "$name" "$st" "$hl" "$code" "$(how_run "$name")" "$what"
done

echo; echo "## Every container podsvc has"
podman ps -a --format '  {{.Names}}\t{{.Status}}\t{{.Image}}' 2>/dev/null
echo; echo "## Pods"
podman pod ps --format '  {{.Name}}\t{{.Status}}\t{{.NumberOfContainers}} containers' 2>/dev/null
echo; echo "## Quadlet files in $QDIR_FIX"
ls -1 "$QDIR_FIX" 2>/dev/null | sed 's/^/  /'
echo; echo "## Listening TCP ports"
ss -ltnH 2>/dev/null | awk '{print "  "$4}' | sort -u

if [ "$BOX" = gate ]; then
  echo; echo "## Multi-Pass build: live vs this fix list"
  live=/srv/gate/eo-account/app/eo_account.py
  for f in "$live" "$P/account-gate/eo_account.py"; do
    if [ -r "$f" ]; then
      printf '  %-58s %7s bytes  sha256 %s\n' "$f" "$(stat -c %s "$f")" "$(sha256sum "$f" | cut -c1-12)"
      for m in 'def forgot_page' 'PODPANELS_KEY =' 'def setup_block' 'def admin_block' 'def admin_bays_block' 'AudiobookshelfTalk'; do
        printf '      %-24s %s\n' "$m" "$(grep -c "$m" "$f")"
      done
    else echo "  $f: not found"; fi
  done
  echo "  theme fonts live: $(ls /srv/gate/eo-account/app/fonts/*.woff2 2>/dev/null | wc -l) (the fix list has $(ls "$P"/account-gate/fonts/*.woff2 2>/dev/null | wc -l))"
  echo "  eo-account unit: $( [ -f "$QDIR_FIX/eo-account.container" ] && echo Quadlet || echo none)"
  echo; echo "## Multi-Pass apps (name: enabled) -- no secrets"
  grep -oE '"[a-z-]+": *\{ *"enabled": *(true|false)' /srv/gate/eo-account/data/apps.json 2>/dev/null | sed 's/^/  /' || echo "  no apps.json"
  echo; echo "## nginx: talk., comedy., archives., player. and the phone-app skip"
  grep -nE '^\s*(talk|comedy|archives|player)\.songofeo\.com|~\^\(audio' "$NG" 2>/dev/null | sed 's/^/  /'
  echo; echo "## Authelia: music wall domain lists"
  grep -n 'music.songofeo.com' "$AU" 2>/dev/null | sed 's/^/  /'
  echo; echo "## TLS certificate names (does it cover player.songofeo.com?)"
  if command -v openssl >/dev/null; then
    openssl x509 -in /srv/gate/nginx/certs/fullchain.pem -noout -ext subjectAltName 2>/dev/null | tail -n +2 | tr ',' '\n' | sed 's/^ */  /'
  else
    podman exec nginx sh -c 'command -v openssl >/dev/null && openssl x509 -in /certs/fullchain.pem -noout -ext subjectAltName' 2>/dev/null | sed 's/^ */  /' || echo "  (no openssl here)"
  fi
  echo; echo "## Can the gate reach the new SGIN ports?"
  for u in http://10.6.9.20:13379/ping http://10.6.9.20:13380/ping http://10.6.9.20:4533/ping; do
    printf '  %-34s %s\n' "$u" "$(probe_code "$u")"
  done
fi

if [ "$BOX" = sgin ]; then
  echo; echo "## ARCADE (RomM): why no setup wizard?"
  mode=scripts; [ -f "$QDIR_FIX/romm.container" ] && mode=quadlet
  echo "  runs from: $mode"
  for u in http://127.0.0.1:8080 http://10.6.9.20:8080; do
    hb=$(curl -s -L --max-time 15 "$u/api/heartbeat" 2>/dev/null)
    code=$(curl -s -o /dev/null -w '%{http_code}' --max-time 10 "$u/" 2>/dev/null)
    wiz=$(printf '%s' "$hb" | grep -oE '"SHOW_SETUP_WIZARD": *(true|false)' | head -1)
    printf '  %-24s page=%s  heartbeat=%s  %s\n' "$u" "${code:-000}" "$([ -n "$hb" ] && echo yes || echo NO)" "${wiz:-SHOW_SETUP_WIZARD not found}"
  done
  echo "  RomM's accounts by role (inside romm-db; the password never leaves the container):"
  podman exec romm-db sh -c 'mariadb -uroot -p"$MARIADB_ROOT_PASSWORD" -N -e "SELECT CONCAT(\"    \",role,\": \",COUNT(*)) FROM romm.users GROUP BY role; SHOW COLUMNS FROM romm.users LIKE \"role\";"' 2>&1 | sed 's/^/  /' | head -12
  echo "  database folder / volume:"
  if [ "$mode" = quadlet ]; then grep -h '^Volume=.*mysql' "$QDIR_FIX/romm-db.container" 2>/dev/null | sed 's/^/    /'
  else echo "    /srv/stream/romm/db  ($(du -sh /srv/stream/romm/db 2>/dev/null | cut -f1))"; fi
  echo "  half-done resets (moved-aside folders):"
  ls -d /srv/stream/romm.pre-reset-* /srv/stream/romm/db.pre-reset-* 2>/dev/null | sed 's/^/    /' || echo "    none"
  echo "  newest nightly snapshots of RomM (these can bring old accounts back into an EMPTY database):"
  ls -1t /srv/storage/vault/personal-state/romm 2>/dev/null | head -3 | sed 's/^/    /' || echo "    none"
  echo "  reset scripts on this machine (from older bundles):"
  ls -1 /tmp/cobra-setup/24-sgin-romm-reset.sh /tmp/cobra-setup/cobra-server-scripts/podman/sgin/romm-reset.sh 2>/dev/null | sed 's/^/    /' || echo "    none"
  echo "  RomM's last log lines:"
  podman logs --tail 15 romm 2>&1 | sed 's/^/    /'

  echo; echo "## TALK RADIO & COMEDY CLUB and THE ARCHIVES"
  for d in dock1a/comedy dock1a/archives; do
    f=/srv/storage/disks/$d
    if [ -d "$f" ]; then echo "  $f: $(find "$f" -maxdepth 1 -mindepth 1 | wc -l) entries; top folders:"; find "$f" -maxdepth 1 -mindepth 1 -type d -printf '    %f\n' | head -15
    else echo "  $f: MISSING"; fi
  done
  for p in 13379 13380; do printf '  port %s: %s\n' "$p" "$(ss -ltnH "sport = :$p" | grep -q . && echo 'IN USE' || echo free)"; done
  echo; echo "## AUDIOBOOKS (the main Audiobookshelf, :13378): what it can read (F34 narrows this)"
  podman inspect -f '{{range .Mounts}}{{if ne .Destination "/config"}}{{if ne .Destination "/metadata"}}  {{.Source}} -> {{.Destination}}{{"\n"}}{{end}}{{end}}{{end}}' audiobookshelf 2>/dev/null || echo "  no audiobookshelf container"
  echo "  its pod: $(podman inspect -f '{{.PodName}}' audiobookshelf 2>/dev/null)"
  echo "  old Navidromes (left alone until you say so):"
  podman ps -a --filter name=navidrome- --format '    {{.Names}}  {{.Status}}' 2>/dev/null
fi
} 2>&1 | tee "$OUT"
chmod 644 "$OUT" 2>/dev/null
echo
say "Saved $OUT. On the-box, fetch it with (one line):"
note "scp eels@$( [ "$BOX" = gate ] && echo 10.6.9.10 || echo 10.6.9.20 ):$OUT ."
