# shellcheck shell=bash
# fixlib.sh  --  shared by every F-script in this fix list. Sourced, never run on its own.
#
# It loads payload/lib.sh (the cobra-setup helpers: say, note, warn, die, confirm, backup, offer, running,
# restart_app, romm_hb, nginx_test ...) and adds what this fix list needs:
#   which_box        prints gate or sgin, from this machine's address
#   EXPECTED_GATE    every container the gate should run, with where to check it and what starts it
#   EXPECTED_SGIN    the same for the SGIN
#   probe_code URL   the HTTP status code an app answers with (000 = no answer)
#
# The standing rules (from lib.sh) hold for every F-script:
#   read-only first; a diff and your y before any file changes; a backup before every change;
#   nothing is ever deleted; a failed check puts the backup back.

FIX=$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)
P=$FIX/payload                                   # the merged cobra-setup files this fix list installs from
[ -r "$P/lib.sh" ] || { echo "ERROR: $P/lib.sh is missing. Run F00-copy-to-servers.ps1 on the-box again." >&2; exit 1; }
# shellcheck source=payload/lib.sh
. "$P/lib.sh"
PODS=$P/cobra-server-scripts/podman              # cobra-server's podman run scripts (gate/ and sgin/)
# The drive layout (DISKS and every *_DIR) comes from the podman scripts' lib.sh, the one place it's written.
# Only those assignment lines are read, so its functions don't replace the cobra-setup ones loaded above.
eval "$(grep -E '^\s*(DISKS|[A-Z]+_DIR)=' "$PODS/lib.sh" | sed -E 's/\s+#.*$//')"

which_box() {
  local ips; ips=$(hostname -I 2>/dev/null || true)
  case " $ips " in
    *" 10.6.9.10 "*) echo gate ;;
    *" 10.6.9.20 "*) echo sgin ;;
    *) echo unknown ;;
  esac
}

# container | URL to check (empty = no web page of its own) | what starts it | what it is
# "quadlet:" means a systemd --user unit made by a cobra-setup step; "script:" is a file under $PODS.
EXPECTED_GATE=(
  "nginx||script:gate/nginx.sh|the front door (every hostname)"
  "authelia|http://127.0.0.1:9091/api/health|script:gate/authelia.sh|the sign-in and the walls"
  "vaultwarden|http://127.0.0.1:8222/alive|script:gate/vaultwarden.sh|password vault"
  "postgres||script:gate/paperless.sh|Paperless's database"
  "redis||script:gate/paperless.sh|Paperless's queue"
  "paperless|http://127.0.0.1:8000/|script:gate/paperless.sh|documents and OCR"
  "metube|http://127.0.0.1:8081/|script:gate/metube.sh|video and audio downloader"
  "homepage|http://127.0.0.1:3000/|script:gate/homepage.sh|the dashboard (command.)"
  "uptime-kuma|http://127.0.0.1:3001/|script:gate/uptime-kuma.sh|pod watcher (status.)"
  "hiscore|http://127.0.0.1:8090/healthz|script:gate/hiscore.sh|cabinet high scores"
  "eo-art|http://127.0.0.1:8790/|script:gate/eo-art.sh|concourse window pictures"
  "eo-account|http://127.0.0.1:8098/|quadlet:F20-gate-multipass.sh|the Multi-Pass"
  "forms|http://127.0.0.1:8097/|quadlet:cobra-setup step 14|Formidable forms receiver"
  "feishin|http://127.0.0.1:9180/|script:gate/feishin.sh|Feishin music player (new)"
)
EXPECTED_SGIN=(
  "jellyfin|http://127.0.0.1:8096/health|script:sgin/jellyfin.sh|Television Bay"
  "ersatztv|http://127.0.0.1:8409/|script:sgin/ersatztv.sh|live TV channels"
  "navidrome|http://127.0.0.1:4533/ping|script:sgin/navidrome.sh|Music Bay"
  "audiobookshelf|http://127.0.0.1:13378/ping|script:sgin/audiobookshelf.sh|Audiobooks Bay (walled by F34)"
  "audiobookshelf-talk|http://127.0.0.1:13379/ping|script:sgin/audiobookshelf-talk.sh|Talk Radio & Comedy Club Bay (new)"
  "audiobookshelf-archives|http://127.0.0.1:13380/ping|script:sgin/audiobookshelf-archives.sh|The Archives Bay (new)"
  "kavita|http://127.0.0.1:5000/|script:sgin/kavita.sh|Kavita Comics (walled)"
  "kavita-books|http://127.0.0.1:5001/|step:F50-sgin-kavita-walls.sh, then F35 on the gate|Kavita Books (walled, new)"
  "kavita-rpg|http://127.0.0.1:5002/|step:F50-sgin-kavita-walls.sh, then F35 on the gate|Kavita RPG Vault (walled, new)"
  "romm-db||script:sgin/romm.sh|the Arcade's database"
  "romm|http://127.0.0.1:8080/|script:sgin/romm.sh|Arcade Bay"
  "icecast|http://127.0.0.1:8000/|script:sgin/radio.sh|the radio stream"
  "radio||script:sgin/radio.sh|the radio's playout (Liquidsoap)"
)

# probe_code URL   The status code, trying the URL as given and then with the SGIN's LAN address
# (some SGINs don't answer published ports on 127.0.0.1). On the gate nothing is published, so it asks
# from inside the pod (nginx has curl; eo-account has Python).
probe_code() {
  local url=$1 c=000 lan
  if [ "$(which_box)" = gate ]; then
    if running nginx; then
      c=$(podman exec nginx curl -s -o /dev/null -w '%{http_code}' --max-time 6 "$url" 2>/dev/null || true)
    elif running eo-account; then
      c=$(podman exec eo-account python3 -c "import sys,urllib.request as u,urllib.error as e
try: print(u.urlopen(sys.argv[1],timeout=6).status)
except e.HTTPError as x: print(x.code)
except Exception: print('000')" "$url" 2>/dev/null || true)
    fi
  else
    c=$(curl -s -o /dev/null -w '%{http_code}' --max-time 6 "$url" 2>/dev/null || true)
    if [ "${c:-000}" = 000 ]; then
      lan=${url/127.0.0.1/10.6.9.20}
      c=$(curl -s -o /dev/null -w '%{http_code}' --max-time 6 "$lan" 2>/dev/null || true)
    fi
  fi
  printf '%s' "${c:-000}"
}

# how_run NAME   quadlet (a systemd --user unit runs it), script (plain container) or missing.
how_run() {
  if [ -f "$QDIR_FIX/$1.container" ]; then echo quadlet
  elif podman container exists "$1" 2>/dev/null; then echo script
  else echo missing; fi
}
QDIR_FIX=$HOME/.config/containers/systemd
